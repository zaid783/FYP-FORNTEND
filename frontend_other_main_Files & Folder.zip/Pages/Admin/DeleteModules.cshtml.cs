using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace payday_client.Pages.Admin
{
    public class DeleteModulesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
