using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace payday_client.Pages.ChangePassword
{
    public class ChangePasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
