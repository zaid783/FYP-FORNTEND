using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace payday_client.Pages.CompanySetup
{
    public class CompanySetupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
