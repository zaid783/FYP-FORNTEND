﻿
const apiBaseUrl = "http://localhost:7085"; 
let isFetching = false;
let aviData = [];

document.addEventListener("DOMContentLoaded", () => {
    fetchAndRenderAVIData(true); // First time load with dropdown + date

    setInterval(() => {
        console.log("♻️ Auto-refreshing AVI data...");
        fetchAndRenderAVIData(false); 
    }, 30000);
});

async function fetchAndRenderAVIData(isInitialLoad = false) {
    if (isFetching) return;
    isFetching = true;

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/avi_vehicle`);
        if (!response.ok) throw new Error("❌ Failed to fetch AVI data");

        const data = await response.json();
        console.log("✅ AVI Data:", data);

        aviData = normalizeKeys(data.data_table || []);
        renderAVISummaryCards(data.cards);
        renderAVITable(aviData);

        if (isInitialLoad) {
            populateVehicleDropdown(aviData);
            setDefaultDateRange();
        }

    } catch (err) {
        console.error("🚨 Error loading AVI data:", err.message);
    } finally {
        isFetching = false;
    }
}

function normalizeKeys(dataArray) {
    return dataArray.map(item => ({
        sNo: item.S_No,
        vrn: item.VRN,
        tag: item.RFID_Tag_No,
        dispenser: item.Dispenser_Id,
        nozzle: item.Nozzle_Id,
        price: item.Price_OMR,
        volume: item.Volume_Liters,
        amount: item.Total_Amount_OMR,
        fuelType: item.Fuel_Type,
        timestamp: item.Timestamp
    }));
}

function renderAVISummaryCards(cards) {
    if (document.getElementById("card1")) {
        document.getElementById("card1").innerText = cards.total_vehicles;
    }
    if (document.getElementById("card2")) {
        document.getElementById("card2").innerText = cards.total_transactions;
    }
    if (document.getElementById("card3")) {
        document.getElementById("card3").innerText = cards.total_delivered_volume_liters.toFixed(2);
    }
    if (document.getElementById("card4")) {
        document.getElementById("card4").innerText = cards.total_sale_value_omr.toFixed(2);
    }
}

function populateVehicleDropdown(data) {
    const vehicleSet = new Set(data.map(item => item.vrn));
    const vehicleSelect = document.getElementById("vehicle");
    vehicleSelect.innerHTML = '<option value="">Select Vehicle</option>';
    vehicleSet.forEach(vehicle => {
        const opt = document.createElement("option");
        opt.value = vehicle;
        opt.textContent = vehicle;
        vehicleSelect.appendChild(opt);
    });
}

function renderAVITable(data) {
    if ($.fn.dataTable.isDataTable('#aviTable')) {
        const table = $('#aviTable').DataTable();
        table.clear();
        table.rows.add(data).draw();
    } else {
        $('#aviTable').DataTable({
            data: data,
            columns: [
                { data: 'sNo', title: 'S.No' },
                { data: 'vrn', title: 'Vehicle' },
                { data: 'tag', title: 'Tag' },
                { data: 'dispenser', title: 'Dispenser' },
                { data: 'nozzle', title: 'Nozzle' },
                { data: 'price', title: 'Price (OMR)' },
                { data: 'volume', title: 'Volume (L)' },
                { data: 'amount', title: 'Amount (OMR)' },
                { data: 'timestamp', title: 'Timestamp' }
            ],
            dom: 'Bfltip',
            lengthMenu: [[5, 10, 20, -1], [5, 10, 20, "All"]],
            pageLength: 10,
            buttons: [
                { extend: 'copy', text: 'Copy' },
                { extend: 'csv', text: 'CSV' },
                { extend: 'excel', text: 'Excel' },
                { extend: 'pdf', text: 'PDF' },
                { extend: 'print', text: 'Print' }
            ],
            initComplete: function () {
                $(".dt-buttons").after($(".dataTables_length"));
            }
        });
    }
}

function setDefaultDateRange() {
    const now = new Date();
    const end = now.toISOString().slice(0, 10); // YYYY-MM-DD
    const start = new Date(now.getTime() - 30 * 60000).toISOString().slice(0, 10);
    document.getElementById("startDate").value = start;
    document.getElementById("endDate").value = end;
}

// Filter logic
$(document).ready(function () {
    $('#searchFilterBtn').on('click', function () {
        const table = $('#aviTable').DataTable();
        const vehicle = $('#vehicle').val();
        const start = new Date($('#startDate').val());
        const end = new Date($('#endDate').val());

        table.rows().every(function () {
            const data = this.data();
            const timestamp = new Date(data.timestamp);
            const matchVehicle = !vehicle || data.vrn === vehicle;
            const matchDate = timestamp >= start && timestamp <= end;

            const rowNode = this.node();
            if (rowNode) {
                $(rowNode).toggle(matchVehicle && matchDate);
            }
        });
    });

    $('#vehicle').on('change', function () {
        if (!$(this).val()) {
            $('#aviTable').DataTable().rows().every(function () {
                const rowNode = this.node();
                if (rowNode) {
                    $(rowNode).show();
                }
            });
        }
    });
});


