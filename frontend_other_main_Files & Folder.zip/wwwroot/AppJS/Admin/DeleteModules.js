﻿import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");


// INITIALIZING VARIBALES
var end_point;

var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");

var url = new URLSearchParams(window.location.search);
var menuId = '';

if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/AdminAccess';
    discon();
});


// DISCONNECTION FUNCTION
function discon() {
    Onload();
}

// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    $.ajax({
        url: GETAPIURL(end_point + "/GetCurrentRecordsCount"),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            formActionSpinners.css("display", "none");
            $("#button_msg").css("display", "block");
            if (response != null) {
                if (response.statusCode == "200") {
                    var data = response.data;
                    $("#count_holidays").text(data.holidaysCount);
                    $("#count_roster").text(data.rostersCount);
                    $("#count_loans").text(data.loansCount);
                    $("#count_advances").text(data.advancesCount);
                    $("#count_loginaudits").text(data.loginAuditCount);
                    $("#count_attendance").text(data.attendanceCount);
                    $("#count_leaves").text(data.leavesCount);
                    $("#count_employees").text(data.employeesCount);
                    $("#count_shifts").text(data.shiftsCount);
                    $("#count_policy").text(data.policiesCount);
                    $("#count_allowances").text(data.allowancesCount);
                    $("#count_banks").text(data.banksCount);
                    $("#count_bloodgroups").text(data.bloodGroupsCount);
                    $("#count_city").text(data.citiesCount);
                    $("#count_country").text(data.countriesCount);
                    $("#count_deductions").text(data.deductionsCount);
                    $("#count_departments").text(data.departmentsCount);
                    $("#count_designations").text(data.desginationsCount);
                    $("#count_branches").text(data.branchesCount);
                    $("#count_status").text(data.statusCount);
                    $("#count_genders").text(data.gendersCount);
                    $("#count_inout").text(data.inoutCount);
                    $("#count_marital").text(data.maritalCount);
                    $("#count_qualification").text(data.qualificationsCount);
                    $("#count_relation").text(data.relationsCount);
                }
            }


        },
        error: function (xhr, status, err) {
            formActionSpinners.css("display", "none");
            $("#button_msg").css("display", "block");
            Swal.fire({
                icon: 'error',
                text: "Failed to clear the selected database."
            });
        }
    })
    return true;
}


function FlushEntity(tableName, prereq) {
    Swal.fire({
        title: 'Warning',
        icon: 'warning',
        text: `Are you sure you want to clear this table? The following tables will be cleared as well: ${prereq} (Clear Manually)`,
        showCancelButton: true,
        confirmButtonColor: "#DC3545",
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: GETAPIURL(end_point + "/FlushEntity"),
                    type: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                        xhr.setRequestHeader('_TableName', tableName);
                    },
                    success: function (response) {
                        if (response != null) {
                            if (response.statusCode == "200") {
                                if (response.message == "CLEARED") {
                                    Swal.fire({
                                        icon: 'success',
                                        text: response.data
                                    });
                                    Onload();
                                }
                            }
                            else if (response.statusCode == "405") {
                                Swal.fire({
                                    icon: 'error',
                                    title: "Failed",
                                    text: "Please clear dependent tables initially to proceed!"
                                });
                            }
                            else {
                                Swal.fire({
                                    icon: 'error',
                                    text: response.data
                                });
                            }
                        }
                    },
                    error: function (xhr, status, err) {
                        Swal.fire({
                            icon: 'error',
                            text: "Failed to clear the selected database."
                        });
                    }
                })
            } else {
                formActionSpinners.css("display", "none");
                $("#button_msg").css("display", "block");
            }
        })

    return true;
}

$("#btn_emptydatabase").on("click", () => {
    formActionSpinners.css("display", "block");
    $("#button_msg").css("display", "none");
    FlushEntity("ALL", "");
});
// BTN EVENT HANDLERS -- MODULES
$("#btn_module_loginaudit").on("click", () => {
    FlushEntity("LOGINAUDIT", "-");
})
$("#btn_module_holidays").on("click", () => {
    FlushEntity("HOLIDAY", "-");
})
$("#btn_module_roster").on("click", () => {
    FlushEntity("ROSTER", "RosterEvents, EmployeeRoster");
})
$("#btn_module_loans").on("click", () => {
    FlushEntity("LOAN", "EmployeeLoan, EmployeeLoanInstallements");
})
$("#btn_module_advances").on("click", () => {
    FlushEntity("ADVANCE", "-");
})
$("#btn_module_attendance").on("click", () => {
    FlushEntity("ATTENDANCE", "-");
})
$("#btn_module_leaves").on("click", () => {
    FlushEntity("LEAVE", "LeaveRequests, LeavePolicies, LeaveTypes");
})
$("#btn_module_employees").on("click", () => {
    FlushEntity("EMPLOYEE", "AdvanceSalary, UserEventLogs");
})
$("#btn_module_shifts").on("click", () => {
    FlushEntity("SHIFT", "-");
})
$("#btn_module_policies").on("click", () => {
    FlushEntity("POLICY", "-");
})

// CONFIGURATION
$("#btn_config_allowances").on("click", () => {
    FlushEntity("ALLOWANCE", "PersonalInformation");
})
$("#btn_config_banks").on("click", () => {
    FlushEntity("BANK", "PersonalInformation");
})
$("#btn_config_bloodgroups").on("click", () => {
    FlushEntity("BLOODGROUP", "PersonalInformation");
})
$("#btn_config_cities").on("click", () => {
    FlushEntity("CITY", "PersonalInformation");
})
$("#btn_config_countries").on("click", () => {
    FlushEntity("COUNTRY", "PersonalInformation");
})
$("#btn_config_deductions").on("click", () => {
    FlushEntity("DEDUCTION", "PersonalInformation");
})
$("#btn_config_departments").on("click", () => {
    FlushEntity("DEPARTMENT", "PersonalInformation");
})
$("#btn_config_designations").on("click", () => {
    FlushEntity("DESIGNATION", "PersonalInformation");
})
$("#btn_config_empbranch").on("click", () => {
    FlushEntity("BRANCH", "PersonalInformation");
})
$("#btn_config_empstatus").on("click", () => {
    FlushEntity("STATUS", "PersonalInformation");
})
$("#btn_config_empgenders").on("click", () => {
    FlushEntity("GENDER", "PersonalInformation");
})
$("#btn_config_inoutexemption").on("click", () => {
    FlushEntity("INOUT", "PersonalInformation");
})
$("#btn_config_maritalstatus").on("click", () => {
    FlushEntity("MARTITALSTATUS", "PersonalInformation");
})
$("#btn_config_qualifications").on("click", () => {
    FlushEntity("QUALIFICATION", "PersonalInformation");
})
$("#btn_config_relations").on("click", () => {
    FlushEntity("RELATION", "PersonalInformation");
})