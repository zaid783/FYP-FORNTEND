﻿import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");


// INITIALIZING VARIBALES
var end_point;

var formActionSpinners = $(".btn-spinner");
const uploadButton = $('#Upload_Attendance_btn');
var modalActionSpinners = $(".modal-spinner");

var url = new URLSearchParams(window.location.search);
var menuId = '';

if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/AdminAccess';
    discon();
});


// DISCONNECTION FUNCTION
function discon() {
    Onload();
}

$('#custom_upload_button').on('click', function () {
    $('#upload_dat_file').click();
});

$('#custom_upload_button_emp').on('click', function () {
    $('#upload_xlsx_file').click();
});
// Update the file name display when a file is chosen
$('#upload_dat_file').on('change', function () {
    var fileName = this.files[0].name;
    var fileExtension = fileName.split('.').pop().toLowerCase();

    if (fileExtension !== 'dat') {
        alert('Only .dat files are allowed!');
        this.value = ''; // Clear the input
        document.getElementById('file_name').innerText = 'No file chosen';
    } else {
        document.getElementById('file_name').innerText = fileName;
    }
});
$('#upload_xlsx_file').on('change', function () {
    var fileName = this.files[0].name;
    var fileExtension = fileName.split('.').pop().toLowerCase();
    
    if (fileExtension !== 'xlsx') {
        alert('Only .xlsx files are allowed!');
        this.value = ''; // Clear the input
        document.getElementById('file_name2').innerText = 'No file chosen';
    } else {
        document.getElementById('file_name2').innerText = fileName;
    }
});

$('#Upload_Attendance_btn').on('click', function () {
    // Get the file input element
    var jsonData;
    var fileInput = document.getElementById('upload_dat_file');
    

    // Ensure a file is selected
    if (fileInput.files.length === 0) {
        alert('Please select a .dat file to upload.');
        return;
    }

    // Get the selected file
    var file = fileInput.files[0];
    //console.log(fileInput.files[0]);

    // Ensure it's a .dat file
    if (file.type !== '' && !file.name.endsWith('.dat')) {
        alert('Only .dat files are allowed.');
        return;
    }

    //formActionSpinners.show();
    uploadButton.prop('disabled', true);
    file.text().then(function (fileData) {
        jsonData = JSON.stringify({
            "fileContent": fileData
        });
        POST(end_point + "/UploadAttendance", jsonData, function () {
            discon();
            uploadButton.prop('disabled', false);
        }, formActionSpinners);

       
         
    }).catch(function (error) {
        console.error('Error reading file:', error);
        uploadButton.prop('disabled', false);
        //formActionSpinners.addClass('d-none');
        //formActionSpinners.hide();
});

    // Send the file to the server via an AJAX request (fetch API in this case)
   
});

$('#Upload_Employee_btn').on('click', function () {
    var fileInput = document.getElementById('upload_xlsx_file');
    var uploadButton = $(this);

    if (fileInput.files.length === 0) {
        alert('Please select an .xlsx file to upload.');
        return;
    }

    var file = fileInput.files[0];

    if (file.type !== '' && !file.name.endsWith('.xlsx')) {
        alert('Only .xlsx files are allowed.');
        return;
    }

    uploadButton.prop('disabled', true);

    var reader = new FileReader();

    reader.onload = function (e) {
        var data = new Uint8Array(e.target.result);
        var workbook = XLSX.read(data, { type: 'array' });
        var sheetName = workbook.SheetNames[0];
        var worksheet = workbook.Sheets[sheetName];

        // Convert sheet to JSON
        var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        // Transform into the desired JSON structure
        var formattedData = {
            ColumnNames: jsonData[0], // First row contains the column headers
            Rows: []                  // Rows array
        };

        for (var i = 1; i < jsonData.length; i++) {
            var row = jsonData[i];

            // Check if the Date of Birth is a serial number and convert it
            var dobRaw = row[9]; // Assuming the date of birth is in the 10th column
            var dobFormatted = dobRaw;

            if (typeof dobRaw === 'number') {
                dobFormatted = convertExcelDate(dobRaw); // Convert Excel serial number to a date string
            }

            // Replace the raw date of birth with the formatted date
            row[9] = dobFormatted;

            formattedData.Rows.push(row);
        }

        // JSON string
        var finalJson = JSON.stringify(formattedData, null, 2);
       // console.log("final json:");
       // console.log(finalJson);  // Debugging

        // Now send the finalJson data via a POST request
        POST(end_point + "/UploadEmployee", finalJson, function () {
            discon();
            uploadButton.prop('disabled', false);
            $('#Upload_Employee_btn').prop('disabled', false);
            $('#Upload_Attendance_btn').prop('disabled', false);
        }, formActionSpinners);
    };

    reader.onerror = function (error) {
        console.error('Error reading file:', error);
        $('#Upload_Employee_btn').prop('disabled', false);
        $('#Upload_Attendance_btn').prop('disabled', false);
    };

    // Read the file as binary
    $('#Upload_Employee_btn').prop('disabled', false);
    $('#Upload_Attendance_btn').prop('disabled', false);
});

function convertExcelDate(serial) {
    var utc_days = Math.floor(serial - 25569); // Excel serial dates start on 1st Jan 1900, hence 25569
    var utc_value = utc_days * 86400; // Convert days to seconds
    var date_info = new Date(utc_value * 1000); // Convert to milliseconds

    // Format date to YYYY-MM-DD
    var year = date_info.getFullYear();
    var month = ('0' + (date_info.getMonth() + 1)).slice(-2); // Months are 0-based
    var day = ('0' + date_info.getDate()).slice(-2);

    return year + '-' + month + '-' + day;
}
function ParseData(fileData) {
    console.log("HERE");
    const lines = fileData.split('\n');
    const parsedData = [];


    for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line != '') {
            const data = {
                value: line
            };
            parsedData.push(data);
        }
    }
    return parsedData
}

// ONLOAD FUNCTION
function Onload() {
    $('#Upload_Employee_btn').prop('disabled', false);
    $('#Upload_Attendance_btn').prop('disabled', false);
    var tbl_row_cnt = 1;
    $.ajax({
        url: GETAPIURL(end_point + "/GetCurrentRecordsCount"),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            formActionSpinners.css("display", "none");
            $("#button_msg").css("display", "block");
            if (response != null) {
                if (response.statusCode == "200") {
                    var data = response.data;
                    $("#count_holidays").text(data.holidaysCount);
                    $("#count_roster").text(data.rostersCount);
                    $("#count_loans").text(data.loansCount);
                    $("#count_advances").text(data.advancesCount);
                    $("#count_loginaudits").text(data.loginAuditCount);
                    $("#count_attendance").text(data.attendanceCount);
                    $("#count_leaves").text(data.leavesCount);
                    $("#count_employees").text(data.employeesCount);
                    $("#count_shifts").text(data.shiftsCount);
                    $("#count_policy").text(data.policiesCount);
                    $("#count_allowances").text(data.allowancesCount);
                    $("#count_banks").text(data.banksCount);
                    $("#count_bloodgroups").text(data.bloodGroupsCount);
                    $("#count_city").text(data.citiesCount);
                    $("#count_country").text(data.countriesCount);
                    $("#count_deductions").text(data.deductionsCount);
                    $("#count_departments").text(data.departmentsCount);
                    $("#count_designations").text(data.desginationsCount);
                    $("#count_branches").text(data.branchesCount);
                    $("#count_status").text(data.statusCount);
                    $("#count_genders").text(data.gendersCount);
                    $("#count_inout").text(data.inoutCount);
                    $("#count_marital").text(data.maritalCount);
                    $("#count_qualification").text(data.qualificationsCount);
                    $("#count_relation").text(data.relationsCount);
                }
            }


        },
        error: function (xhr, status, err) {
            formActionSpinners.css("display", "none");
            $("#button_msg").css("display", "block");
            Swal.fire({
                icon: 'error',
                text: "Failed to clear the selected database."
            });
        }
    })
    return true;
}


function FlushEntity(tableName, prereq) {
    Swal.fire({
        title: 'Warning',
        icon: 'warning',
        text: `Are you sure you want to clear this table? The following tables will be cleared as well: ${prereq} (Clear Manually)`,
        showCancelButton: true,
        confirmButtonColor: "#DC3545",
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: GETAPIURL(end_point + "/FlushEntity"),
                    type: "GET",
                    contentType: "application/json",
                    dataType: "json",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                        xhr.setRequestHeader('_TableName', tableName);
                    },
                    success: function (response) {
                        if (response != null) {
                            if (response.statusCode == "200") {
                                if (response.message == "CLEARED") {
                                    Swal.fire({
                                        icon: 'success',
                                        text: response.data
                                    });
                                    Onload();
                                }
                            }
                            else if (response.statusCode == "405") {
                                Swal.fire({
                                    icon: 'error',
                                    title: "Failed",
                                    text: "Please clear dependent tables initially to proceed!"
                                });
                            }
                            else {
                                Swal.fire({
                                    icon: 'error',
                                    text: response.data
                                });
                            }
                        }
                    },
                    error: function (xhr, status, err) {
                        Swal.fire({
                            icon: 'error',
                            text: "Failed to clear the selected database."
                        });
                    }
                })
            } else {
                formActionSpinners.css("display", "none");
                $("#button_msg").css("display", "block");
            }
        })

    return true;
}

$("#btn_emptydatabase").on("click", () => {
    formActionSpinners.css("display", "block");
    $("#button_msg").css("display", "none");
    FlushEntity("ALL", "");
});
// BTN EVENT HANDLERS -- MODULES
$("#btn_module_loginaudit").on("click", () => {
    FlushEntity("LOGINAUDIT", "-");
})
$("#btn_module_holidays").on("click", () => {
    FlushEntity("HOLIDAY", "-");
})
$("#btn_module_roster").on("click", () => {
    FlushEntity("ROSTER", "RosterEvents, EmployeeRoster");
})
$("#btn_module_loans").on("click", () => {
    FlushEntity("LOAN", "EmployeeLoan, EmployeeLoanInstallements");
})
$("#btn_module_advances").on("click", () => {
    FlushEntity("ADVANCE", "-");
})
$("#btn_module_attendance").on("click", () => {
    FlushEntity("ATTENDANCE", "-");
})
$("#btn_module_leaves").on("click", () => {
    FlushEntity("LEAVE", "LeaveRequests, LeavePolicies, LeaveTypes");
})
$("#btn_module_employees").on("click", () => {
    FlushEntity("EMPLOYEE", "AdvanceSalary, UserEventLogs");
})
$("#btn_module_shifts").on("click", () => {
    FlushEntity("SHIFT", "-");
})
$("#btn_module_policies").on("click", () => {
    FlushEntity("POLICY", "-");
})

// CONFIGURATION
$("#btn_config_allowances").on("click", () => {
    FlushEntity("ALLOWANCE", "PersonalInformation");
})
$("#btn_config_banks").on("click", () => {
    FlushEntity("BANK", "PersonalInformation");
})
$("#btn_config_bloodgroups").on("click", () => {
    FlushEntity("BLOODGROUP", "PersonalInformation");
})
$("#btn_config_cities").on("click", () => {
    FlushEntity("CITY", "PersonalInformation");
})
$("#btn_config_countries").on("click", () => {
    FlushEntity("COUNTRY", "PersonalInformation");
})
$("#btn_config_deductions").on("click", () => {
    FlushEntity("DEDUCTION", "PersonalInformation");
})
$("#btn_config_departments").on("click", () => {
    FlushEntity("DEPARTMENT", "PersonalInformation");
})
$("#btn_config_designations").on("click", () => {
    FlushEntity("DESIGNATION", "PersonalInformation");
})
$("#btn_config_empbranch").on("click", () => {
    FlushEntity("BRANCH", "PersonalInformation");
})
$("#btn_config_empstatus").on("click", () => {
    FlushEntity("STATUS", "PersonalInformation");
})
$("#btn_config_empgenders").on("click", () => {
    FlushEntity("GENDER", "PersonalInformation");
})
$("#btn_config_inoutexemption").on("click", () => {
    FlushEntity("INOUT", "PersonalInformation");
})
$("#btn_config_maritalstatus").on("click", () => {
    FlushEntity("MARTITALSTATUS", "PersonalInformation");
})
$("#btn_config_qualifications").on("click", () => {
    FlushEntity("QUALIFICATION", "PersonalInformation");
})
$("#btn_config_relations").on("click", () => {
    FlushEntity("RELATION", "PersonalInformation");
})