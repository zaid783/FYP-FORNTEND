﻿
document.addEventListener("DOMContentLoaded", () => {
    fetchAndInitialize();
    setupEventListeners();


    setInterval(() => {
        console.log("♻️ Auto-refreshing ATG data...");
        fetchAndInitialize();
    }, 30000);
});

let tankData = [];
let currentPage = 1;
const pageSize = 4;
let isFetching = false; 

const apiBaseUrl = "http://localhost:7085";

function getFuelColor(percentage) {
    if (percentage <= 20) return "darkred";
    if (percentage <= 50) return "blue";
    if (percentage <= 80) return "goldenrod";
    return "darkgreen";
}

async function fetchAndInitialize() {
    if (isFetching) {
        console.warn("⚠️ Fetch already in progress, skipping this tick...");
        return;
    }

    isFetching = true;
    console.log("🔄 Fetching ATG data from", `${apiBaseUrl}/api/sensordata/atg-monitoring`);

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/atg-monitoring`);
        console.log("📡 Response status:", response.status);

        if (!response.ok) throw new Error("❌ Network response was not ok");

        const data = await response.json();
        console.log("✅ ATG Data received:", data);

        tankData = data.data_table.map(item => ({
            id: convertTankIdToDomId(item.tank_id),
            tank_id: item.tank_id,
            fuel: item.fuel_type,
            capacity: item.capacity_liters,
            current: item.current_volume,
            updatedAt: item.last_update
        }));

        initTankDisplay();
        populateTankTable();

    } catch (error) {
        console.error("🚨 Failed to load ATG data:", error);
    } finally {
        isFetching = false;
    }
}

function convertTankIdToDomId(tankId) {
    const map = {
        "Tank 1": "tank1",
        "Tank 2": "tank2",
        "Tank 3": "tank3",
        "Tank 4": "tank4"
    };
    return map[tankId] || tankId.toLowerCase().replace(/\s/g, '');
}

function initTankDisplay() {
    tankData.forEach(tank => {
        const fillDiv = document.getElementById(tank.id);
        if (fillDiv) {
            const percentage = Math.round((tank.current / tank.capacity) * 100);

            // ⛔️ Skip update if percentage hasn't changed
            if (fillDiv.dataset.percentage !== String(percentage)) {
                fillDiv.style.height = percentage + "%";
                fillDiv.style.backgroundColor = getFuelColor(percentage);

                const text = fillDiv.querySelector(".fuel-text");
                if (text) text.innerText = percentage + "%";

                fillDiv.dataset.percentage = percentage;
            }
        }
    });
}

function populateTankTable() {
    const tbody = document.getElementById("tankTableBody");
    tbody.innerHTML = "";

    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const paginatedData = tankData.slice(start, end);

    paginatedData.forEach(tank => {
        const percentage = Math.round((tank.current / tank.capacity) * 100);
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${tank.tank_id}</td>
            <td>${tank.fuel}</td>
            <td>${tank.capacity}</td>
            <td>${tank.current}</td>
            <td>${percentage}%</td>
            <td>${tank.updatedAt}</td>
        `;
        tbody.appendChild(row);
    });

    updatePaginationInfo();
}

function updatePaginationInfo() {
    const info = document.getElementById("paginationInfo");
    const start = (currentPage - 1) * pageSize + 1;
    const end = Math.min(currentPage * pageSize, tankData.length);
    info.innerText = `Showing ${start} to ${end} of ${tankData.length} entries`;

    document.getElementById("prevBtn").disabled = currentPage === 1;
    document.getElementById("nextBtn").disabled = end >= tankData.length;
}

function setupEventListeners() {
    document.getElementById("prevBtn").addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            populateTankTable();
        }
    });

    document.getElementById("nextBtn").addEventListener("click", () => {
        if (currentPage * pageSize < tankData.length) {
            currentPage++;
            populateTankTable();
        }
    });
}

