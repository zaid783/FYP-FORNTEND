import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR, FILLCOMBO } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALES
var end_point;
var btn_login = $('#btn_login');

var formActionSpinners = $(".btn-spinner");
var btn_login = $("#btn_login");
// jQuery CONSTRUCTOR
$(document).ready(function () {
    localStorage.clear()
    end_point = '/AuthService';
    discon();
});


// DISCONNECTION FUNCTION
function discon() {
    formActionSpinners.css("display", "none");
    btn_login.css("display", "block");
    CLEAR();
}

// // VALIDATION FUNCTION
function ckvalidation() {
    formActionSpinners.css("display", "block");
    btn_login.css("display", "none");

    var ck = 0, _Error = '', _cre = '', id = '';

    var txt_role = $('#txt_role');
    var txt_Email = $('#txt_email');
    var txt_Password = $('#txt_password');

    if (txt_Password.val() == '') {
        ck = 1;
        _Error = 'Please enter a valid password';
        txt_Password.focus();
    }
    if (txt_Email.val() == '') {
        ck = 1;
        _Error = 'Please enter a valid email!';
        txt_Email.focus();
    }
    if (txt_role.val() == '') {
        ck = 1;
        _Error = 'Please enter Vendor Type';
        txt_role.focus();
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            // "roleId": txt_role.val(),
            "email": txt_Email.val(),
            "password": txt_Password.val(),
        });
    }
    return { ckval: ck, creteria: _cre };
}

// ADD BUTTON EVENT
$('fieldset').on('click', '#btn_login', function (e) {
    btn_login.prop("disabled", true);
    Login();
});

function Login() {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;

    $.ajax({
        url: apiUrl + end_point + '/UserLogin',
        type: "Post",
        contentType: "application/json",
        dataType: "json",
        data: _cre,
        success: function (response) {
            btn_login.prop("disabled", false);

            if (response.statusCode == 200) {
                formActionSpinners.css("display", "none");
                btn_login.css("display", "block");

                localStorage.setItem("Id", response.data.id)
                localStorage.setItem("UserName", response.data.firstName + " " + response.data.lastName)
                localStorage.setItem("Phone", response.data.contact)
                localStorage.setItem("Email", response.data.email)
                localStorage.setItem(api_signature, response.message)
                if (response.data.roleName.toLowerCase() == "employee") {
                    localStorage.setItem("Role", "Employee");
                    window.location.href = '/Dashboard/EmployeeAnalytics';
                    return;
                }
                else {
                    localStorage.setItem('Role', "Admin");
                    window.location.href = '/Dashboard/Analytics';
                    return;
                }
            }
            else {
                btn_login.prop("disabled", false);
                formActionSpinners.css("display", "none");
                btn_login.css("display", "block");
                Swal.fire({
                    title: response.message,
                    icon: 'warning',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                })
            }
        },
        error: function (xhr, status, err) {
            btn_login.prop("disabled", false);
            formActionSpinners.css("display", "none");
            btn_login.css("display", "block");

            Swal.fire({
                title: "Server Error",
                width: 800,
                text: "Failed to reach server. Please check your internet connection!",
                icon: 'error',
                showConfirmButton: true,
            })
        }
    })
}

var input = document.getElementById("txt_password");
input.addEventListener("keyup", function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        btn_login.prop("disabled", true);
        Login();
    }
});
document.addEventListener('DOMContentLoaded', function () {
    particlesJS('particles-js', {
        particles: {
            number: { value: 50 },
            color: { value: '#000000' },
            shape: { type: 'circle' },
        },
    });
});
