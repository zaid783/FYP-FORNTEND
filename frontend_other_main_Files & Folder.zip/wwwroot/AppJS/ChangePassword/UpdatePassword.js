﻿import { CLEAR, PUT } from "../Service/ApiService.js";

var end_point;
var btn_chngpass = $('#btn_chngpass');
var formActionSpinners = $(".btn-spinner");


$(document).ready(function () {
    end_point = "/AuthService";
    CLEAR();
});


function ckvalidation() {
    
    btn_chngpass.css("display", "none");

    var ck = 0, _Error = '', _cre = '';

    var currentPassword = $('#currentPassword');
    var newPassword = $('#newPassword');
    var confirmPassword = $('#confirmPassword');

    if (currentPassword.val() == '') {
        ck = 1;
        _Error = "Current Password field is empty";
    }
    else if (newPassword.val() == '') {
        ck = 1;
        _Error = "New Password field is empty";
    }
    else if (confirmPassword.val() == '') {
        ck = 1;
        _Error = "Current Password filed is empty";
    }
    else if (newPassword.val() != confirmPassword.val()) {
        ck = 1;
        _Error = "Password does not match! ";
    }
    else if (newPassword.val() != '') {
        var passwordformate = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
        if (!newPassword.val().match(passwordformate)) {
            ck = 1;
            _Error = 'Check your password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character';
        }
    }
    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: "error"
        })
    }
    else if (!Boolean(ck)) {
        var userEmail = localStorage.getItem('Email');

        _cre = JSON.stringify({
            "email": userEmail,
            "currentPassword": currentPassword.val(),
            "newPassword": newPassword.val(),

        });        
    }

    return { ckval: ck, creteria: _cre };
    
}

//Change Password Button Even
$('form').on('click', '#btn_chngpass', function (e) {
    btn_chngpass.prop("disabled", true);
    changepassword();
    CLEAR();
    btn_chngpass.prop("disabled", false);
    btn_chngpass.css("display", "block");
});
function changepassword() {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) {
        return;
    }
    var _cre = ck.creteria;

    PUT(end_point + "/UpdatePassword", _cre, function () {
        CLEAR();
        btn_chngpass.css("display", "block");  
    }, formActionSpinners);
 }

var input = document.getElementById("confirmPassword");
input.addEventListener("keyup", function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        btn_chngpass.prop("disabled", true);
        changepassword();
    }
});
