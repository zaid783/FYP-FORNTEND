import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')


var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/BonusSlab';

    // Trigger change event on page load to set initial state
    $('#sel_Add_bonus').trigger('change');
    discon();
});

$('#openmodal').on('click', function (e) {
    var code = $("#txt_code").val()
    clearModal();
    CLEAR();
    btn_update.hide();
    btn_save.show()
    $("#txt_code").val(code)
});

const clearModal = () => {
    $('input[type="text"]').val('');
    $('.error-icon').css('display', 'none');
}


// DISCONNECTION FUNCTION
function discon() {
    var code = $("#txt_code").val()
    Onload(); CLEAR(); btn_update.hide(); btn_save.show()
    $("#txt_code").val(code)
}


// PATCHING DATA FUNCTION
function patchdata(response) {
    formActionSpinners.css("display", "none");
    modalActionSpinners.css("display", "none");

    $('#txt_id').val(response.id);
    $('#txt_code').val(response.code);
    $('#txt_name').val(response.name);
    $('#rangeFrom').val(response.salaryFrom);
    $('#rangeTo').val(response.salaryTo);
    $('#BonusAmount').val(response.amount);
    $('#sel_Add_bonus').val(response.amountType)

    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var txt_id = $('#txt_id');
    var txt_code = $('#txt_code');
    var txt_name = $('#txt_name');
    var salaryFrom = $('#rangeFrom');
    var salaryTo = $('#rangeTo');
    var amount = $('#BonusAmount');
    var amountType = $('#sel_Add_bonus');
    var ck_act = $('#ck_act');

    if (txt_name.val() == '') {
        ck = 1;
        _Error = 'Please Enter Bonus Name';
        txt_name.focus();
    }

    if (txt_code.val() == '') {
        ck = 1;
        _Error = 'Please Enter Code ';
        txt_code.focus();
    }

    if (txt_id.val() == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id.val()
    }
    // Validation for Range From
    if (salaryFrom.val().trim() == '' || isNaN(salaryFrom.val()) || parseInt(salaryFrom.val()) <= 0) {
        ck = 1;
        _Error = 'Please Enter a valid Range From (a non-negative number)';
        salaryFrom.focus();
    }

    // Validation for Range To
    if (salaryTo.val().trim() == '' || isNaN(salaryTo.val()) || parseInt(salaryTo.val()) <= 0) {
        ck = 1;
        _Error = 'Please Enter a valid Range To (a non-negative number)';
        salaryTo.focus();
    }

    // Validation to ensure Range From <= Range To
    if (parseInt(salaryFrom.val()) > parseInt(salaryTo.val())) {
        ck = 1;
        _Error = 'Range From cannot be greater than Range To';
        salaryFrom.focus();
    }

    // Validation for Bonus Amount
    if (amount.val().trim() == '' || isNaN(amount.val()) || parseFloat(amount.val()) <= 0) {
        ck = 1;
        _Error = 'Please Enter a valid Bonus Amount (a positive number)';
        amount.focus();
    }
    //Validation for Amount Type
    if (amountType.val() == '') {
        ck = 1;
        _Error = 'Please Select Any of The Amount Type';
        amountType.focus();
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "code": txt_code.val(),
            "name": txt_name.val(),
            "active": ck_act[0].checked,
            "salaryFrom": salaryFrom.val(),
            "salaryTo": salaryTo.val(),
            "amount": amount.val(),
            "amountType": amountType.val(),
            "type": "U",
            "menuId": menuId


        });
    }
    return { ckval: ck, creteria: _cre };
}


// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    //console
    console.log(GETAPIURL(end_point + "/GetBonuses"));
    console.log("Menu ID:", menuId);

    $.ajax({
        url: GETAPIURL(end_point + "/GetBonuses"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            console.log("API Response:", response);
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.permissions.update_Permission) {
                    action_button += "<a href='#' class='btn-edit fas fa-edit' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                }
                if (response.permissions.delete_Permission) {
                    action_button += " <a href='#' class='btn-delete fas  fa-trash' data-toggle='tooltip' style='color:#2c445c' title='Delete()'></a> ";
                }
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return meta.row + 1; } },
                            { data: 'code' },
                            { data: 'name' },
                            { data: 'salaryFrom' },
                            { data: 'salaryTo' },
                            { data: 'amount' },
                            { data: 'amountType' },
                            { data: 'active', 'render': function (data, type, full, meta) { if (data) { return '✔'; } else { return '✘'; } } },
                            { data: null, "defaultContent": action_button },
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    $("#txt_code").val(response.data[0].lastCode)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").val(1)
                }
            }


        },
        error: function (xhr, status, err) {
            console.log("Error Status:", status);
            console.log("XHR Object:", xhr);
            console.log("Error:", err);
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}


// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddBonuses", _cre, function () {
        discon();
    }, formActionSpinners);
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateBonuses", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['name'];
    var type = data['type'];

    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.show(); btn_save.hide()
    await GETBYID(end_point + "/GetBonusesById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))

});

// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    DELETE(end_point + "/DeleteBonuses", _Id, _name, function () {
        Onload();
    })
});

$('#sel_Add_bonus').change(function () {
    var BonusAmountInput = $('#BonusAmount');

    if ($(this).val() == 'Percentage') {
        // Update placeholder when "Percentage" is selected
        BonusAmountInput.attr('placeholder', 'Max 90%');

        // Add max attribute and set validation
        BonusAmountInput.attr('max', 90);
        BonusAmountInput.attr('oninput', 'if(this.value > 90) this.value = 90;');
    } else {
        // Reset placeholder when "Amount" is selected
        BonusAmountInput.attr('placeholder', '1000....');

        // Remove max attribute and input validation for Amount
        BonusAmountInput.removeAttr('max');
        BonusAmountInput.removeAttr('oninput');
    }
});



/*var response = {
    data: [
        { code: 'A001', name: 'Item 1', rangeFrom: 1000, rangeTo: 2000, tax: 150, active: true },
        { code: 'A002', name: 'Item 2', rangeFrom: 2000, rangeTo: 3000, tax: 250, active: false },
        { code: 'A003', name: 'Item 3', rangeFrom: 3000, rangeTo: 4000, tax: 350, active: true }
    ]
};

if (loaderIcon) {
    loaderIcon.style.display = "none";
    $('#data_table').DataTable().clear().destroy();

    var datatablesButtons = $("#data_table").DataTable({
        data: response.data,
        destroy: true,
        retrieve: true,
        processing: true,
        lengthChange: false,
        buttons: ["pdf", "copy", "print", "csv"],
        columns: [
            { "render": function (data, type, full, meta) { return meta.row + 1; } }, // S# (auto-incremented row number)
            { data: 'code' }, // Code
            { data: 'name' }, // Name
            { data: 'rangeFrom' }, // Range From
            { data: 'rangeTo' }, // Range To
            { data: 'tax' }, // Tax Amount
            {
                data: 'active',
                'render': function (data, type, full, meta) {
                    return data ? 'âœ”' : 'âœ˜'; // Active
                }
            }
            //{
            //    data: null,
            //    "defaultContent": '<button class="btn btn-primary btn-sm">Action</button>' // Action button
            //}
        ],
        "order": [[0, "asc"]], // Default order by S#
    });

    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)");

    // Simulate setting the lastCode value
    $("#txt_code").val(response.data[0].code);
}

}*/


