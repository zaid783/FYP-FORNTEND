import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')


var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}



 //jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/DocumentType';

    $('#sel_Extention_type').select2({
        //width: '100%',
        //placeholder: "Select Extension Type"
    });
    
    $('#sel_Extention_type').trigger('change');
    discon();
});




$('#openmodal').on('click', function (e) {
    var code = $("#txt_code").val()
    clearModal();
    CLEAR();
    btn_update.hide();
    btn_save.show()
    $("#txt_code").val(code)
});

const clearModal = () => {
    $('input[type="text"]').val('');
    $('select').val([]).trigger('change');
    $('.error-icon').css('display', 'none');
}


// DISCONNECTION FUNCTION
function discon() {
    var code = $("#txt_code").val()
    Onload(); CLEAR(); btn_update.hide(); btn_save.show()
    $("#txt_code").val(code)
}


// PATCHING DATA FUNCTION
function patchdata(response) {
    formActionSpinners.css("display", "none");
    modalActionSpinners.css("display", "none");

    $('#txt_id').val(response.id);
    $('#txt_code').val(response.code);
    $('#txt_name').val(response.name);
    if (response.extentionType.includes(',')) {
        $('#sel_Extention_type').val(response.extentionType.split(',')).trigger('change');
    }
    else {
        $('#sel_Extention_type').val(response.extentionType).trigger('change');
    }
    //$('#sel_Extention_type').val(response.extentionType);
     
    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}


let existingNames = new Set(); 

function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var txt_id = $('#txt_id');
    var txt_code = $('#txt_code');
    var txt_name = $('#txt_name');
    var extentionType = $('#sel_Extention_type');
    var ck_act = $('#ck_act');

    // Validate Document Name
    if (txt_name.val().trim() === '') {
        ck = 1;
        _Error = 'Please Enter Document Name';
        txt_name.focus();
    }
    else if (existingNames.has(txt_name.val().trim())) {
        ck = 1;
        _Error = 'Document Name Already Exists';
        txt_name.focus();
    }

    if (txt_code.val().trim() === '') {
        ck = 1;
        _Error = 'Please Enter Code';
        txt_code.focus();
    }
    
    if (txt_id.val().trim() === '') {
        id = '00000000-0000-0000-0000-000000000000';
    } else {
        id = txt_id.val();
    }
    
    if (extentionType.val() === '') {
        ck = 1;
        _Error = 'Please Select Any of The Extension Type';
        extentionType.focus();
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        });
    } else {
        // Prepare the criteria for Add or Update
        _cre = JSON.stringify({
            "id": id,
            "code": txt_code.val().trim(),
            "name": txt_name.val().trim(),
            "active": ck_act[0].checked,
            "extentionType": extentionType.val().toString(),
            "type": "U", // or "A" for Add operation
            "menuId": menuId
        });
    }

    return { ckval: ck, creteria: _cre };
}

function Onload() {
    var tbl_row_cnt = 1;
    //console
    console.log(GETAPIURL(end_point + "/GetDocumentType"));
    console.log("Menu ID:", menuId);

    $.ajax({
        url: GETAPIURL(end_point + "/GetDocumentType"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            console.log("API Response:", response);
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.permissions.update_Permission) {
                    action_button += "<a href='#' class='btn-edit fas fa-edit' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                }
                if (response.permissions.delete_Permission) {
                    action_button += " <a href='#' class='btn-delete fas  fa-trash' data-toggle='tooltip' style='color:#2c445c' title='Delete()'></a> ";
                }
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return meta.row + 1; } },
                            { data: 'code' },
                            { data: 'name' },
                            { data: 'extentionType' },
                            { data: 'active', 'render': function (data, type, full, meta) { if (data) { return '✔'; } else { return '✘'; } } },
                            { data: null, "defaultContent": action_button },
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    $("#txt_code").val(response.data[0].lastCode)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").val(1)
                }
            }


        },
        error: function (xhr, status, err) {
            console.log("Error Status:", status);
            console.log("XHR Object:", xhr);
            console.log("Error:", err);
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}


// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    console.log(GETAPIURL(end_point + "/AddDocumentType"));
    POST(end_point + "/AddDocumentType", _cre, function () {
        discon();
    }, formActionSpinners);
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateDocumentType", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['name'];
    var type = data['type'];

    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.show(); btn_save.hide()
    await GETBYID(end_point + "/GetDocumentTypeById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))

});




// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    DELETE(end_point + "/DeleteDocumentType", _Id, _name, function () {
        Onload();
    })
});

$('#sel_Extention_type').change(function () {
    var selectedValue = $(this).val();
    console.log("Selected Value")
    console.log(selectedValue)
    // Update placeholder for PDF and DOCX
    if (selectedValue === 'pdf' || selectedValue === 'docx') {
        $('#txt_name').attr('placeholder', 'Enter Name for ' + selectedValue + ' Document');
    }
    // Update placeholder for JPG and PNG
    else if (selectedValue === '.jpg' || selectedValue === '.png') {
        $('#txt_name').attr('placeholder', 'Enter Name for ' + selectedValue + ' Image');
    }
    // Default placeholder for unmatched values
    else {
        $('#txt_name').attr('placeholder', 'Enter Document Name');
    }
});






