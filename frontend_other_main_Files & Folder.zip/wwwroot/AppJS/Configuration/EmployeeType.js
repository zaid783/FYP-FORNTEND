import  {GETAPIURL,GETBYID,POST,PUT,DELETE,CLEAR}  from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALE
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')

var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () {  
    end_point = '/api/v1/EmployeeType';
    discon();
});


$('#openmodal').on('click', function (e) {
    var code = $("#txt_code").val()
    clearModal();
    CLEAR();
    btn_update.hide();
    btn_save.show()
    $("#txt_code").val(code)
});

const clearModal = () => {
    $('input[type="text"]').val('');
    $('.error-icon').css('display', 'none');
}

// DISCONNECTION FUNCTION
function discon(){
    var code = $("#txt_code").val()
    Onload();CLEAR();btn_update.hide();btn_save.show()
    $("#txt_code").val(code)
}


// PATCHING DATA FUNCTION
function patchdata(response) {
    formActionSpinners.css("display", "none");
    modalActionSpinners.css("display", "none");

    $('#txt_id').val(response.id);
    $('#txt_code').val(response.code);
    $('#txt_name').val(response.name);
    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '' ,id='';
    var txt_id = $('#txt_id');  
    var txt_code = $('#txt_code');   
    var txt_name = $('#txt_name');   
    var ck_act = $('#ck_act'); 
    
    if (txt_name.val() == '') {
        ck = 1;
        _Error = 'Please Enter EmployeeType Name';
        txt_name.focus();
    }
    
    if (txt_code.val() == '') {
        ck = 1;
        _Error = 'Please Enter Code ';
        txt_code.focus();
    }
    
    if (txt_id.val() == '') {
        id= '00000000-0000-0000-0000-000000000000'
    }
    else{
        id = txt_id.val()
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "code": txt_code.val(),
            "name": txt_name.val(),
            "active": ck_act[0].checked,
            "type": "U",
            "menuId": menuId
        });
    }
    return { ckval: ck, creteria: _cre };
}


// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    $.ajax({
        url: GETAPIURL(end_point + "/GetEmployeeType"), 
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function(xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.permissions.update_Permission) {
                    action_button += "<a href='#' class='btn-edit fas fa-edit' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                }
                if (response.permissions.delete_Permission) {
                    action_button += " <a href='#' class='btn-delete fas  fa-trash' data-toggle='tooltip' style='color:#2c445c' title='Delete()'></a> ";
                }
                if (response.data != null) {
                    $('#empdata_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#empdata_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange:!1,
                        buttons: ["pdf","copy", "print","csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; }},
                            { data: 'code' },
                            { data: 'name' },
                            { data: 'active','render': function (data, type, full, meta) {if (data) {return '✔'; }else { return '✘'; }  }},
                            { data: null,"defaultContent": action_button},
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")    
                    $("#txt_code").val(response.data[0].lastCode)
                }else{
                    $('#empdata_table').DataTable().clear().destroy();
                    $("#empdata_table").DataTable();
                    $("#txt_code").val(1)
                }
            }
            
            
        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                width:800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}

// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddEmployeeType",_cre,function () {
        discon();
    }, formActionSpinners);
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateEmployeeType",_cre,function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#empdata_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.show();btn_save.hide()
    await GETBYID(end_point + "/GetEmployeeTypeById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))
});

// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#empdata_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    DELETE(end_point + "/DeleteEmployeeType",_Id,_name,function () {
        Onload();
    })
});

