import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')


var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/TaxSlab';
    $('#sel_tax_bonus').trigger('change');
    discon();
});

$('#openmodal').on('click', function (e) {
    var code = $("#txt_code").val()
    clearModal();
    CLEAR();
    btn_update.hide();
    btn_save.show()
    $("#txt_code").val(code)
});

const clearModal = () => {
    $('input[type="text"]').val('');
    $('.error-icon').css('display', 'none');
}


// DISCONNECTION FUNCTION
function discon() {
    var code = $("#txt_code").val()
    Onload(); CLEAR(); btn_update.hide(); btn_save.show()
    $("#txt_code").val(code)
}


// PATCHING DATA FUNCTION
function patchdata(response) {
    formActionSpinners.css("display", "none");
    modalActionSpinners.css("display", "none");

    $('#txt_id').val(response.id);
    $('#txt_code').val(response.code);
    $('#txt_name').val(response.name);
    $('#rangeFrom').val(response.rangeFrom);
    $('#rangeTo').val(response.rangeTo);
    $('#taxAmount').val(response.amount);
    $('#sel_tax_bonus').val(response.amountType)

    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var txt_id = $('#txt_id');
    var txt_code = $('#txt_code');
    var txt_name = $('#txt_name');
    var rangeFrom = $('#rangeFrom');
    var rangeTo = $('#rangeTo');
    var amount = $('#taxAmount');
    var amountType = $('#sel_tax_bonus');
    var ck_act = $('#ck_act');

    if (txt_name.val() == '') {
        console.log(txt_name.val() == '');
        ck = 1;
        _Error = 'Please Enter TaxSlab Name';
        txt_name.focus();
    }

    if (txt_code.val() == '') {
        ck = 1;
        _Error = 'Please Enter Code ';
        txt_code.focus();
    }

    if (txt_id.val() == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id.val()
    }
    // Validation for Range From
    if (rangeFrom.val() === '' || isNaN(rangeFrom.val()) || parseFloat(rangeFrom.val()) <= 50000) {
        ck = 1;
        _Error = 'Please Enter a valid "Range From" from 50000';
        rangeFrom.focus();
    }


    // Validation for Range To
    if (rangeTo.val() === '' || isNaN(rangeFrom.val()) || parseFloat(rangeTo.val()) <= 60000) {
        ck = 1;
        _Error = 'Please Enter a valid "Range To" from 60000';
        rangeTo.focus();
    }

    // Validation for Tax Amount
    if (amount.val() == '' || parseFloat(rangeTo.val()) <= 0) {
        ck = 1;
        _Error = 'Please Enter a valid Tax Amount (a positive number)';
        amount.focus();
    }
    //Validation for Amount Type
    if (amountType.val() == '') {
        ck = 1;
        _Error = 'Please Select Any of The Amount Type';
        amountType.focus();
    }
    //Validation for Amount Type
    if (rangeTo.val() < rangeFrom.val()) {
        ck = 1;
        _Error = 'Range From cant be greater than Range To';
        amountType.focus();
    }
    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "code": txt_code.val(),
            "name": txt_name.val(),
            "active": ck_act[0].checked,
            "rangeFrom": rangeFrom.val(),
            "rangeTo": rangeTo.val(),
            "amount": amount.val(),
            "amountType": amountType.val(),
            "type": "U",
            "menuId": menuId


        });
        console.log(_cre);
    }
    return { ckval: ck, creteria: _cre };
}


// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;


    $.ajax({
        url: GETAPIURL(end_point + "/GetTaxSlab"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {

            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                console.log(response)
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.permissions.update_Permission) {
                    action_button += "<a href='#' class='btn-edit fas fa-edit' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                }
                if (response.permissions.delete_Permission) {
                    action_button += " <a href='#' class='btn-delete fas  fa-trash' data-toggle='tooltip' style='color:#2c445c' title='Delete()'></a> ";
                }
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; } },
                            { data: 'code' },
                            { data: 'name' },
                            { data: 'rangeFrom' },
                            { data: 'rangeTo' },
                            { data: 'amount' },
                            { data: 'amountType' },
                            { data: 'active', 'render': function (data, type, full, meta) { if (data) { return '✔'; } else { return '✘'; } } },
                            { data: null, "defaultContent": action_button },
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    $("#txt_code").val(response.data[0].lastCode)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").val(1)
                }
            }


        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}
/*var response = {
    data: [
        { code: 'A001', name: 'Item 1', rangeFrom: 1000, rangeTo: 2000, tax: 150, active: true },
        { code: 'A002', name: 'Item 2', rangeFrom: 2000, rangeTo: 3000, tax: 250, active: false },
        { code: 'A003', name: 'Item 3', rangeFrom: 3000, rangeTo: 4000, tax: 350, active: true }
    ]
};

if (loaderIcon) {
    loaderIcon.style.display = "none";
    $('#data_table').DataTable().clear().destroy();

    var datatablesButtons = $("#data_table").DataTable({
        data: response.data,
        destroy: true,
        retrieve: true,
        processing: true,
        lengthChange: false,
        buttons: ["pdf", "copy", "print", "csv"],
        columns: [
            { "render": function (data, type, full, meta) { return meta.row + 1; } }, // S# (auto-incremented row number)
            { data: 'code' }, // Code
            { data: 'name' }, // Name
            { data: 'rangeFrom' }, // Range From
            { data: 'rangeTo' }, // Range To
            { data: 'tax' }, // Tax Amount
            {
                data: 'active',
                'render': function (data, type, full, meta) {
                    return data ? '✔' : '✘'; // Active
                }
            }
            //{
            //    data: null,
            //    "defaultContent": '<button class="btn btn-primary btn-sm">Action</button>' // Action button
            //}
        ],
        "order": [[0, "asc"]], // Default order by S#
    });

    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)");

    // Simulate setting the lastCode value
    $("#txt_code").val(response.data[0].code);
}

}*/

// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddTaxSLab", _cre, function () {
        discon();
    }, formActionSpinners);
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateTaxSlab", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['name'];
    var type = data['type'];

    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.show(); btn_save.hide()
    await GETBYID(end_point + "/GetTaxSlabById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))

});

// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    DELETE(end_point + "/DeleteTaxSlab", _Id, _name, function () {
        Onload();
    })
});

$('#sel_tax_bonus').change(function () {
    var taxAmountInput = $('#taxAmount');

    if ($(this).val() == 'Percentage') {
        // Update placeholder when "Percentage" is selected
        taxAmountInput.attr('placeholder', 'Max 90%');

        // Add max and min attributes and set validation
        taxAmountInput.attr('max', 90);
        taxAmountInput.attr('min', 1); // Ensure value is greater than 0
        taxAmountInput.attr('oninput', 'if(this.value > 90) this.value = 90; if(this.value < 1) this.value = 1;');
    } else {
        // Reset placeholder when "Amount" is selected
        taxAmountInput.attr('placeholder', '1000....');

        // Remove max, min attributes, and input validation for Amount
        taxAmountInput.removeAttr('min');
        taxAmountInput.removeAttr('oninput');
    }
});
