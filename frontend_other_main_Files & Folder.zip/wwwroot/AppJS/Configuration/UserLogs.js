//import  {GETAPIURL,GETBYID,POST,PUT,DELETE,CLEAR}  from "../Service/ApiService.js";
//import { Roles } from "../Service/Security.js";

//// INITIALIZING VARIBALES
//var end_point;
//var btn_save = $('#btn_sav')
//var btn_update = $('#btn_upd')
//var btn_add = $('#openmodal')
//var fromShortName = "ROLE"

//var formActionSpinners = $(".btn-spinner");
//var modalActionSpinners = $(".modal-spinner");
//var loaderIcon = document.getElementById("loader_icon");

//var url = new URLSearchParams(window.location.search);
//var menuId = '';
//if (url.has('M')) {
//    menuId = window.atob(url.get('M'));
//}


//// jQuery CONSTRUCTOR
//$(document).ready(function () {  
//    end_point = '/api/v1/PayrollLovService';
//    discon();
//  });

//$("#search").on("click", function () {
//    var _month = $("#txt_date").val();
//    Onload(_month);
//});

//// DISCONNECTION FUNCTION
//function discon(){
//    var code = $("#txt_code").val()
//    //CLEAR();btn_update.hide();btn_save.show();
//    const currentDate = new Date();
//    const currentYear = currentDate.getFullYear().toString();
//    const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Adding 1 because months are 0-based, and padStart ensures two digits
//    const currentYearMonth = `${currentYear}-${currentMonth}`;
//    document.getElementById("txt_date").value = currentYearMonth;
//    console.log(currentYearMonth)
//    Onload(currentYearMonth);
//    $("#txt_code").val(code)
//}

//// $($(document)).on('click', '#btn_codegenerate', function (e) {
////     setCode();
//// });

//// function setCode(){
////     $("#txt_code").val(fromShortName+"-"+ GenerateCode())
//// }

//// function GenerateCode() {
////     const min = 10;
////     const max = 99;
////     var preficxCode = Math.round(Math.random() * (max - min) + min);
////     var midexCode =  Math.round(Math.random() * (max - min) + min);
////     var postfixCode = Math.round(Math.random() * (max - min) + min);
////     return preficxCode +""+ midexCode +""+ postfixCode;
//// }


//// PATCHING DATA FUNCTION
//function patchdata(response){
//    $('#txt_id').val(response.id);
//    $('#txt_personid').val(response.personId);
//    $('#txt_personname').val(response.personName);
//    $('#txt_facesluiceid').val(response.facesluiceId);
//    $('#txt_facesluicename').val(response.facesluiceName);
//    $('#txt_checkintime').val(response.checkInTime);
//    $('#txt_checkouttime').val(response.checkOutTime);
//    $('#txt_verifystatus').val(response.verifyStatus);

//    console.log(response)
//    if (!response.active) {
//        $("#ck_act").prop("checked", false);
//    } else { $("#ck_act").prop("checked", true); }
//    $('#data_Model').modal();

   
//}

//// VALIDATION FUNCTION
//function ckvalidation() {
//    var ck = 0, _Error = '', _cre = '' ,id='';
//    var txt_id = $('#txt_id');  
//    var txt_code = $('#txt_code');   
//    var txt_role = $('#txt_role');   
//    var ck_act = $('#ck_act'); 
    
//    if (txt_role.val() == '') {
//        ck = 1;
//        _Error = 'Please Enter User Role';
//        txt_role.focus();
//    }
    
//    if (txt_code.val() == '') {
//        ck = 1;
//        _Error = 'Please Enter Code ';
//        txt_code.focus();
//    }
    
//    if (txt_id.val() == '') {
//        id= '00000000-0000-0000-0000-000000000000'
//    }
//    else{
//        id = txt_id.val()
//    }

//    if (Boolean(ck)) {
//        Swal.fire({
//            title: _Error,
//            icon: 'error'
//        })
//    }

//    else if (!Boolean(ck)) {
//        _cre = JSON.stringify({
//            "id": id,
//            "code": txt_code.val(),
//            "role": txt_role.val(),
//            "active": ck_act[0].checked,
//            "type": "U",
           
//        });
//    }
//    return { ckval: ck, creteria: _cre };
//}

//// setInterval(() => {
////     const currentDate = new Date();
////     const currentYear = currentDate.getFullYear().toString();
////     const currentMonth = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Adding 1 because months are 0-based, and padStart ensures two digits
////     const currentYearMonth = `${currentYear}-${currentMonth}`;
////     console.log(currentYearMonth)
////     Onload(currentYearMonth);
//// }, 5000);

//// ONLOAD FUNCTION
//function Onload(date) {
//    var tbl_row_cnt = 1;
//    $.ajax({
//        url: GETAPIURL(end_point + "/GetAttendance"),
//        type: "Get",
//        contentType: "application/json",
//        dataType: "json",
//        beforeSend: function(xhr) {
//            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
//            xhr.setRequestHeader('_month', date);
            
//        },
//        success: function (response) {
//            console.log(response)
//            var action_button = ' ';
//            if (response != null) {
//                $('#data_table').DataTable().clear().destroy();
//                var datatablesButtons = $("#data_table").DataTable({
//                    data: response.data,
//                    destroy: true,
//                    retrieve: true,
//                    processing: true,
//                    lengthChange:!1,
//                    buttons: ["pdf","copy", "print","csv"],
//                    columns: [
//                        //{ data: null,"defaultContent": action_button},
//                        { "render": function (data, type, full, meta) { return tbl_row_cnt++; }},
//                        // { data: 'personId' },
//                        { data: 'personName' },
//                        { data: 'facesluiceId' },
//                        { data: 'facesluiceName' },
//                        { data: 'checkInTime' , "render": function (data, type, full, meta) {  return  moment(data).format('DD-MMM-YYYY h:mm A'); }},
//                        { data: 'checkOutTime', "render": function (data, type, full, meta) {  return moment(data).format('DD-MMM-YYYY h:mm A')}},
//                        { data: 'totalHours' , "render": function (data, type, full, meta) {  return data.toFixed(2) } },
//                        // { data: 'checkInRemarks' },
//                        // { data: 'remarks' },
//                    ],
//                    "order": [[0, "asc"]],
//                    //"pageLength": 10,
                    
//                });
//                datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
//            }
//        },
//        error: function (xhr, status, err) {
//            Swal.fire({
//                title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
//                width:800,
//                icon: 'error',
//                showConfirmButton: true,
//                showClass: {
//                    popup: 'animated fadeInDown faster'
//                },
//                hideClass: {
//                    popup: 'animated fadeOutUp faster'
//                }
//            })
//        }
//    })
//    return true;
//}

//// ADD BUTTON EVENT
//$('form').on('click', '#btn_sav', function (e) {
//    var ck = ckvalidation();
//    var ckval = ck.ckval;
//    if (ckval == 1) { return; }
//    var _cre = ck.creteria;
//    POST(end_point + "/AddAttendance",_cre,function () {
//        discon();
//    });
//});

//// UPDATE BUTTON EVENT
//$('form').on('click', '#btn_upd', function (e) {
//    var ck = ckvalidation();
//    var ckval = ck.ckval;
//    if (ckval == 1) { return; }
//    var _cre = ck.creteria;
//    PUT(end_point + "/UpdateAttendance",_cre,function () {
//        discon();
//    });
//});

//// EDIT BUTTON EVENT 
//$('table').on('click', '.btn-edit', async function (e) { //Edit Start
//    e.preventDefault();
//    var currentRow = $(this).closest("tr");
//    var data = $('#data_table').DataTable().row(currentRow).data();
//    var _id = data['id'];
//    var _name = data['role'];
//    var type = data['type'];
//    if (type == "S") {
//        Swal.fire({
//            title: "This is System Generated Record",
//            icon: 'warning',
//        })
//        return
//    }
//    btn_update.show();btn_save.hide()
//    await GETBYID(end_point + "/GetAttendanceById", _id, menuId, _name, function (response) {
//        patchdata(response)
//    })
   
//});

//// DELETE BUTTON EVENT 
//$('table').on('click', '.btn-delete', function (e) {
//    e.preventDefault();
//    var currentRow = $(this).closest("tr");
//    var data = $('#data_table').DataTable().row(currentRow).data();
//    var _Id = data['id'];
//    var _name = data['role'];
//    var type = data['type'];
//    if (type == "S") {
//        Swal.fire({
//            title: "This is System Generated Record",
//            icon: 'warning',
//        })
//        return
//    }
//    DELETE(end_point + "/DeleteAttendance",_Id,_name,function () {
//        Onload();
//    })
//});


//// // for date wise search the record
//// $(document).ready(function () {
////     // Initialize your DataTable
////     var table = $('#data_table').DataTable({
////         data: [], // Add your data here
////         destroy: true,
////         retrieve: true,
////         processing: true,
////         lengthChange: !1,
////         columns: [
////             // Define your table columns here
////             { data: 'persionName' },
////             { data: 'logType' },
////             { data: 'facesluiceName' },
////             { data: 'checkInTime', render: function (data) {
////                 return (data !== "0001-01-01T00:00:00") ? moment(data).format('MMM DD YYYY h:mm:ss A') : '';
////             }},
////             { data: 'checkOutTime', render: function (data) {
////                 return (data !== "0001-01-01T00:00:00") ? moment(data).format('MMM DD YYYY h:mm:ss A') : '';
////             }},
////             { data: 'verifyStatus' },
////             { data: 'totalHours' }
////         ]
////     });

//    // // Initialize date range picker for check-in and check-out dates
//    // $('#checkinDate, #checkoutDate').daterangepicker({
//    //     autoUpdateInput: false,
//    //     locale: {
//    //         cancelLabel: 'Clear'
//    //     }
//    // });

//    // // Clear the date fields when the clear button is clicked
//    // $('#checkinDate, #checkoutDate').on('apply.daterangepicker', function (ev, picker) {
//    //     $(this).val(picker.startDate.format('MMM DD, YYYY') + ' - ' + picker.endDate.format('MMM DD, YYYY'));
//    // });

//    // $('#checkinDate, #checkoutDate').on('cancel.daterangepicker', function (ev, picker) {
//    //     $(this).val('');
//    // });

//    // // Add a listener to the date range fields to filter the DataTable when a date range is applied
//    // $('#checkinDate, #checkoutDate').on('apply.daterangepicker', function () {
//    //     var checkinDate = $('#checkinDate').val();
//    //     var checkoutDate = $('#checkoutDate').val();

//    //     table.columns(3).search(checkinDate).draw(); // Index 3 corresponds to the Check-In Date column
//    //     table.columns(4).search(checkoutDate).draw(); // Index 4 corresponds to the Check-Out Date column
//    // });

//    // // Now you can fetch data and populate your DataTable using your Onload function

//    // Onload();
//// });

//$(document).on('click', '#search', function (e) {
//    e.preventDefault();

//    // Get the selected month from the input field
//    var _month = $('#txt_date').val();

//    // Call the Onload function with the selected month
//    Onload(_month);
//});