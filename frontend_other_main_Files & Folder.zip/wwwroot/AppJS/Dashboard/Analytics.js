// ========================== IMPORTS ==========================

document.addEventListener("DOMContentLoaded", async () => {
    await fetchAndRenderAtgData();
    await fetchAndRenderDispenserData();
    await updateCards();       
    await renderCharts();     
    await renderLowLevelRtgTable();

    setInterval(async () => {
        console.log("♻️ Auto-refreshing dashboard data...");
        await fetchAndRenderAtgData();
        await fetchAndRenderDispenserData();
        await updateCards();
        await renderCharts();
        await renderLowLevelRtgTable();
    }, 30000);
});



let dispenserData = [];
let isFetchingDispenser = false;
let tankData = [];
let isFetchingAtg = false; 

const apiBaseUrl = "http://localhost:7085";

function getFuelColor(percentage) {
    if (percentage <= 20) return "darkred";
    if (percentage <= 50) return "blue";
    if (percentage <= 80) return "goldenrod";
    return "darkgreen";
}

async function fetchAndRenderAtgData() {
    if (isFetchingAtg) {
        console.warn("⚠️ Fetch already in progress, skipping this tick...");
        return;
    }

    isFetchingAtg = true;
    console.log("🔄 Fetching ATG data from", `${apiBaseUrl}/api/sensordata/atg-monitoring`);

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/atg-monitoring`);
        console.log("📡 Response status:", response.status);

        if (!response.ok) throw new Error("❌ Network response was not ok");

        const data = await response.json();
        console.log("✅ ATG Data received:", data);

        tankData = data.data_table.map(item => ({
            id: convertTankIdToDomId(item.tank_id),
            tank_id: item.tank_id,
            fuel: item.fuel_type,
            capacity: item.capacity_liters,
            current: item.current_volume,
            updatedAt: item.last_update
        }));

        initTankDisplay();
        
    } catch (error) {
        console.error("🚨 Failed to load ATG data:", error);
    } finally {
        isFetchingAtg = false;
    }
}

function convertTankIdToDomId(tankId) {
    const map = {
        "Tank 1": "tank1",
        "Tank 2": "tank2",
        "Tank 3": "tank3",
        "Tank 4": "tank4"
    };
    return map[tankId] || tankId.toLowerCase().replace(/\s/g, '');
}

function initTankDisplay() {
    tankData.forEach(tank => {
        const fillDiv = document.getElementById(tank.id);
        if (fillDiv) {
            const percentage = Math.round((tank.current / tank.capacity) * 100);

            if (fillDiv.dataset.percentage !== String(percentage)) {
                fillDiv.style.height = percentage + "%";
                fillDiv.style.backgroundColor = getFuelColor(percentage);

                const text = fillDiv.querySelector(".fuel-text");
                if (text) text.innerText = percentage + "%";

                fillDiv.dataset.percentage = percentage;
            }
        } else {
            console.warn(`⚠️ No element found with id '${tank.id}'`);
        }
    });
}




//===============================DISPENSER DETAILS============================


async function fetchAndRenderDispenserData() {
    if (isFetchingDispenser) return;
    isFetchingDispenser = true;

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/dispenser-monitoring`);
        if (!response.ok) throw new Error("❌ Failed to fetch data");

        const data = await response.json();
        console.log("✅ Dispenser data:", data);

        // Example structure assumption: { "data_table": [...] }
        dispenserData = data.data_table || [];

        renderDispenserCards(dispenserData);
        renderDispenserTable(dispenserData);

    } catch (err) {
        console.error("🚨 Error loading dispenser data:", err.message);
    } finally {
        isFetchingDispenser = false;
    }
}



function renderDispenserCards(data) {
    const list = document.getElementById("nozzle-list");
    list.innerHTML = "";

    // Step 1: Group by dispenser (assuming "pump" is unique per dispenser)
    const latestDispenserMap = {};

    data.forEach(d => {
        const key = d.pump;
        if (!latestDispenserMap[key] || new Date(d.timestamp) > new Date(latestDispenserMap[key].timestamp)) {
            latestDispenserMap[key] = d;
        }
    });

    // Step 2: Render exactly 5 (or however many unique ones exist)
    const latestDispenserList = Object.values(latestDispenserMap).slice(0, 5); // always max 5

    latestDispenserList.forEach(d => {
        const item = document.createElement("div");
        item.className = "nozzle-item d-flex align-items-center justify-content-between mb-2";

        item.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-gas-pump text-primary me-3"></i>
            <div>
                <strong>${d.pump ?? "N/A"}</strong>
                <div><strong>${d.volume_liters ?? 0} Liters</strong></div>
            </div>
        </div>
        <div class="d-flex align-items-center">
            <span class="badge me-3 ${d.status?.toLowerCase() === "online" ? "bg-success" : "bg-danger"}">
                <strong>${d.status ?? "Unknown"}</strong>
            </span>
            <div class="text-end">
                <span class="badge ${(d.status || "").trim().toLowerCase() === "online" ? "bg-info" : "bg-warning"} text-dark">
                    <strong>${d.dispenser_id ?? "-"}</strong>
                </span>
            <small class="d-block"><strong>Price: $${d.price_omr ?? "0.00"}</strong></small>
        </div>
    </div>
`;


        list.appendChild(item);
    });
}


function renderDispenserTable(data) {
    const table = $('#tankTable').DataTable({
        destroy: true,
        data: data,
        columns: [
            { data: 'pump', title: 'Pump' },
            { data: 'status', title: 'Status' },
            { data: 'dispenser_id', title: 'Dispenser ID' },
            { data: 'price_omr', title: 'Price (OMR)' },
            { data: 'volume_liters', title: 'Volume (Liters)' },
        ]
    });
}



// ========================== CARD DATA (DUMMY WRAPPED AS AJAX STRUCTURE) ==========================

async function fetchDashboardSummary() {
    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/dashboard-summary`);
        if (!response.ok) throw new Error("Failed to fetch dashboard summary");
        const data = await response.json();
        return data;
    } catch (err) {
        console.error("Error fetching dashboard summary:", err);
        return null;
    }
}


async function updateCards() {
    console.log("🧾 Updating cards...");

    const data = await fetchDashboardSummary();
    if (data && data.summary_cards) {
        const cards = data.summary_cards;
        document.getElementById("totalAtg").innerText = cards.total_atgs;
        document.getElementById("totalBrowser").innerText = cards.total_bowsers;
        document.getElementById("todayRtg").innerText = cards.total_rtgs;
        document.getElementById("totalAvi").innerText = cards.total_avi_vehicles;
        console.log("✅ Cards updated with API data");
    } else {
        console.error("❌ Failed to load card data");
    }
}


async function renderLowLevelRtgTable() {
    const data = await fetchDashboardSummary();
    if (data && data.low_level_rtg_table) {
        const container = document.getElementById("rtgListContainer");
        if (!container) {
            console.warn("⚠️ RTG list container not found!");
            return;
        }

        container.innerHTML = ""; // Clear previous content

        data.low_level_rtg_table.forEach(rtg => {
            const rtgItemHTML = `
                <div class="rtg-item">
                    <div>
                        <strong>${rtg.name}</strong>
                        <div>${rtg.current_fuel_liters.toFixed(2)} Liters</div>
                    </div>
                    <small>Last updated: ${rtg.last_update}</small>
                </div>
            `;
            container.innerHTML += rtgItemHTML;
        });
        console.log("✅ Low Level RTG Table rendered");
    } else {
        console.error("❌ Failed to load Low Level RTG data");
    }
}



// ========================== CHARTS ==========================
let fuelVolumeChartInstance = null;
let levelsGaugeInstance = null;

async function renderCharts() {
    console.log("📊 Rendering charts...");

    const data = await fetchDashboardSummary();
    if (!data) return;

    // volume_bar_chart data for fuelVolumeChart
    const barChartData = data.volume_bar_chart || [];
    const labels = barChartData.map(d => d.source);
    const volumes = barChartData.map(d => d.volume_percent);

    if (fuelVolumeChartInstance) {
        // update existing chart
        fuelVolumeChartInstance.data.labels = labels;
        fuelVolumeChartInstance.data.datasets[0].data = volumes;
        fuelVolumeChartInstance.update();
    } else {
        // create new chart
        fuelVolumeChartInstance = new Chart(document.getElementById('fuelVolumeChart'), {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: volumes,
                    backgroundColor: ['#ffc107', '#17a2b8', '#28a745', '#dc3545'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { color: 'Black' }
                    }
                }
            }
        });
    }

    // fuel_pie_chart data for levelsGauge
    const pieChartData = data.fuel_pie_chart || [];
    const pieLabels = pieChartData.map(d => d.label);
    const pieValues = pieChartData.map(d => d.value);

    if (levelsGaugeInstance) {
        levelsGaugeInstance.data.labels = pieLabels;
        levelsGaugeInstance.data.datasets[0].data = pieValues;
        levelsGaugeInstance.update();
    } else {
        levelsGaugeInstance = new Chart(document.getElementById('levelsGauge'), {
            type: 'doughnut',
            data: {
                labels: pieLabels,
                datasets: [{
                    data: pieValues,
                    backgroundColor: ['#ffc107', '#2a325a'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                circumference: 180,
                rotation: -90,
                cutout: '70%',
                plugins: {
                    legend: { display: false }
                }
            }
        });

        Chart.register({
            id: 'centerText',
            afterDraw: (chart) => {
                if (chart.canvas.id === "levelsGauge") {
                    const ctx = chart.ctx;
                    ctx.save();
                    ctx.fillStyle = 'Black';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';

                    // Show percentage of "Consumed Fuel" from pie data
                    const consumedFuel = pieChartData.find(d => d.label === "Consumed Fuel")?.value || 0;
                    const totalFuel = pieValues.reduce((a, b) => a + b, 0);
                    const consumedPercent = totalFuel > 0 ? ((consumedFuel / totalFuel) * 100).toFixed(1) : "0";

                    ctx.font = '30px Arial';
                    ctx.fillText(`${consumedPercent}%`, chart.canvas.width / 2, chart.canvas.height * 0.7);
                    ctx.restore();
                }
            }
        });
    }

    console.log("✅ Charts updated with API data");
}


