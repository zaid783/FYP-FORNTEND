import { GETAPIURL, FILLCOMBO, GETBYID, POST, PUT, DELETE, CLEAR , FILLCOMBOWIHOUTSELECT2} from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";


// Form Request Name get from URL param
var url = new URLSearchParams(window.location.search);
var Id = '';
var end_point='';

var att_from_date = $('#att_from_date');  
var att_to_date = $('#att_to_date');   

var att_monthFrom = $('#att_monthFrom');  
var att_monthTo = $('#att_monthTo');   

var payday_startFrom = $('#payday_from_date');

//Employee Attendance Report Variable:  Code By Allah Bukhsh
var att_from_date_empAttendaneRep = $('#att_from_date_empAttendaneRep');
var att_to_date_empAttendaneRep = $('#att_to_date_empAttendaneRep');

//TimeSheet Report Variable:
var att_from_date_emptimesheet = $('#att_from_date_emptimesheet');
var att_to_date_emptimesheet = $('#att_to_date_emptimesheet');

//ALL OTHER DATE'S VALIDATION'S BELOW (Future Work)
/*//var payday_monthTo = $('#payday_to_date');

var payroll_startFrom = $('#payroll_from_date');

var payslip_startFrom = $('#salaryslip_from_date');

var cheque_startFrom = $('#cheque_from_date');
var bankID_Selected = $('#sel_bank_cheque');

//new variables for TimeSheet report filter
var sel_brncode_timesheet = $('#sel_brncode_timesheet');
var sel_depcode_timesheet = $('#sel_depcode_timesheet');
var sel_seccode_timesheet = $('#sel_seccode_timesheet');

//Attendance Register Report Variable:
var att_from_date_attendanceregister = $('#att_from_date_attendanceregister');
var att_to_date_attendanceregister = $('#att_to_date_attendanceregister');
var sel_empcode_attendanceregister = $('#sel_empcode_attendanceregister');

var sel_empcode_daily = $('#sel_empcode_daily');   
var sel_empcode_montly = $('#sel_empcode_montly'); 
var sel_empcode_payday = $('#sel_empcode_payday');   
var sel_empcode_payroll = $('#sel_empcode_payroll');   
var sel_empcode_payslip = $('#sel_empcode_payslip');   
var sel_empcode_cheque = $('#sel_empcode_cheque');   

// new variable for daily report filter
var sel_brncode_daily = $('#sel_brncode_daily');
var sel_depcode_daily = $('#sel_depcode_daily');
var sel_seccode_daily = $('#sel_seccode_daily');

// new variable for monthly report filter
var sel_brncode_montly = $('#sel_brncode_montly');
var sel_depcode_montly = $('#sel_depcode_montly');
var sel_seccode_montly = $('#sel_seccode_montly');

//new variables for payday report filter
var sel_brncode_payday = $('#sel_brncode_payday');
var sel_depcode_payday = $('#sel_depcode_payday');
var sel_seccode_payday = $('#sel_seccode_payday');



//new variables for Attendance Register report filter
var sel_brncode_attendanceregister = $('#sel_brncode_attendanceregister');
var sel_depcode_attendanceregister = $('#sel_depcode_attendanceregister');
var sel_seccode_attendanceregister = $('#sel_seccode_attendanceregister');

//new variables for payroll report filter
var sel_brncode_payroll = $('#sel_brncode_payroll');
var sel_depcode_payroll = $('#sel_depcode_payroll');
var sel_seccode_payroll = $('#sel_seccode_payroll');

// Good Attendance Report VAriables:  Code By Allah Bukhsh
var att_from_date_goodattendance = $('#att_from_date_goodattendance');
var att_to_date_goodattendance = $('#att_to_date_goodattendance');
var att_exclude_date_goodattendance = $('#att_exclude_date_goodattendance');



//Consecutive Absentees Report
//ck_empcode_all_consecutiveabsents   for allemployees Checkbox
//absentCount
//for dates att_from_date_attendanceregister, att_to_date_attendanceregister
var absentCount = $('#absentCount');
var sel_empcode_consecutiveabsents = $('#sel_empcode_consecutiveabsents');
var att_from_date_consecutiveabsents = $('#att_from_date_consecutiveabsents');
var att_to_date_consecutiveabsents = $('#att_to_date_consecutiveabsents');
*/
//for report
var employee_selected_Code = "*";
var brn_selected_code = "*";
var dep_selected_code = "*";
var sec_selected_code = "*";


// Form Request Name get from URL param
var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () { 
    end_point = '/api/v1/AccountsLovService';
    LoadEmployee();
    render_dates() 
    render_month()
    LoadBanks()
    // Onload(Id)
  });


function LoadEmployee() {
    var $element = $('#sel_empcode_daily').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    var $element = $('#sel_empcode_montly').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    var $element = $('#sel_empcode_payday').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    var $element = $('#sel_empcode_payroll').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    var $element = $('#sel_empcode_payslip').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    var $element = $('#sel_empcode_cheque').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

    //Get branch,department and section to filter data for daily report
    var $element = $('#sel_brncode_daily').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_daily').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_daily').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    //Get branch,department and section to filter data for monthly report
    var $element = $('#sel_brncode_montly').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_montly').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_montly').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    //Get branch,department and section to filter data for payday report
    var $element = $('#sel_brncode_payday').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_payday').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_payday').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    //Get Employee Code for TimeSheet
    var $element = $('#sel_empcode_timesheet').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code");

    var $element = $('#sel_empcode_attendanceregister').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code");


    //Get branch,department and section to filter data for timesheet report
    var $element = $('#sel_brncode_timesheet').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_timesheet').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_timesheet').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    //Get branch,department and section to filter data for attendance Register report
    var $element = $('#sel_brncode_attendanceregister').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_attendanceregister').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_attendanceregister').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    //Get branch,department and section to filter data for Payroll report
    var $element = $('#sel_brncode_payroll').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBranchLov', $element, "Employee Branch")

    var $element = $('#sel_depcode_payroll').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetDepartmentLov', $element, "Employee Department")

    var $element = $('#sel_seccode_payroll').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetSectionLov', $element, "Employee Section")

    // for Conswcutive absentees
    var $element = $('#sel_empcode_consecutiveabsents').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetEmployeeLov', $element, "Employee Code")

}

function LoadBanks() {
    var $element = $('#sel_bank_cheque').select2();
    FILLCOMBO('/api/v1/PayrollLovService/GetBankLov', $element, "Bank Template")
}

// TAB 1 WORKING START

function render_dates() {
    // Set default values
    var yesterday = moment().subtract(1, 'days').format("YYYY-MM-DD");
    att_from_date.val(yesterday);
    att_to_date.val(yesterday);

    // Set max value for att_to_date to yesterday
    att_from_date.attr('max', yesterday);
    att_to_date.attr('max', yesterday);
    employee_selected_Code = "*";

    // Render dates for Employee Attendance Report: Code By Allah Bukhsh
    att_from_date_empAttendaneRep.val(yesterday);
    att_to_date_empAttendaneRep.val(yesterday);
    att_from_date_empAttendaneRep.attr('max', yesterday);
    att_to_date_empAttendaneRep.attr('max', yesterday);

    //Render dates for TimeSheet Report
    att_from_date_emptimesheet.val(yesterday);
    att_to_date_emptimesheet.val(yesterday);
    att_from_date_emptimesheet.attr('max', yesterday);
    att_to_date_emptimesheet.attr('max', yesterday);
    
    //ALL OTHER RENDER CODE BELOW (Future Work)
/*
    //Render dates for Attendance Register Report
    att_from_date_attendanceregister.val(yesterday);
    att_to_date_attendanceregister.val(yesterday);
    att_from_date_attendanceregister.attr('max', yesterday);
    att_to_date_attendanceregister.attr('max', yesterday);

    ////Render dates for Good Attendance Report:   Code By Allah Bukhsh
    att_from_date_goodattendance.val(yesterday);
    att_to_date_goodattendance.val(yesterday);
    att_exclude_date_goodattendance.val(yesterday);
    att_from_date_goodattendance.attr('max', yesterday);
    att_to_date_goodattendance.attr('max', yesterday);
    att_exclude_date_goodattendance.attr('max', yesterday);


    //Render dates for Consecutive Absent Report
    att_from_date_consecutiveabsents.val(yesterday);
    att_to_date_consecutiveabsents.val(yesterday);
    att_from_date_consecutiveabsents.attr('max', yesterday);
    att_to_date_consecutiveabsents.attr('max', yesterday);
    
    */
}

function render_month() {
    var currentDate = new Date();
    att_monthFrom.val(moment(currentDate).format("yyyy-MM"));
    att_monthTo.val(moment(currentDate).format("yyyy-MM"));
    employee_selected_Code = "*";
}



//New Filter Check for timesheet reports
$('#sel_empcode_timesheet').prop('disabled', $('#ck_empcode_all_timesheet').prop('checked'));
$('#sel_depcode_timesheet').prop('disabled', $('#ck_brncode_all_timesheet').prop('checked'));
$('#sel_brncode_timesheet').prop('disabled', $('#ck_depcode_all_timesheet').prop('checked'));
$('#sel_seccode_timesheet').prop('disabled', $('#ck_seccode_all_timesheet').prop('checked'));

//ALL FILTER CODE BELOW (Future Work)
/*
//New Filter Check for daily reports
$('#sel_empcode_daily').prop('disabled', $('#ck_empcode_all_date').prop('checked'));
$('#sel_brncode_daily').prop('disabled', $('#ck_brncode_all_daily').prop('checked'));
$('#sel_depcode_montly').prop('disabled', $('#ck_depcode_all_daily').prop('checked'));
$('#sel_seccode_montly').prop('disabled', $('#ck_seccode_all_daily').prop('checked'));

//New Filter Check for monthly reports
$('#sel_empcode_montly').prop('disabled', $('#ck_empcode_all_monthly').prop('checked'));
$('#sel_brncode_montly').prop('disabled', $('#ck_brncode_all_monthly').prop('checked'));
$('#sel_depcode_montly').prop('disabled', $('#ck_depcode_all_monthly').prop('checked'));
$('#sel_seccode_montly').prop('disabled', $('#ck_seccode_all_monthly').prop('checked'));

//New Filter Check for payday reports
$('#sel_empcode_payday').prop('disabled', $('#ck_empcode_all_payday').prop('checked'));
$('#sel_depcode_payday').prop('disabled', $('#ck_brncode_all_payday').prop('checked'));
$('#sel_brncode_payday').prop('disabled', $('#ck_depcode_all_payday').prop('checked'));
$('#sel_seccode_payday').prop('disabled', $('#ck_seccode_all_payday').prop('checked'));

//New Filter Check for attendance register reports
$('#sel_empcode_attendanceregister').prop('disabled', $('#ck_empcode_all_attendanceregister').prop('checked'));
$('#sel_depcode_attendanceregister').prop('disabled', $('#ck_brncode_all_attendanceregister').prop('checked'));
$('#sel_brncode_attendanceregister').prop('disabled', $('#ck_depcode_all_attendanceregister').prop('checked'));
$('#sel_seccode_attendanceregister').prop('disabled', $('#ck_seccode_all_attendanceregister').prop('checked'));

//New Filter Check for payroll reports
$('#sel_empcode_payroll').prop('disabled', $('#ck_empcode_all_payroll').prop('checked'));
$('#sel_depcode_payroll').prop('disabled', $('#ck_brncode_all_payroll').prop('checked'));
$('#sel_brncode_payroll').prop('disabled', $('#ck_depcode_all_payroll').prop('checked'));
$('#sel_seccode_payroll').prop('disabled', $('#ck_seccode_all_payroll').prop('checked'));

//New Filter Chack for Consecutive Absentees
$('#sel_empcode_consecutiveabsents').prop('disabled', $('#ck_empcode_all_consecutiveabsents').prop('checked'));

*/
$('#ck_empcode_all_payroll').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_payroll').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_payroll').val(-1).trigger("change");
    }
});

//==============================================================================================
//if all branch, department or section is checked for TimeSheet report
$('#ck_empcode_all_timesheet').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_timesheet').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_timesheet').val(-1).trigger("change");
    }
});

$('#ck_brncode_all_timesheet').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_timesheet').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_timesheet').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_timesheet').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_timesheet').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_timesheet').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_timesheet').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_timesheet').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_timesheet').val(-1).trigger("change");
    }
});

//if one employee is selected in payday report
$('#sel_empcode_timesheet').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_timesheet').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_timesheet').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_timesheet').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_timesheet').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_timesheet').prop('checked', true).prop('disabled', true);
        $('#ck_depcode_all_timesheet').prop('checked', true).prop('disabled', true);
        $('#ck_seccode_all_timesheet').prop('checked', true).prop('disabled', true);
    }
    else { //if (!isChecked) to reset other fields on employee
        $('#sel_brncode_timesheet').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_timesheet').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_timesheet').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_timesheet').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_timesheet').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_timesheet').prop('checked', false).prop('disabled', false);
    }
});
//======================================================================================

//All Check's Code (Future Work)
/*//======================================================================================
//if all branch, department or section is checked for daily report

$('#ck_empcode_all_date').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_daily').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_daily').val(-1).trigger("change");
    }
});

$('#ck_brncode_all_daily').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_daily').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_daily').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_daily').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_daily').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_daily').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_daily').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_daily').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_daily').val(-1).trigger("change");
    }
});

//for daily report if an employee code is selected disable every option
$('#sel_empcode_daily').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_date').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_daily').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_daily').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_daily').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_daily').prop('checked', true).prop('disabled', true);
        $('#ck_depcode_all_daily').prop('checked', true).prop('disabled', true);
        $('#ck_seccode_all_daily').prop('checked', true).prop('disabled', true);
    }
    else {
        $('#sel_brncode_daily').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_daily').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_daily').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_daily').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_daily').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_daily').prop('checked', false).prop('disabled', false);
    }

});


//======================================================================================
//if all branch, department or section is checked for monthly report

$('#ck_empcode_all_monthly').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_montly').prop('disabled', isChecked);

    if (isChecked) {
        $('#sel_empcode_montly').val(-1).trigger("change");
    }
    
});

$('#ck_brncode_all_monthly').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_montly').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_montly').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_monthly').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_montly').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_montly').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_monthly').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_montly').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_montly').val(-1).trigger("change");
    }
});

//for monthly report if an employee code is selected disable every option
$('#sel_empcode_montly').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_monthly').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_montly').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_montly').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_montly').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_monthly').prop('checked',true).prop('disabled', true);
        $('#ck_depcode_all_monthly').prop('checked', true).prop('disabled', true);    
        $('#ck_seccode_all_monthly').prop('checked', true).prop('disabled', true);
    }
    else { 
        $('#sel_brncode_montly').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_montly').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_montly').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_monthly').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_monthly').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_monthly').prop('checked', false).prop('disabled', false);
    }

});

//==============================================================================================
//if all branch, department or section is checked for payday report
$('#ck_empcode_all_payday').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_payday').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_payday').val(-1).trigger("change");
    }
});

$('#ck_brncode_all_payday').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_payday').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_payday').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_payday').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_payday').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_payday').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_payday').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_payday').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_payday').val(-1).trigger("change");
    }
});

//if one employee is selected in payday report
$('#sel_empcode_payday').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_payday').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_payday').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_payday').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_payday').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_payday').prop('checked',true).prop('disabled', true);
        $('#ck_depcode_all_payday').prop('checked', true).prop('disabled', true);
        $('#ck_seccode_all_payday').prop('checked', true).prop('disabled', true);
    }
    else { //if (!isChecked) to reset other fields on employee
        $('#sel_brncode_payday').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_payday').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_payday').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_payday').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_payday').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_payday').prop('checked', false).prop('disabled', false);
    }
});
//======================================================================================

//==============================================================================================
//if all branch, department or section is checked for Attendance Register
$('#ck_empcode_all_attendanceregister').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_attendanceregister').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_attendanceregister').val(-1).trigger("change");
    }
});

$('#ck_brncode_all_attendanceregister').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_attendanceregister').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_attendanceregister').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_attendanceregister').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_attendanceregister').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_attendanceregister').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_attendanceregister').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_attendanceregister').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_attendanceregister').val(-1).trigger("change");
    }
});

//if one employee is selected in payday report
$('#sel_empcode_attendanceregister').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_attendanceregister').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_attendanceregister').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_attendanceregister').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_attendanceregister').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_attendanceregister').prop('checked', true).prop('disabled', true);
        $('#ck_depcode_all_attendanceregister').prop('checked', true).prop('disabled', true);
        $('#ck_seccode_all_attendanceregister').prop('checked', true).prop('disabled', true);
    }
    else { //if (!isChecked) to reset other fields on employee
        $('#sel_brncode_attendanceregister').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_attendanceregister').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_attendanceregister').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_attendanceregister').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_attendanceregister').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_attendanceregister').prop('checked', false).prop('disabled', false);
    }
});
//=======================================================================================================
//disabled employee if checkbox is checked for consecutive absentees report
$('#ck_empcode_all_consecutiveabsents').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_consecutiveabsents').prop('disabled', isChecked);

    if (isChecked) {
        $('#sel_empcode_consecutiveabsents').val(-1).trigger("change");
    }

});

//==========================================================================================================

//==============================================================================================
//if all branch, department or section is checked for Payroll
$('#ck_empcode_all_payroll').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_empcode_payroll').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_empcode_payroll').val(-1).trigger("change");
    }
});

$('#ck_brncode_all_payroll').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_brncode_payroll').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_brncode_payroll').val(-1).trigger("change");
    }
});

$('#ck_depcode_all_payroll').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_depcode_payroll').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_depcode_payroll').val(-1).trigger("change");
    }
});

$('#ck_seccode_all_payroll').on('click', function () {
    var isChecked = $(this).prop('checked');
    $('#sel_seccode_payroll').prop('disabled', isChecked);
    if (isChecked) {
        $('#sel_seccode_payroll').val(-1).trigger("change");
    }
});

//if one employee is selected in payroll report
$('#sel_empcode_payroll').on('change', function () {
    var selectedValue = $(this).val();

    // Use the correct method to check if the checkbox is checked
    var isChecked = $('#ck_empcode_all_payroll').is(':checked');

    if (selectedValue !== "-1" && !isChecked) {
        $('#sel_brncode_payroll').prop('disabled', true).val(-1).trigger("change");
        $('#sel_depcode_payroll').prop('disabled', true).val(-1).trigger("change");
        $('#sel_seccode_payroll').prop('disabled', true).val(-1).trigger("change");
        $('#ck_brncode_all_payroll').prop('checked', true).prop('disabled', true);
        $('#ck_depcode_all_payroll').prop('checked', true).prop('disabled', true);
        $('#ck_seccode_all_payroll').prop('checked', true).prop('disabled', true);
    }
    else { //if (!isChecked) to reset other fields on employee
        $('#sel_brncode_payroll').prop('disabled', false).val(-1).trigger("change");
        $('#sel_depcode_payroll').prop('disabled', false).val(-1).trigger("change");
        $('#sel_seccode_payroll').prop('disabled', false).val(-1).trigger("change");
        $('#ck_brncode_all_payroll').prop('checked', false).prop('disabled', false);
        $('#ck_depcode_all_payroll').prop('checked', false).prop('disabled', false);
        $('#ck_seccode_all_payroll').prop('checked', false).prop('disabled', false);
    }
});
//=======================================================================================================
*/

$("#generateEmployeeAttdReportBtn").on('click', function () {
    employee_attendance_report();
})

$('#generate_emptimesheetreport').on('click', function () {
    emptime_sheet_report();
});

$("#generateEmpMonthlyReportBtn").on('click', function () {
    EmpMonthwise_Attendance()
})

//ALL OTHER CREATE BUTTON'S CODE (Future Work)
/*
$("#generateDailyReportBtn").on('click', function () {
    datewise_attendance_report()
})

$("#generate_paydayreport").on('click', function () {
    monthwise_payday();
})
$("#generate_payrollreport").on('click', function () {
    monthwise_payroll();
})

$("#generate_salaryslip").on('click', function () {
    monthwise_payslip();
})

$("#generate_cheque").on('click', function () {
    monthwise_cheque();
})



$('#generate_attendanceregisterreport').on('click', function () {
    attendance_register_report();
});

$("#generateGoodReportBtn").on('click', function () {
    good_attendance_report();    
})



$('#generate_consecutiveabsentreport').on('click', function () {
    consecutive_absence_report();
});

$('#generate_CDR').on('click', function () {
    cash_disbursement_report();
});
*/

//Code By AB: LEDGER EMPLOYEE ATTENDANCE REPORT FUNCTION
function employee_attendance_report() {
    var ck = employee_attendacne_ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;

    // Construct the URL with correct employee ID
    var url = "/Report/EmployeeAttendanceReport?M=" + btoa(menuId) +
        "&dateFrom=" + encodeURIComponent(_cre.dateFrom) +
        "&dateTo=" + encodeURIComponent(_cre.dateTo) +
        "&emp=" + encodeURIComponent(_cre.emp);

    window.open(url, '_blank');
}
function employee_attendacne_ckvalidation() {

    var ck = 0, _Error = '', _cre = '', id = '';
    var att_from_date = $('#att_from_date_empAttendaneRep');
    var att_to_date = $('#att_to_date_empAttendaneRep');
    if (att_from_date.val() == '') {
        ck = 1;
        _Error = 'Select Starting Date';
        att_from_date.focus();
    }
    if (att_to_date.val() == '') {
        ck = 1;
        _Error = 'Select Till Date';
        att_to_date.focus();
    }
    //===========================================================================================================

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = {
            "dateFrom": moment(att_from_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "dateTo": moment(att_to_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "emp": Id
        };
    }
    return { ckval: ck, creteria: _cre };
}

//old time sheet Ledger
/*//function emptime_sheet_report() {
//    var ck = emptime_sheet_report_ckvalidation();
//    var ckval = ck.ckval;
//    if (ckval == 1) { return; }
//    var _cre = ck.creteria;

//    // Construct the URL with correct employee ID
//    var url = "/Report/EmployeeTimeSheetReport?M=" + btoa(menuId) +
//        "&dateFrom=" + encodeURIComponent(_cre.dateFrom) +
//        "&dateTo=" + encodeURIComponent(_cre.dateTo) +
//        "&emp=" + encodeURIComponent(_cre.emp);

//    window.open(url, '_blank');
//}

//function emptime_sheet_report_ckvalidation() {
//    var ck = 0, _Error = '', _cre = '', id = '';
//    if (att_from_date_emptimesheet.val() == '') {
//        ck = 1;
//        _Error = 'Select Start Date';
//        att_from_date_emptimesheet.focus();
//    }
//    if (att_to_date_emptimesheet.val() == '') {
//        ck = 1;
//        _Error = 'Select End Date';
//        att_to_date_emptimesheet.focus();
//    }

//    if (moment(att_from_date_emptimesheet.val()).format("YYYY-MM-DD hh:mm:ss") > moment(att_to_date_emptimesheet.val()).format("YYYY-MM-DD hh:mm:ss")) {
//        ck = 1;
//        _Error = "The report cannot be generated for selected month. Please select a proper duration of months";
//        att_from_date_emptimesheet.focus();
//    }



//    if (Boolean(ck)) {
//        Swal.fire({
//            title: _Error,
//            icon: 'error'
//        })
//    }

//    else if (!Boolean(ck)) {
//        _cre = {
//            "dateFrom": moment(att_from_date_emptimesheet.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
//            "dateTo": moment(att_to_date_emptimesheet.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss")
//        };
//    }
//    return { ckval: ck, creteria: _cre };
//}
*/


// EMPLOYEE TIME SHEET REPORT LEDGER
function emptime_sheet_report(/*_Id*/) {
    //console.log("")
    var ck = emptime_sheet_report_ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    var url = "/Report/EmployeeTimeSheetReport?M=" + btoa(menuId) +
        "&dateFrom=" + encodeURIComponent(_cre.dateFrom) +
        "&dateTo=" + encodeURIComponent(_cre.dateTo) +
        "&emp=" + encodeURIComponent(_cre.emp);
    window.open(url, '_blank');

}
function emptime_sheet_report_ckvalidation() {

    var ck = 0, _Error = '', _cre = '', id = '';
    var att_from_date = $('#att_from_date_emptimesheet');
    var att_to_date = $('#att_to_date_emptimesheet');
    if (att_from_date.val() == '') {
        ck = 1;
        _Error = 'Select Start Date';
        att_from_date.focus();
    }
    if (att_to_date.val() == '') {
        ck = 1;
        _Error = 'Select End Date';
        att_to_date.focus();
    }
    
    if (moment(att_from_date.val()).format("YYYY-MM-DD hh:mm:ss") > moment(att_to_date.val()).format("YYYY-MM-DD hh:mm:ss")) {
        ck = 1;
        _Error = "The report cannot be generated for selected month. Please select a proper duration of months";
        att_from_date.focus();
    }

    
    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = {
            "dateFrom": moment(att_from_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "dateTo": moment(att_to_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "emp": employee_selected_Code
        };
    }
    return { ckval: ck, creteria: _cre };
}

// LEDGER MONTH WISE FUNCTION
function EmpMonthwise_Attendance(/*_Id*/) {
    var ck = Attendance_EmpMonthWiseckValidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    var url = "/Report/EmployeeMonthlyAttendanceReport?M=" + btoa(menuId) +
        "&monthFrom=" + encodeURIComponent(_cre.monthFrom) +
        "&monthTo=" + encodeURIComponent(_cre.monthTo) +
        "&emp=" + encodeURIComponent(_cre.emp);
    window.open(url, '_blank')
}
function Attendance_EmpMonthWiseckValidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    if (att_monthFrom.val() == '') {
        ck = 1;
        _Error = 'Select Start Month';
        att_monthFrom.focus();
    }
    if (att_monthTo.val() == '') {
        ck = 1;
        _Error = 'Select End Month';
        att_monthTo.focus();
    }
    if (moment(att_monthFrom.val()).format("YYYY-MM-DD hh:mm:ss") > moment(att_monthTo.val()).format("YYYY-MM-DD hh:mm:ss")) {
        ck = 1;
        _Error = "The report cannot be generated for selected month. Please select a proper duration of months";
        att_monthFrom.focus();
    }
    ////========================================================================================================================

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = {
            "monthFrom": moment(att_monthFrom.val()).format("YYYY-MM-DD hh:mm:ss"),
            "monthTo": moment(att_monthTo.val()).format("YYYY-MM-DD hh:mm:ss"),
            "emp": employee_selected_Code
        };
    }
    return { ckval: ck, creteria: _cre };
}


//ALL OTHER LEDGER FUNCTION'S BELOW (Future Work)

/*// LEDGER DATE WISE FUNCTION
function datewise_attendance_report(_Id) {
        var ck = attendacne_datewiseckvalidation();
        var ckval = ck.ckval;
        if (ckval == 1) { return; }
        var _cre = ck.creteria;
    var url = "/Report/ReportSheet?M=" + btoa(menuId) + "&dateFrom=" +
        encodeURIComponent(_cre.dateFrom) + "&dateTo=" + encodeURIComponent(_cre.dateTo) +
        "&emp=" + encodeURIComponent(_cre.emp) + "&brn=" + encodeURIComponent(_cre.brn) +
        "&dep=" + encodeURIComponent(_cre.dep) + "&sec=" + encodeURIComponent(_cre.sec)
        window.open(url, '_blank')
    }
function attendacne_datewiseckvalidation() {

        var ck = 0, _Error = '', _cre = '', id = '';
        if (att_from_date.val() == '') {
            ck = 1;
            _Error = 'Select Starting Date';
            att_from_date.focus();
        }
        if (att_to_date.val() == '') {
            ck = 1;
            _Error = 'Select Till Date';
            att_to_date.focus();
        }
        //===========================================================================================================

        if ($('#ck_empcode_all_date').prop('checked') == true) {
            employee_selected_Code = "*"
        } else {
            if (sel_empcode_daily.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more employee(s).';
            } else {
                employee_selected_Code = sel_empcode_daily.val()
            }
        }

        //if admin selected all branches, department, and section
        //Branches
        if ($('#ck_brncode_all_daily').prop('checked') == true) {
            brn_selected_code = "*";
        }
        else {
            if (sel_brncode_daily.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Branch(s).';
            } else {
                brn_selected_code = sel_brncode_daily.val()
            }
        }
        //Department
        if ($('#ck_depcode_all_daily').prop('checked') == true) {
            dep_selected_code = "*";
        }
        else {
            if (sel_depcode_daily.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Department(s)';
            }
            else {
                dep_selected_code = sel_depcode_daily.val();
            }
        }
        //Sections
        if ($('#ck_seccode_all_daily').prop('checked') == true) {
            sec_selected_code = "*";
        }
        else {
            if (sel_seccode_daily.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Section(s)';
            }
            else {
                sec_selected_code = sel_seccode_daily.val();
            }
        }

        if (Boolean(ck)) {
            Swal.fire({
                title: _Error,
                icon: 'error'
            })
        }

        else if (!Boolean(ck)) {
            _cre = {
                "dateFrom": moment(att_from_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
                "dateTo": moment(att_to_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
                "emp": employee_selected_Code,
                "brn": brn_selected_code,
                "dep": dep_selected_code,
                "sec": sec_selected_code
            };
        }
        return { ckval: ck, creteria: _cre };
    }


// LEDGER PAYDAY FUNCTION
function monthwise_payday(_Id) {
        var ck = payday_monthwiseckvalidation();
        var ckval = ck.ckval;
        if (ckval == 1) { return; }
        var _cre = ck.creteria;
        var url = "/Report/PaydayReport?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.start) + "&emp=" + encodeURIComponent(_cre.emp) + "&brn=" + encodeURIComponent(_cre.brn) + "&dep=" + encodeURIComponent(_cre.dep) + "&sec=" + encodeURIComponent(_cre.sec)
        window.open(url, '_blank')
    }
function payday_monthwiseckvalidation() {
        var ck = 0, _Error = '', _cre = '', id = '';
        if (payday_startFrom.val() == '') {
            ck = 1;
            _Error = 'Please select a payday start date!';
            payday_startFrom.focus();
        }
        //if (payday_monthTo.val() == '') {
        //    ck = 1;
        //    _Error = 'Select End Month';
        //    payday_monthTo.focus();
        //}

        if ($('#ck_empcode_all_payday').prop('checked') == true) {
            employee_selected_Code = "*"
        } else {
            if (sel_empcode_payday.val() == "-1" || sel_empcode_payday.val() == null) {
                ck = 1;
                _Error = 'Please select one or more employee(s).';
            } else {
                employee_selected_Code = sel_empcode_payday.val()
            }
        }

        //if admin selected all branches, department, and section
        //Branches

        if ($('#ck_brncode_all_payday').prop('checked') == true) {
            brn_selected_code = "*";
        }
        else {
            if (sel_brncode_payday.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Branch(s).';
            } else {
                brn_selected_code = sel_brncode_payday.val()
            }
        }
        //Department
        if ($('#ck_depcode_all_payday').prop('checked') == true) {
            dep_selected_code = "*";
        }
        else {
            if (sel_depcode_payday.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Department(s)';
            }
            else {
                dep_selected_code = sel_depcode_payday.val();
            }
        }
        //Sections
        if ($('#ck_seccode_all_payday').prop('checked') == true) {
            sec_selected_code = "*";
        }
        else {
            if (sel_seccode_payday.val() == "-1") {
                ck = 1;
                _Error = 'Please select one or more Section(s)';
            }
            else {
                sec_selected_code = sel_seccode_payday.val();
            }
        }

        if (Boolean(ck)) {
            Swal.fire({
                title: _Error,
                icon: 'error'
            })
        }

        else if (!Boolean(ck)) {
            _cre = {
                "start": moment(payday_startFrom.val()).format("YYYY-MM-DD hh:mm:ss"),
                //"monthTo": moment(payday_monthTo.val()).format("YYYY-MM-DD hh:mm:ss"),
                "emp": employee_selected_Code,
                "brn": brn_selected_code,
                "dep": dep_selected_code,
                "sec": sec_selected_code
            };
        }
        return { ckval: ck, creteria: _cre };
    }



// LEDGER PAYROLL FUNCTION
function monthwise_payroll(_Id) {
        var ck = payroll_monthwiseckvalidation();
        var ckval = ck.ckval;
        if (ckval == 1) { return; }
        var _cre = ck.creteria;
        var url = "/Report/PayrollReport?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.start) + "&emp=" + encodeURIComponent(_cre.emp) + "&brn=" + encodeURIComponent(_cre.brn) + "&dep=" + encodeURIComponent(_cre.dep) + "&sec=" + encodeURIComponent(_cre.sec);
        window.open(url, '_blank')
    }
function payroll_monthwiseckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    if (payroll_startFrom.val() == '') {
        ck = 1;
        _Error = 'Please select a payroll start date!';
        payroll_startFrom.focus();
    }
    //if (payday_monthTo.val() == '') {
    //    ck = 1;
    //    _Error = 'Select End Month';
    //    payday_monthTo.focus();
    //}

    if ($('#ck_empcode_all_payroll').prop('checked') == true) {
        employee_selected_Code = "*"
    } else {
        if (sel_empcode_payroll.val() == "-1" || sel_empcode_payroll.val() == null) {
            ck = 1;
            _Error = 'Please select one or more employee(s).';
        } else {
            employee_selected_Code = sel_empcode_payroll.val()
        }
    }

    //if admin selected all branches, department, and section
    //Branches

    if ($('#ck_brncode_all_payroll').prop('checked') == true) {
        brn_selected_code = "*";
    }
    else {
        if (sel_brncode_payroll.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Branch(s).';
        } else {
            brn_selected_code = sel_brncode_payroll.val()
        }
    }
    //Department
    if ($('#ck_depcode_all_payroll').prop('checked') == true) {
        dep_selected_code = "*";
    }
    else {
        if (sel_depcode_payroll.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Department(s)';
        }
        else {
            dep_selected_code = sel_depcode_payroll.val();
        }
    }
    //Sections
    if ($('#ck_seccode_all_payroll').prop('checked') == true) {
        sec_selected_code = "*";
    }
    else {
        if (sel_seccode_payroll.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Section(s)';
        }
        else {
            sec_selected_code = sel_seccode_payroll.val();
        }
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = {
            "start": moment(payroll_startFrom.val()).format("YYYY-MM-DD hh:mm:ss"),
            //"monthTo": moment(payday_monthTo.val()).format("YYYY-MM-DD hh:mm:ss"),
            "emp": employee_selected_Code,
            "brn": brn_selected_code,
            "dep": dep_selected_code,
            "sec": sec_selected_code
        };
    }
    return { ckval: ck, creteria: _cre };
}


// PAYSLIP FUNCTION
function monthwise_payslip(_Id) {
        var ck = payslip_monthwiseckvalidation();
        var ckval = ck.ckval;
        if (ckval == 1) { return; }
        var _cre = ck.creteria;
        var url = "/Report/PaySlip?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.start) + "&emp=" + encodeURIComponent(_cre.emp)
        window.open(url, '_blank')
    }
function payslip_monthwiseckvalidation() {
        var ck = 0, _Error = '', _cre = '', id = '';
        if (payslip_startFrom.val() == '') {
            ck = 1;
            _Error = 'Please select a payslip month!';
            payslip_startFrom.focus();
        }
        if (sel_empcode_payslip.val() == "-1" || sel_empcode_payslip.val() == null) {
            ck = 1;
            _Error = 'Please select employee to proceed.';
        } else {
            employee_selected_Code = sel_empcode_payslip.val()
        }


        if (Boolean(ck)) {
            Swal.fire({
                title: _Error,
                icon: 'error'
            })
        }

        else if (!Boolean(ck)) {
            _cre = {
                "start": moment(payslip_startFrom.val()).format("YYYY-MM-DD hh:mm:ss"),
                "emp": employee_selected_Code
            };
        }
        return { ckval: ck, creteria: _cre };
    }


// CHEQUE
function monthwise_cheque(_Id) {
    var ck = cheque_monthwiseckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    var url = "/Report/Cheque?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.start) + "&emp=" + encodeURIComponent(_cre.emp) + "&BID=" + encodeURIComponent(_cre.bankID)
    window.open(url, '_blank')
}
function cheque_monthwiseckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    if (cheque_startFrom.val() == '') {
        ck = 1;
        _Error = 'Please select a month to produce cheque!';
        cheque_startFrom.focus();
    }
    if (bankID_Selected.val() == "-1" || bankID_Selected.val() == "") {
        ck = 1;
        _Error = 'Please select bank to proceed.';
    }
    if (sel_empcode_cheque.val() == "-1" || sel_empcode_cheque.val() == null) {
        ck = 1;
        _Error = 'Please select an employee to proceed.';
    } else {
        employee_selected_Code = sel_empcode_cheque.val()
    }
    if (sel_empcode_cheque.val() == "-1" || sel_empcode_cheque.val() == null) {
        ck = 1;
        _Error = 'Please select an employee to proceed.';
    } else {
        employee_selected_Code = sel_empcode_cheque.val()
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        });
    }

    else if (!Boolean(ck)) {
        _cre = {
            "start": moment(cheque_startFrom.val()).format("YYYY-MM-DD hh:mm:ss"),
            "emp": employee_selected_Code,
            "bankID": bankID_Selected.val()
        };
    }
    return { ckval: ck, creteria: _cre };
}
function attendance_register_report(_Id) {
    //console.log("")
    var ck = attendance_register_report_ckvalidation();
    var ckval = ck.ckval;
    var _cre = ck.creteria;
    console.log("In Attendance Register Report");
    console.log("in credentials " + _cre + ckval);
    if (ckval == 1) { return; }
    var url = "/Report/AttendanceRegisterReport?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.dateFrom) + "&dateTo=" + encodeURIComponent(_cre.dateTo) + "&emp=" + encodeURIComponent(_cre.emp) + "&brn=" + encodeURIComponent(_cre.brn) + "&dep=" + encodeURIComponent(_cre.dep) + "&sec=" + encodeURIComponent(_cre.sec);
    window.open(url, '_blank');
}

function attendance_register_report_ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    if (att_from_date_attendanceregister.val() == '') {
        ck = 1;
        _Error = 'Select Start Date';
        att_from_date_attendanceregister.focus();
    }
    if (att_to_date_attendanceregister.val() == '') {
        ck = 1;
        _Error = 'Select End Date';
        att_to_date_attendanceregister.focus();
    }

    if ($('#ck_empcode_all_attendanceregister').prop('checked') == true) {
        employee_selected_Code = "*"
    } else {
        if (sel_empcode_attendanceregister.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more employee(s).';
        } else {
            employee_selected_Code = sel_empcode_attendanceregister.val()
        }
    }

    if (moment(att_from_date_attendanceregister.val()).format("YYYY-MM-DD hh:mm:ss") > moment(att_to_date_attendanceregister.val()).format("YYYY-MM-DD hh:mm:ss")) {
        ck = 1;
        _Error = "The report cannot be generated for selected month. Please select a proper duration of months";
        att_from_date_attendanceregister.focus();
    }

    //if admin selected all branches, department, and section
    //Branches

    if ($('#ck_brncode_all_attendanceregister').prop('checked') == true) {
        brn_selected_code = "*";
    }
    else {
        if (sel_brncode_attendanceregister.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Branch(s).';
        } else {
            brn_selected_code = sel_brncode_attendanceregister.val()
        }
    }
    //Department
    if ($('#ck_depcode_all_attendanceregister').prop('checked') == true) {
        dep_selected_code = "*";
    }
    else {
        if (sel_depcode_attendanceregister.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Department(s)';
        }
        else {
            dep_selected_code = sel_depcode_attendanceregister.val();
        }
    }
    //Sections
    if ($('#ck_seccode_all_attendanceregister').prop('checked') == true) {
        sec_selected_code = "*";
    }
    else {
        if (sel_seccode_attendanceregister.val() == "-1") {
            ck = 1;
            _Error = 'Please select one or more Section(s)';
        }
        else {
            sec_selected_code = sel_seccode_attendanceregister.val();
        }
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        });
    }

    else if (!Boolean(ck)) {
        _cre = {
            "dateFrom": moment(att_from_date_attendanceregister.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "dateTo": moment(att_to_date_attendanceregister.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "emp": employee_selected_Code,
            "brn": brn_selected_code,
            "dep": dep_selected_code,
            "sec": sec_selected_code

        };
    }
    return { ckval: ck, creteria: _cre };

}

// LEDGER GOOD ATTENDANCE REPORT FUNCTION:   Code By Allah Bukhsh

function good_attendance_report(_Id) {
    var ck = goodAttendanceValidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }

    var _cre = ck.creteria;


    var url = "/Report/GoodAttendanceReport?M=" + btoa(menuId)
        + "&dateFrom=" + encodeURIComponent(_cre.dateFrom)
        + "&dateTo=" + encodeURIComponent(_cre.dateTo)
        + "&excludeDate=" + encodeURIComponent(_cre.excludeDate);
    window.open(url, '_blank');
}


function goodAttendanceValidation() {
    var ck = 0, _Error = '', _cre = '';

    // Update to match HTML IDs
    var att_from_date = $('#att_from_date_goodattendance');
    var att_to_date = $('#att_to_date_goodattendance');
    var excludeDate = $('#att_exclude_date_goodattendance'); // Ensure this ID is correct in HTML as well

    if (att_from_date.val() == '') {
        ck = 1;
        _Error = 'Select Starting Date';
        att_from_date.focus();
    }
    if (att_to_date.val() == '') {
        ck = 1;
        _Error = 'Select Till Date';
        att_to_date.focus();
    }
    if (excludeDate.val() == '') {
        ck = 1;
        _Error = 'Select Exclude Date';
        excludeDate.focus();
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        });
    } else if (!Boolean(ck)) {
        _cre = {
            "dateFrom": moment(att_from_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "dateTo": moment(att_to_date.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "excludeDate": moment(excludeDate.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss")
        };
    }
    return { ckval: ck, creteria: _cre };
}


function consecutive_absence_report(_Id) {
    var ck = consecutive_absent_report_ckvalidation();
    var ckval = ck.ckval;
    var _cre = ck.creteria;
    console.log("In Consecutive Attendance Report");
    console.log("In credentials " + _cre + ckval);
    if (ckval == 1) { return; }
    var url = "/Report/ConsecutiveAbsentsReport?M=" + btoa(menuId) + "&dateFrom=" + encodeURIComponent(_cre.dateFrom) + "&dateTo=" + encodeURIComponent(_cre.dateTo) + "&emp=" + encodeURIComponent(_cre.emp) + "&abs=" + encodeURIComponent(_cre.abs);
    window.open(url, '_blank');
}

function consecutive_absent_report_ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    if (att_from_date_consecutiveabsents.val() == '') {
        ck = 1;
        _Error = 'Select Start Date';
        att_from_date_consecutiveabsents.focus();
    }
    if (att_to_date_consecutiveabsents.val() == '') {
        ck = 1;
        _Error = 'Select End Date';
        att_to_date_consecutiveabsents.focus();
    }
    if (absentCount.val() == '') {
        ck = 1;
        _Error = 'Write Absent Count';
        absentCount.focus();
    }
    if ($('#ck_empcode_all_consecutiveabsents').prop('checked') == true) {
        employee_selected_Code = "*";
    } else {
        if (sel_empcode_consecutiveabsents.val() == "-1") {
            ck = 1;
            _Error = "Please Select one or more Employee";
        } else {
            employee_selected_Code = sel_empcode_consecutiveabsents.val();
        }
    }
    if (moment(att_from_date_consecutiveabsents.val()).format("YYYY-MM-DD hh:mm:ss") > moment(att_to_date_consecutiveabsents.val()).format("YYYY-MM-DD hh:mm:ss")) {
        ck = 1;
        _Error = "The report cannot be generated for selected month. Please select a proper duration of months";
        att_from_date_consecutiveabsents.focus();
    }
    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        });
    } else if (!Boolean(ck)) {
        _cre = {
            "dateFrom": moment(att_from_date_consecutiveabsents.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "dateTo": moment(att_to_date_consecutiveabsents.val()).startOf('day').format("YYYY-MM-DD HH:mm:ss"),
            "emp": employee_selected_Code,
            "abs": absentCount.val()
        };
    }
    return { ckval: ck, creteria: _cre };
}


function cash_disbursement_report(_Id) {
    var ck = cash_disbursement_report_ckvalidation();
    var ckval = ck.ckval;
    var _cre = ck.creteria;
    

    //console.log("In Attendance Register Report");
    //console.log("in credentials " + _cre + ckval);
    if (ckval == 1) { return; }
    var url = "/Report/CashDisbursementReport?M=" + btoa(menuId) + "&reportType=" + encodeURIComponent(_cre.ReportType) + "&reportAction=" + encodeURIComponent(_cre.ReportAction);
    window.open(url, '_blank');
}

function cash_disbursement_report_ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var sel_tax_bonus = $('#sel_tax_bonus');
    //var sel_report_action = $('#sel_report_action');

    //if (sel_tax_bonus.val() === '' || sel_tax_bonus.val() === '-1') {
    //    ck = 1;
    //    _Error = 'Select a Report Type';
    //    sel_tax_bonus.focus();
    //}
    //if (sel_report_action.val() === '' || sel_report_action.val() === '-1') {
    //    ck = 1;
    //    _Error = 'Select a Report Action';
    //    sel_report_action.focus();
    //}

    
    //if (Boolean(ck)) {
    //    Swal.fire({
    //        title: _Error,
    //        icon: 'error'
    //    });
    //}
    console.log("HERE");
    if (!Boolean(ck)) {
        _cre = {
            "ReportType": sel_tax_bonus.val(),
            "ReportAction": 'ViewHistory'//sel_report_action.val()
        };
    }
    return { ckval: ck, creteria: _cre };
}
*/