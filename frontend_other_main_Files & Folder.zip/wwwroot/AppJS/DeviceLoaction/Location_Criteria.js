﻿import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR, FILLCOMBO, FILLCOMBOBYID } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";


// Global variables
let vehicle = $('#vehicle');
let selected_vehicle_Code = "*";

// Auto-login and fetch token
async function autoLoginToGetToken() {
    try {
        const res = await fetch('http://localhost:7085/api/external/login', {
            method: 'POST'
        });

        if (!res.ok) {
            const text = await res.text();
            console.error("❌ Login failed. Status:", res.status, "Body:", text);
            return null;
        }

        const data = await res.json();
        if (data.user_api_hash) {
            localStorage.setItem('apiToken', data.user_api_hash);
            return data.user_api_hash;
        } else {
            console.error("❌ Missing token in response:", data);
            return null;
        }
    } catch (err) {
        console.error("❌ Auto-login error:", err);
        return null;
    }
}

async function loadVehicles() {
    console.log("🟡 Step 1: Starting loadVehicles()...");

    const token = await autoLoginToGetToken();
    console.log("🟡 Step 2: Token fetched:", token);

    if (!token) {
        console.error("❌ Step 2 Failed: No token");
        return;
    }

    const url = `http://localhost:7085/api/external/devices?user_api_hash=${encodeURIComponent(token)}`;
    console.log("🟡 Step 3: Fetching from:", url);

    try {
        const res = await fetch(url);
        if (!res.ok) {
            const errText = await res.text();
            throw new Error(`Fetch failed: ${res.status} - ${errText}`);
        }

        const groups = await res.json();
        console.log("✅ Step 4: Parsed response:", groups);

        vehicle.empty().append(new Option("Select Vehicle", "-1"));

        groups.forEach((group, gIndex) => {
            console.log(`🟦 Group ${gIndex}: ${group.title}`, group);

            if (Array.isArray(group.items)) {
                group.items.forEach((v, vIndex) => {
                    console.log(`➕ Adding vehicle [${vIndex}] from group '${group.title}':`, v);
                    vehicle.append(new Option(v.name, v.id));
                });
            } else {
                console.warn(`⚠️ Group ${group.title} has no items.`);
            }
        });

        if ($.fn.select2) {
            vehicle.select2();
            console.log("✅ Select2 initialized.");
        }

        console.log("✅ Vehicle dropdown loaded successfully.");

    } catch (error) {
        console.error("❌ Error loading vehicles:", error);
    }
}


// Checkbox behavior
$('#ck_vehicle').on('change', function () {
    const isChecked = $(this).is(':checked');
    vehicle.prop('disabled', isChecked);
    if (isChecked) {
        vehicle.val(-1).trigger("change");
    }
});

// Button click
$('#show_vehicle_on_Map').on('click', function () {
    vehicleMap();
});


function vehicleMap_ckvalidation() {
    let isChecked = $('#ck_vehicle').is(':checked');
    let selectedVehicle = $('#vehicle').val();

    if (!isChecked && (!selectedVehicle || selectedVehicle === "-1")) {
        alert("❌ Please select a vehicle.");
        return { ckval: 1, creteria: null };
    }

    // If checkbox is checked, collect ALL vehicle IDs from the dropdown
    if (isChecked) {
        let allVehicleIds = [];
        $('#vehicle option').each(function () {
            let val = $(this).val();
            if (val && val !== "-1") {
                allVehicleIds.push(val);
            }
        });
        console.log("✅ Checkbox checked - All vehicle IDs:", allVehicleIds);
        return { ckval: 0, creteria: { vehicleId: allVehicleIds.join(",") } };
    }

    // If checkbox is not checked, return selected vehicle ID
    console.log("✅ Single vehicle selected:", selectedVehicle);
    return { ckval: 0, creteria: { vehicleId: selectedVehicle } };
}



function vehicleMap() {
    let ck = vehicleMap_ckvalidation();
    if (ck.ckval === 1) return;

    const vehicleId = ck.creteria.vehicleId;
    const url = `/DeviceLoaction/VehicleDetailedInfo?vehicleId=${encodeURIComponent(vehicleId)}`;
    console.log("🔗 Redirecting to:", url);
    window.open(url, '_blank');
}

// On page ready
$(document).ready(function () {
    loadVehicles();
});
