﻿
import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR, FILLCOMBO, FILLCOMBOBYID } from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

async function autoLoginToGetToken() {
    try {
        const res = await fetch('http://localhost:7085/api/external/login', { method: 'POST' });
        if (!res.ok) throw new Error(await res.text());
        const data = await res.json();
        if (data.user_api_hash) {
            localStorage.setItem('apiToken', data.user_api_hash);
            return data.user_api_hash;
        }
        throw new Error("Missing token in response");
    } catch (err) {
        console.error("❌ Auto-login failed:", err);
        return null;
    }
}

function makeCardDraggable(card) {
    let isDragging = false, offsetX, offsetY;

    card.addEventListener('mousedown', (e) => {
        isDragging = true;
        offsetX = e.clientX - card.offsetLeft;
        offsetY = e.clientY - card.offsetTop;
        card.style.cursor = "grabbing";
    });

    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            card.style.left = `${e.clientX - offsetX}px`;
            card.style.top = `${e.clientY - offsetY}px`;
        }
    });

    document.addEventListener('mouseup', () => {
        isDragging = false;
        card.style.cursor = "grab";
    });
}
function createVehicleIcon(vehicle) {
    const iconData = vehicle.icon || {};

    // Construct the full URL if only a relative path is provided
    const iconUrl = iconData.path
        ? `https://world.autotel.pk/${iconData.path}`
        : "https://world.autotel.pk/images/device_icons/default_offline.png"; // Fallback icon

    const width = iconData.width || 36;
    const height = iconData.height || 36;

    return L.icon({
        iconUrl,
        iconSize: [width, height],
        iconAnchor: [width / 2, height],
        popupAnchor: [0, -height],
        className: "vehicle-marker-icon"
    });
}


function createInfoCard(vehicle, asHtml = false) {
    let statusText = 'Unknown';
    let statusColor = 'gray';
    if (vehicle.online === 'offline') {
        statusText = 'Offline';
        statusColor = vehicle.icon_colors?.offline || 'gray';
    } else if (vehicle.speed > 0) {
        statusText = 'Moving';
        statusColor = vehicle.icon_colors?.moving || 'green';
    } else {
        statusText = 'Stopped';
        statusColor = vehicle.icon_colors?.stopped || 'orange';
    }

    const getSensorValue = (name) => {
        const sensor = vehicle.sensors?.find(s => s.name.toLowerCase().includes(name.toLowerCase()));
        return sensor ? sensor.value : 'N/A';
    };

    const latitude = vehicle.lat ? parseFloat(vehicle.lat).toFixed(7) : 'N/A';
    const longitude = vehicle.lng ? parseFloat(vehicle.lng).toFixed(7) : 'N/A';
    const mileage = vehicle.total_distance !== undefined
        ? `${vehicle.total_distance.toFixed(2)} ${vehicle.unit_of_distance || 'km'}`
        : 'N/A';

    const speed = vehicle.speed !== undefined ? `${vehicle.speed} km/h` : '0 km/h';
    const fuelReading = getSensorValue('External Volts'); // Change name if needed

    const html = `
        <div class='info-card'>
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 10px;">
                <span style="display:inline-block;width:10px;height:10px;background:${statusColor};border-radius:50%;"></span>
                <span style="font-weight:bold">${statusText}</span>
                <span style="font-size: 11px; color: #888; margin-left:auto;">${vehicle.time || ''}</span>
            </div>
            <div style="font-size:13px;">

                <div class="info-item">
                    <i class="bi bi-geo-alt-fill icon"></i>
                    <span><b>Lat, Lng:</b> ${latitude}, ${longitude}</span>
                </div>

                  <div class="info-item">
                    <i class="bi bi-signpost-split icon"></i>
                    <span><b>Mileage: ${mileage} km</span>
                  </div>

                  <div class="info-item">
                    <i class="bi bi-speedometer2 icon"></i>
                    <span><b>Speed:</b> ${speed} km/h</span>
                  </div>

                  <div class="info-item">
                    <i class="bi bi-fuel-pump icon"></i>
                    <span><b>Fuel:</b> ${fuelReading}</span>
                  </div>
            </div>
        </div>
    `;


    if (asHtml) return html;

    // For sidebar use
    const card = document.createElement('div');
    card.className = 'info-card';
    card.innerHTML = html;
    makeCardDraggable(card);
    return card;
}


document.addEventListener("DOMContentLoaded", async () => {
    const vehicleIdsParam = new URLSearchParams(window.location.search).get("vehicleId");
    const vehicleIds = vehicleIdsParam ? vehicleIdsParam.split(',') : [];
    console.log("Selected Vehicle ID:", vehicleIds);
    if (!vehicleIds) return alert("❌ Missing vehicleId in URL");

    const token = await autoLoginToGetToken();
    if (!token) return;

    try {
        const res = await fetch(`http://localhost:7085/api/external/devices?user_api_hash=${encodeURIComponent(token)}`);
        const text = await res.text();
        const data = JSON.parse(text);

        console.log("Fetched device data:", data);

        let allDevices = [];
        data.forEach(group => {
            if (Array.isArray(group.items)) {
                allDevices = allDevices.concat(group.items);
            }
        });

        console.log("All Vehicles:", allDevices);

        const matchingVehicles = allDevices.filter(v => vehicleIds.includes(v.id.toString()));
        if (matchingVehicles.length === 0) return alert("❌ Vehicle(s) not found");

        const cardsContainer = document.getElementById("vehicleCards");
        cardsContainer.innerHTML = ''; // Clear old cards

        // Initialize map
        const map = L.map('vehicleMap').setView([30.1575, 71.5249], 6);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
        const bounds = [];

        matchingVehicles.forEach(selected => {
            // --- Sidebar Card Render (Jaisa pehle tha) ---
            cardsContainer.appendChild(createInfoCard(selected));

            const lat = parseFloat(selected.device_data?.traccar?.lastValidLatitude);
            const lng = parseFloat(selected.device_data?.traccar?.lastValidLongitude);

            if (!isNaN(lat) && !isNaN(lng)) {
                // --- Custom Vehicle Icon (API se) ---
                const marker = L.marker([lat, lng], {
                    icon: createVehicleIcon(selected),   // yeh aapka naya function hai
                    rotationAngle: selected.device_data?.traccar?.course || 0 // agar available ho
                }).addTo(map);

                // --- Marker Click par Card Popup ---
                const cardHtml = createInfoCard(selected, true); // true = HTML string for popup
                marker.bindPopup(cardHtml, {
                    closeButton: false,
                    minWidth: 250,
                    autoPan: true,
                    offset: [0, -(
                        (selected.icon && selected.icon.height) ? selected.icon.height : 36
                    )], // icon ki height ke hisaab se thora upar
                    className: 'vehicle-popup-card'
                });
                marker.on('click', function () {
                    marker.openPopup();
                });

                bounds.push([lat, lng]);

                // --- Vehicle Trail/Path ---
                let trail = [];
                if (selected.device_data?.traccar?.latest_positions) {
                    trail = selected.device_data.traccar.latest_positions
                        .split(";")
                        .map(pair => {
                            const [latStr, lngStr] = pair.split("/");
                            const lat = parseFloat(latStr);
                            const lng = parseFloat(lngStr);
                            return (!isNaN(lat) && !isNaN(lng)) ? [lat, lng] : null;
                        })
                        .filter(coord => coord !== null);
                }

                if (trail.length > 1) {
                    const path = L.polyline(trail, { color: 'blue' }).addTo(map);
                    bounds.push(...trail);
                }
            }
        });

        if (bounds.length > 0) {
            map.fitBounds(bounds);
        }

        

        // ✅ LIVE UPDATE EVERY 10 SECONDS
        setInterval(async () => {
            try {
                const token = localStorage.getItem('apiToken');
                if (!token) return;

                const res = await fetch(`http://localhost:7085/api/external/devices?user_api_hash=${encodeURIComponent(token)}`);
                const text = await res.text();
                const data = JSON.parse(text);


                let allDevices = [];
                data.forEach(group => {
                    if (Array.isArray(group.items)) {
                        allDevices = allDevices.concat(group.items);
                    }
                });

                const updatedVehicles = allDevices.filter(v => vehicleIds.includes(v.id.toString()));
                if (updatedVehicles.length === 0) return;

                // 🧽 Remove old markers and cards
                map.eachLayer(layer => {
                    if (layer instanceof L.Marker || layer instanceof L.Polyline) map.removeLayer(layer);
                });

                cardsContainer.innerHTML = '';

                const newBounds = [];

                updatedVehicles.forEach(vehicle => {
                    cardsContainer.appendChild(createInfoCard(vehicle));

                    const lat = parseFloat(vehicle.device_data?.traccar?.lastValidLatitude);
                    const lng = parseFloat(vehicle.device_data?.traccar?.lastValidLongitude);

                    if (!isNaN(lat) && !isNaN(lng)) {
                        const marker = L.marker([lat, lng], {
                            icon: createVehicleIcon(vehicle),
                            rotationAngle: vehicle.device_data?.traccar?.course || 0
                        }).addTo(map);

                        const cardHtml = createInfoCard(vehicle, true);
                        marker.bindPopup(cardHtml, {
                            closeButton: false,
                            minWidth: 250,
                            autoPan: true,
                            offset: [0, -((vehicle.icon && vehicle.icon.height) ? vehicle.icon.height : 36)],
                            className: 'vehicle-popup-card'
                        });
                        marker.on('click', function () {
                            marker.openPopup();
                        });

                        newBounds.push([lat, lng]);

                        let trail = [];
                        if (vehicle.device_data?.traccar?.latest_positions) {
                            trail = vehicle.device_data.traccar.latest_positions
                                .split(";")
                                .map(pair => {
                                    const [latStr, lngStr] = pair.split("/");
                                    const lat = parseFloat(latStr);
                                    const lng = parseFloat(lngStr);
                                    return (!isNaN(lat) && !isNaN(lng)) ? [lat, lng] : null;
                                })
                                .filter(coord => coord !== null);
                        }

                        if (trail.length > 1) {
                            const path = L.polyline(trail, { color: 'blue' }).addTo(map);
                            newBounds.push(...trail);
                        }
                    }
                });
                

            } catch (err) {
                console.error("❌ Live update failed:", err);
            }
        },5000); // 🔁 every 10 seconds


    } catch (err) {
        console.error("❌ Error loading vehicle data:", err);
    }
});