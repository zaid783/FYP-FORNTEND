﻿const apiBaseUrl = "http://localhost:7085";
let isFetchingDispenser = false;
let dispenserData = [];

// Wait until the full HTML (DOM) is loaded, then start fetching dispenser data and auto-refresh every 30 seconds
document.addEventListener("DOMContentLoaded", () => {
    fetchAndRenderDispenserData();
    setInterval(() => {
        console.log("♻️ Auto-refreshing Dispenser data...");
        fetchAndRenderDispenserData();
    }, 30000);
});

async function fetchAndRenderDispenserData() {
    if (isFetchingDispenser) return;
    isFetchingDispenser = true;

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/dispenser-monitoring`);
        if (!response.ok) throw new Error("❌ Failed to fetch data");

        const data = await response.json();
        console.log("✅ Dispenser data:", data);

        // Example structure assumption: { "data_table": [...] }
        dispenserData = data.data_table || [];

        renderSummaryCards(dispenserData, data.cards);
        renderDispenserTable(dispenserData);

    } catch (err) {
        console.error("🚨 Error loading dispenser data:", err.message);
    } finally {
        isFetchingDispenser = false;
    }
}

function renderSummaryCards(data, cards) {
    // Safely assign card values from the 'cards' object
    if (document.getElementById("card1")) {
        document.getElementById("card1").innerText = cards.total_dispensed_volume_blue.toFixed(2);
    }
    if (document.getElementById("card2")) {
        document.getElementById("card2").innerText = cards.total_sale_value_green.toFixed(2);
    }
    if (document.getElementById("card3")) {
        document.getElementById("card3").innerText = cards.total_dispensed_volume_yellow.toFixed(2);
    }
    if (document.getElementById("card4")) {
        document.getElementById("card4").innerText = cards.total_sale_value_red.toFixed(2);
    }
}


function renderDispenserTable(data) {
    const table = $('#tankTable').DataTable({
        destroy: true,
        data: data,
        columns: [
            { data: 'pump', title: 'Pump' },
            { data: 'status', title: 'Status' },
            { data: 'dispenser_id', title: 'Dispenser ID' },
            { data: 'fuel_type', title: 'Fuel Type' },
            { data: 'price_omr', title: 'Price (OMR)' },
            { data: 'volume_liters', title: 'Volume (Liters)' },
            { data: 'total_amount_omr', title: 'Amount (OMR)' },
            { data: 'timestamp', title: 'Timestamp' }
        ],
        dom: 'Bfltip',
        lengthMenu: [[5, 10, 20, -1], [5, 10, 20, "All"]],
        pageLength: 10,
        buttons: [
            { extend: 'copy', text: 'Copy' },
            { extend: 'csv', text: 'CSV' },
            { extend: 'excel', text: 'Excel' },
            { extend: 'pdf', text: 'PDF' },
            { extend: 'print', text: 'Print' }
        ],
        initComplete: function () {
            $(".dt-buttons").after($(".dataTables_length"));
        }
    });
}

