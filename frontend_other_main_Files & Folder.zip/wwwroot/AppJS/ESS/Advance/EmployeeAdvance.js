﻿import { GETAPIURL, GETBYID, FILLCOMBO, POST, PUT, DELETE, CLEAR } from "../../Service/ApiService.js";
import { Roles } from "../../Service/Security.js";
const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");


// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')

var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon_table");


var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/AdvanceSalary';
    ComponentsDropdowns.init();
    var minDate = moment();

    $("#txt_advancedate").attr("min", minDate.format("YYYY-MM"));

    discon();
});

var ComponentsDropdowns = function () {

    var handleSelect2 = function () {
        LoadCurrentEmployee();
    }
    return {
        init: function () {
            handleSelect2();
        }
    };
}();



function LoadCurrentEmployee() {
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");
    $("#sel_employee_advance").text(currentEmployeeName)

    if (currentEmployeeID != -1 && currentEmployeeID != null) {
        $.ajax({
            url: GETAPIURL("/api/v1/PayrollLovService/GetEmployeesDetailLov"),
            type: "GET", // Change "Get" to "GET" for consistency
            contentType: "application/json",
            dataType: "json",
            data: { Search: currentEmployeeID }, // Pass data using the "data" option
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            },
            success: function (response) {
                if (response != null && response.data != null) {
                    var data = response.data;
                    $('#txt_department').text(data.departmentName);
                    $('#txt_salary').text(data.salary);
                }
            },
            error: function (xhr, status, err) {
                $('#txt_department').text('');
                $('#txt_salary').text('');
                Swal.fire({
                    title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                    width: 800,
                    icon: 'error',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                });
            }
        });
    }
};

const clearModal = () => {
    var code = $("#txt_code").val()
    $('input[type="text"]').val('');
    $('input[type="date"]').val(''); // Reset date inputs to an empty string
    $('#sel_request_status').text("--");
    $("#txt_remarks").text("--");
    $('select').val("-1").trigger("change");
    $('.error-icon').css('display', 'none');
    $("#txt_code").val(code)
}


// DISCONNECTION FUNCTION
function discon() {
    var code = $("#txt_code").val()
    Onload();
    CLEAR();
    clearModal();
    btn_update.hide();
    btn_save.show()
    $("#txt_code").val(code)
}

// PATCHING DATA FUNCTION
function patchdata(response) {
    $('#txt_id').val(response.id);

    var formattedDate = moment(response.date);
    $('#sel_employee_advance').val(response.personalInformationId).trigger("change");
    $('#txt_advancedate').val(moment(formattedDate).format("YYYY-MM"));
    $('#txt_department').val(response.departmentName);
    $('#txt_salary').val(response.salary);
    $('#txt_advancesalary').val(response.advancedSalary);
    $('#txt_reason').val(response.reason);
    $('#txt_remarks').text(response.remarks);
    $('#sel_request_status').text(response.status)
    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");

    var txt_id = $('#txt_id').val();

    var txt_advancesalary = $('#txt_advancesalary').val();

    var txt_advancedate = $('#txt_advancedate').val(); // "YYYY-MM"

    var formattedDate = moment(txt_advancedate + '-01').format("YYYY-MM-DD");

    //var txt_advancedate = moment($('#txt_advancedate').val()).format("YYYY-MM-DD");
    var txt_reason = $('#txt_reason').val();
    var txt_remarks = $('#txt_remarks').text();
    var txt_salary = $('#txt_salary').text();

    var ck = 0;
    var _Error = '';


    if (txt_reason == '') {
        ck = 1;
        _Error = 'Please enter reason for advance request.';
        $('#txt_reason').focus();
    }

    if (txt_advancesalary == '') {
        ck = 1;
        _Error = 'Please enter the advance amount.';

        $('#txt_advancesalary').focus();
    } else if (txt_advancesalary <= 0) {
        ck = 1;
        _Error = 'Please enter a valid advance amount.';

        $('#txt_advancesalary').focus();
    }
    else if (parseFloat(txt_advancesalary) > parseFloat(txt_salary)) {
        ck = 1;
        _Error = 'The advance requested amount cannot exceed employee\'s basic salary.';
        $('#txt_advancesalary').focus();
    }

    if (txt_advancedate == '') {
        ck = 1;
        _Error = 'Please enter the date for advance request.';

        $('#txt_advancedate').focus();
    };


    if (txt_id == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "advancedSalary": txt_advancesalary,
            "date": formattedDate,
            "reason": txt_reason,
            "remarks": txt_remarks,
            "personalInformationId": currentEmployeeID,
            "status": "PENDING",
            "type": "U",
            "menuId": menuId

        });
    }
    return { ckval: ck, creteria: _cre };
}

// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");
    $("#sel_employee_advance").text(currentEmployeeName)
    $.ajax({
        url: GETAPIURL(end_point + "/GetAdvanceSalaryByEmployee"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
            xhr.setRequestHeader('_Id', currentEmployeeID);
        },
        success: function (response) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }

            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; } },
                            { data: 'employeeCode' },
                            { data: 'employeeName' },
                            { data: 'departmentName' },
                            { data: 'date', "render": function (data, type, full, meta) { return moment(data).format('MMMM') }},
                            { data: 'salary' },
                            { data: 'advancedSalary' },
                            { data: 'status' },
                            {
                                data: 'reason', "render": function (data, type, full, meta) {
                                    if (data && data.length > 25) { // Adjust 25 to your desired max length
                                        return data.substr(0, 25) + "...";
                                    } else {
                                        return data;
                                    }
                                }
                            },
                            {
                                data: 'remarks', "render": function (data, type, full, meta) {
                                    if (data && data.length > 25) { // Adjust 25 to your desired max length
                                        return data.substr(0, 25) + "...";
                                    } else {
                                        return data;
                                    }
                                }
                            },
                            {
                                data: null,
                                "render": function (data, type, full, meta) {
                                    var action_button = "";
                                    if (full.permissionView) {
                                        action_button += "<a href='#' class='btn-edit fas fa-eye' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                                    }
                                    if (full.status === "PENDING") {
                                        action_button += "<a href='#' class='btn-delete fas fa-times' data-toggle='tooltip' style='color:#2c445c' title='Cancel'></a> ";
                                    }
                                    return action_button;
                                }
                            },
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    $("#txt_code").val(response.data[0].lastCode)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").val(1)
                }
            }
        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }

            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}

// OPEN MODAL NEW EMPLOYEE BUTTON EVENT
$('div').on('click', '#openmodal', function (e) {
    var code = $("#txt_code").val()
    clearModal();
    CLEAR();
    btn_update.hide();
    btn_save.show();
    var currentDate = moment().format("YYYY-MM-DD");

    //$("#txt_advancedate").attr("min", currentDate);


    $("#txt_advancedate").val(currentDate);
    $("#sel_employee_advance").prop("disabled", false)
    $("#txt_advancedate").prop("disabled", false)
    $("#txt_advancesalary").prop("disabled", false);
    $("#txt_reason").prop("disabled", false);
    $("#txt_code").val(code)
});

// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddAdvanceSalary", _cre, function () {
        discon();
    }, formActionSpinners);
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateAdvanceSalary", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['employeeName'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.hide();
    btn_save.hide();
    $("#sel_employee_advance").prop("disabled", true);
    $("#txt_advancedate").prop("disabled", true);
    $("#txt_advancedate").prop("disabled", true);
    $("#txt_advancesalary").prop("disabled", true);
    $("#txt_reason").prop("disabled", true);
    await GETBYID(end_point + "/GetAdvanceSalaryById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))

});

// CANCEL BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['employeeName'];
    var type = data['type'];

    var _cre = JSON.stringify({
        type: 'U',
        status: 'CANCELLED',
        id: _Id,
        menuId: menuId,
        reason: data['reason'],
        remarks: data['remarks'],
        advancedSalary: data['advancedSalary'],
        date: data["date"],
    });

    Swal.fire({
        title: 'Information',
        text: 'Are you sure you want to cancel this request?',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: GETAPIURL(end_point + "/UpdateAdvanceSalary"),
                    type: "PUT",
                    contentType: "application/json",
                    dataType: "json",
                    data: _cre,
                    beforeSend: function (xhr) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "inline-block");
                        }
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                    },
                    success: function (response) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        if (response.statusCode == 200) {
                            $('#data_Model').modal('hide');
                            Onload();
                            Swal.fire({
                                title: response.message,
                                icon: 'success',
                                showConfirmButton: true,
                            })
                        }
                        else {
                            Swal.fire({
                                title: response.message,
                                icon: 'warning',
                                showConfirmButton: true,
                            })
                        }
                    },
                    error: function (xhr, status, err) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        Swal.fire({
                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                            width: 800,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                })
            }
        })

    return true;
});

