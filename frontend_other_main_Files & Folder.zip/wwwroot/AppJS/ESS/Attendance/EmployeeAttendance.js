﻿import { GETAPIURL, FILLCOMBO, GETBYID, POST, PUT, DELETE, CLEAR } from "../../Service/ApiService.js";

// INITIALIZING VARIBALES
var end_point;
var report_end_point;
var btn_save_in = $('#btn_sav_checkin')
var btn_update_in = $('#btn_upd_checkin')
var btn_add_in = $('#openmodal_checkin')


var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}


// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/AttendanceManagementLovService';
    report_end_point = '/api/v1/ReportLovService';
    discon();

});

var ComponentsDropdowns = function () {
    var handleSelect2 = function () {
        LoadCurrentEmployee()
    }
    return {
        init: function () {
            handleSelect2();
        }
    };
}();

$('#openmodal_checkin').on('click', function (e) {
    var code = $("#txt_code").text()
    clearModal();
    CLEAR();
    ComponentsDropdowns.init();
    render_dates();
    btn_update_in.hide();
    btn_save_in.show()
    $("#txt_code").text(code)
});


const clearModal = () => {
    $('input[type="text"]').val('');
    $('.error-icon').css('display', 'none');
}

function LoadCurrentEmployee() {
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");

    if (currentEmployeeID != -1 && currentEmployeeID != null) {
        $.ajax({
            url: GETAPIURL("/api/v1/PayrollLovService/GetEmployeesDetailLov"),
            type: "GET", // Change "Get" to "GET" for consistency
            contentType: "application/json",
            dataType: "json",
            data: { Search: currentEmployeeID }, // Pass data using the "data" option
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            },
            success: function (response) {
                if (response != null && response.data != null) {
                    var data = response.data;
                    $('#txt_name').text(data.name);
                    $('#txt_department').text(data.departmentName);
                    $('#txt_salary').text(`${data.salary} /-`);
                    $('#txt_designation').text(data.designationName);
                }
            },
            error: function (xhr, status, err) {
                $('#txt_department').text('');
                $('#txt_salary').text('');
                Swal.fire({
                    title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                    width: 800,
                    icon: 'error',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                });
            }
        });
    }
};


function render_dates() {
    var yesterday = moment().subtract(1, 'days').format("YYYY-MM-DDTHH:mm");
    var today = moment().format("YYYY-MM-DDTHH:mm");
    var t = $("#txt_checkin").val();

    $("#txt_checkin").val(today);
    $("#txt_checkin").attr('max', today);
}


// DISCONNECTION FUNCTION
function discon() {
    var code = $("#txt_code").val()
    const currentDate = new Date();
    Onload();
    $("#txt_code").val(code)
}



$(document).on('click', '#search', function (e) {
    e.preventDefault();
    var _month = $('#txt_date').val();
    if (loaderIcon) {
        loaderIcon.style.display = "block";
    }
    Onload();

});


// ONLOAD FUNCTION
//--------------------------------
function Onload() {
    var tbl_row_cnt = 1;
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");

    $.ajax({
        url: GETAPIURL(end_point + "/GetEmployeeAttendanceRequests"),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_MenuId', menuId);
            xhr.setRequestHeader('_EmployeeId', currentEmployeeID);
        },
        success: function (response) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; } },
                            { data: 'employeeCode' },
                            { data: 'employeeName' },
                            { data: 'checkType' },
                            { data: 'attendanceDateTime', "render": function (data, type, full, meta) { return moment(data).format("DD MMM-YYYY") } },
                            { data: 'attendanceDateTime', "render": function (data, type, full, meta) { return moment(data).format("hh:mm A") } },
                            { data: 'status'},
                        ],
                        "order": [[0, "asc"]],
                        "pageLength": 25,

                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    //$("#txt_code").text(response.data[0].code)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").text(1)
                }
            }
        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}

function ckvalidationIn() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var txt_id = $('#txt_id');

    var currentEmployeeID = localStorage.getItem("Id");
    var txt_checkin = $('#txt_checkin');
    var checktype = $("#sel_checkstate").val();
    var reason = $("#reason_txt").val();
    console.log(reason);

    if (txt_id.val() == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id.val()
    }

    if (checktype == "") {
        _Error = "Please select a valid IN/OUT status!";
        ck = 1;
    }
    if (currentEmployeeID == null || currentEmployeeID == "") {
        _Error = "Please reload to refresh your employement details!";
        ck = 1;
    }
    if (reason == null || reason == "") {
        _Error = "Please write a valid reason for Attendance Request"
        ck = 1;
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "attendanceDateTime": txt_checkin.val(),
            "checkType": checktype,
            "personalInformationId": currentEmployeeID,
            "type": "U",
            "status": "PENDING",
            "reason": reason,
            "menuId": menuId

        });
    }
    return { ckval: ck, creteria: _cre };
}

// ADD BUTTON EVENT
$('form').on('click', '#btn_sav_checkin', function (e) {
    var ck = ckvalidationIn();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddCheckInOutRequest", _cre, function () {
        $("#data_Modal_In").modal("hide");
        discon();
    }, formActionSpinners);
});
