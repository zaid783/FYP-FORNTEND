import { GETAPIURL, FILLCOMBO, GETBYID, POST, PUT, DELETE, CLEAR } from "../../Service/ApiService.js";

// Form Request Name get from URL param
var url = new URLSearchParams(window.location.search);
var Id = window.atob('YWQwOTg5ZTEtNWJmYy00Y2FmLTk4YWUtMDhkYzdhNDNkMjg3');


var calendarEl = document.getElementById('ess_monthly_calendar');
var calendar = null;


if (url.has('M')) {
    Id = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {  
    var _name = document.getElementById("name")
    _name.innerText = "Welcome, " + localStorage.getItem("UserName")

    Render_calender(new Date())

    LoadProfile();
    CardsOnload();
});

function LoadProfile() {
    $.ajax({
        url: GETAPIURL("/api/v1/CompanySetup/GetCompanySetup"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + localStorage.getItem(api_signature));
            xhr.setRequestHeader('_MenuId', Id);
        },
        success: function (response) {
            if (response != null && response.data != null) {
                if (response.data != null) {
                    if (response.data.companyProfile == "") {
                        $('#company_logo_dashboard').attr('src', '/img/paydaylogo.png');
                    } else {
                        if (response.data.onDashboard == "true") {
                            $('#company_logo_dashboard').attr('src', response.data.companyProfile);
                        }
                    }
                }
            }
        },
    })
}

// ONLOAD FUNCTION
function CardsOnload() {
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");

    $.ajax({
        url: GETAPIURL("/api/v1/Dashboard/GetESSDashboardData"),
        type: "GET",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function(xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_EmployeeID' , currentEmployeeID);
        },
        success: function (response) {
            var tbl_row_cnt = 1;
            
            if (response != null) {
                // TOP CARD
                $("#txt_ess_total_days").text(response.data.totalAttendanceDays);
                $("#txt_ess_present_days").text(response.data.totalPresentDays);
                $("#txt_ess_absent_days").text(response.data.totalAbsentDays);
                $("#txt_ess_late_days").text(response.data.totallateDays);

                //CODE BY AB__________________________________________________________________________
                // CHECK-IN, CHECK-OUT, AND REMARK DISPLAY
                var checkInTime = response.data.checkInTime || "-";
                var checkOutTime = response.data.checkOutTime || "-";
                var remark = response.data.remarks || "-";

                $("#checkInTime").text(checkInTime);
                $("#checkOutTime").text(checkOutTime);
                $("#remark").text(remark);
                //====================================================================================
                // REQUEST LIST
                if (response.data.requestsList != null) {
                    $('#ess_requests_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#ess_requests_table").DataTable({
                        data: response.data.requestsList,
                        destroy: true,
                        searching: false,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: [],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; } },
                            { data: 'type' },
                            {
                                data: 'date',
                                "render": function (data, type, full, meta) {
                                    if (full.type == "Advance Request" || full.type == "Loan Request") {
                                        return moment(data, 'M/D/YYYY h:mm:ss A').format('MMMM, YYYY');
                                    } else {
                                        return moment(data, 'M/D/YYYY h:mm:ss A').format('DD MMM, YYYY');
                                    }
                                }
                            },
                            { data: 'status' },
                            {
                                data: 'remarks', "render": function (data, type, full, meta) {
                                    if (data && data.length > 25) { // Adjust 25 to your desired max length
                                        return data.substr(0, 25) + "...";
                                    } else {
                                        return data;
                                    }
                                }
                            },
                        ],
                        "order": [[0, "asc"]],
                        "pageLength": 5,
                    });
                    //datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                } else {
                    $('#ess_requests_table').DataTable().clear().destroy();
                    $("#ess_requests_table").DataTable();
                }

                // CALENDAR
                // CODE FOR CALENDAR DATE MARKING HERE
                response.data.attendanceList.forEach(function (attendance) {
                    var eventColor;
                    switch (attendance.status.toUpperCase())
                    {
                        case 'PRESENT':
                            eventColor = '#3D7387';
                            break;
                        case 'ABSENT':
                            eventColor = '#FF0000';
                            break;
                        case 'LATE':
                            eventColor = '#e6ea00';
                            break;
                        case 'HALFDAY':
                            eventColor = '#71F2BA';
                            break;
                        case 'QUARTERDAY':
                            eventColor = '#8c564b';
                            break;
                        default:
                            eventColor = '';
                    }
                    calendar.addEvent({
                        title: attendance.status,
                        start: moment(attendance.date).format("YYYY-MM-DD"),
                        extendedProps: {
                            color: eventColor
                        }
                    });
                });


                // LEAVE RADIAL CHART
                RenderLeavesChart(response.data);

                //ATTENDANCE RATE
                var presentRate = [];
                presentRate.push(response.data.attendanceRate)
                RenderPresenceChart(presentRate[0]);
                //ABSENT RATE
                var absentRate = [];
                absentRate.push(response.data.absentRate)
                RenderAbsenceChart(absentRate[0]);


                //MONTHLY ATTENDANCE
                RenderAttendanceChart(response.data.monthlyAttendanceData)

            }
        },
        error: function (xhr, status, err) {
            Swal.fire({
                title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                width:800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}






function Render_calender(date) {
    calendar = new FullCalendar.Calendar(calendarEl, {
        themeSystem: 'bootstrap',
        initialView: 'dayGridMonth',
        initialDate: date,
        headerToolbar: {
            left: '',
            center: '',
            right: ''
        },
        events: [],
        displayEventTime: false,
        eventContent: function (arg) {
            var eventText = document.createElement('div');
            eventText.innerText = arg.event.title;

            eventText.style.backgroundColor = arg.event.extendedProps.color;
            eventText.style.width = '100%';
            eventText.style.color = 'white';
            eventText.style.fontWeight = 'bold';
            eventText.style.fontSize = "10px";
            eventText.style.textAlign = 'center';
            eventText.style.border = '0px solid red';
            return { domNodes: [eventText] };
        },
    });
    calendar.render();
}



// LEAVES CHART
function RenderLeavesChart(data) {
    const fixedColors = ['#71F2BA', '#3d7387', '#2C445C'];

    const leavesData = [
        { leaveLabel: "Total", count: 1 },
        { leaveLabel: "Remaining", count: 2 },
        { leaveLabel: "Availed", count: 3 }
    ];

    const leavesNames = data.leaveData.map(item => item.label);
    const leavesCounts = data.leaveData.map(item => item.count);

    const pieOptions = {
        chart: {
            type: 'pie',
            width: '100%',
            height: 300
        },
        labels: leavesNames,
        series: leavesCounts,
        colors: fixedColors,
        dataLabels: {
            enabled: true,
            textAnchor: 'middle',
            dropShadow: {
                enabled: true,
                top: 1,
                left: 1,
                blur: 1,
                color: '#000',
                opacity: 0.45
            },
            enabledOnSeries: undefined,
            formatter: function (val, opts) {
                const index = opts.seriesIndex;
                return leavesCounts[index];
            },
            style: {
                fontSize: '16px',
                fontWeight: "bold"
            }
        },
        legend: {
            position: 'bottom',
            itemMargin: {
                vertical: 0
            },
            labels: {
                fontSize: '16px' // Increased font size for legend
            }
        }
    };

    const pieChart = new ApexCharts(document.querySelector("#ess_leaves_chart"), pieOptions);
    pieChart.render();
}

// PRESENCE RATE
function RenderPresenceChart(value) {
    const options = {
        chart: {
            height: 280,
            type: 'radialBar',
            toolbar: {
                show: false
            },
        },
        plotOptions: {
            radialBar: {
                startAngle: -135,
                endAngle: 225,
                hollow: {
                    margin: 0,
                    size: '70%',
                    background: '#fff',
                    image: undefined,
                    imageOffsetX: 0,
                    imageOffsetY: 0,
                    position: 'front',
                    dropShadow: {
                        enabled: true,
                        top: 3,
                        left: 0,
                        blur: 4,
                        opacity: 0.24
                    }
                },
                track: {
                    background: '#fff',
                    strokeWidth: '67%',
                    margin: 0,
                    dropShadow: {
                        enabled: true,
                        top: -3,
                        left: 0,
                        blur: 4,
                        opacity: 0.35
                    }
                },
                dataLabels: {
                    show: true,
                    name: {
                        offsetY: -10,
                        show: true,
                        color: '#888',
                        fontSize: '14px'
                    },
                    value: {
                        formatter: function (val) {
                            return `${parseInt(val)}%`;
                        },
                        color: '#111',
                        fontSize: '30px',
                        fontWeight: "bold",
                        show: true,
                    }
                }
            }
        },
        fill: {
            type: 'gradient',
            gradient: {
                shade: 'dark',
                type: 'horizontal',
                shadeIntensity: 0.5,
                gradientToColors: ['#ABE5A1'],
                inverseColors: true,
                opacityFrom: 1,
                opacityTo: 1,
                stops: [0, 100]
            }
        },
        stroke: {
            lineCap: 'round'
        },
        labels: ['PRESENT RATE'],
        series: [value]
    };

    var chart = new ApexCharts(document.querySelector("#ess_attendance_rate_chart"), options);
    chart.render();
}

// ABSENCE RATE
function RenderAbsenceChart(value) {
    const options = {
        chart: {
            height: 280,
            type: 'radialBar',
            toolbar: {
                show: false
            },
        },
        plotOptions: {
            radialBar: {
                startAngle: -135,
                endAngle: 225,
                hollow: {
                    margin: 0,
                    size: '70%',
                    background: '#fff',
                    image: undefined,
                    imageOffsetX: 0,
                    imageOffsetY: 0,
                    position: 'front',
                    dropShadow: {
                        enabled: true,
                        top: 3,
                        left: 0,
                        blur: 4,
                        opacity: 0.24
                    }
                },
                track: {
                    background: '#fff',
                    strokeWidth: '67%',
                    margin: 0,
                    dropShadow: {
                        enabled: true,
                        top: -3,
                        left: 0,
                        blur: 4,
                        opacity: 0.35
                    }
                },
                dataLabels: {
                    show: true,
                    name: {
                        offsetY: -10,
                        show: true,
                        color: '#888',
                        fontSize: '14px'
                    },
                    value: {
                        formatter: function (val) {
                            return `${parseInt(val)}%`;
                        },
                        color: '#111',
                        fontSize: '36px',
                        fontWeight: "bold",
                        show: true,
                    }
                }
            }
        },
        fill: {
            type: 'gradient',
            gradient: {
                shade: 'dark',
                type: 'horizontal',
                shadeIntensity: 0.5,
                gradientToColors: ['red'],
                inverseColors: false,
                opacityFrom: 1,
                opacityTo: 1,
                stops: [0, 100]
            }
        },
        stroke: {
            lineCap: 'round'
        },
        labels: ['ABSENT RATE'],
        series: [value] // Using the passed value here
    };

    var chart = new ApexCharts(document.querySelector("#ess_absent_rate_chart"), options);
    chart.render();
}

// RENDER DAILY ATTENDANCE 
function RenderAttendanceChart(data) {
    var dateObjects = data.totalDates.map(dateString => new Date(dateString));
    var formattedDates = data.totalDates.map(date => moment(date).format('DD MMM'));

    var stackoptions = {
        series: [
            {
                name: 'Present',
                data: data.totalAttendancePresent
            },
            {
                name: 'Late',
                data: data.totalAttendanceLate
            },
            {
                name: 'Early Going',
                data: data.totalAttendanceEarlyGoing
            },
            {
                name: 'Half Day',
                data: data.totalAttendanceHalfday
            },
            {
                name: 'Quarter Day',
                data: data.totalAttendanceQuarterday
            },
            {
                name: 'Absent',
                data: data.totalAttendanceAbsent
            },
        ],
        chart: {
            type: 'bar',
            height: 350,
            stacked: true,
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        responsive: [
            {
                breakpoint: 480,
                options: {
                    legend: {
                        position: 'bottom',
                        offsetX: -10,
                        offsetY: 0
                    }
                }
            }
        ],
        plotOptions: {
            bar: {
                horizontal: false,
                borderRadius: 10,
                dataLabels: {
                    enabled: false // Hide data labels
                }
            }
        },
        xaxis: {
            type: 'string',
            categories: formattedDates,
            min: Math.min(...dateObjects),
            max: Math.max(...dateObjects),
            stepSize: 0,
            labels: {
                show: true,
                hideOverlappingLabels: true
            }
        },
        legend: {
            position: 'right',
            offsetY: 40
        },
        fill: {
            opacity: 1
        },
        dataLabels: {
            enabled: false // Hide data labels
        },
        colors: ['#3D7387', '#e6ea00', '#e87700', '#71F2BA', '#8c564b', '#FF0000'],
        //colors: ['PRESENT', '#LATE', '#EG', '#HD', '#QD', '#ABSENT'],

    };


    var stackchartclear = document.querySelector("#ess_monthly_attendance_summary");

    if (stackchartclear) {
        stackchartclear.innerHTML = "";
    }

    var stackchart = new ApexCharts(document.querySelector("#ess_monthly_attendance_summary"), stackoptions);
    stackchart.render();
}
