﻿import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR, FILLCOMBO, FILLCOMBOBYID, FILLCOMBOWIHOUTSELECT2 } from "../../Service/ApiService.js";
import { Roles } from "../../Service/Security.js";

const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");

// INITIALIZING VARIBALES


var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon");


var end_point;
var end_point_employee;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')

var btn_add = $('#openmodal')
var date_div = $('#date_div')
var isApprovalModal = false;

var btn_addrecord = $('#btn_addrecord')
var btn_searchrecord = $('#btn_searchrecord')
var leave_date_wise_table = $('#leave_date_wise_table')
var multi_leave_date_wise_table = $('#multi_leave_date_wise_table')
var tbl_leave_date_wise_table = $('#leave_date_wise_table tbody');
var table = $('#leave_date_wise_table');
var leaveTypeContainer = $("#leaveTypeContainer");
var availableLeaves = 0;

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/LeaveRequest';
    end_point_employee = '/api/v1/LeaveManagementLovService';
    discon();
    ComponentsDropdowns.init();
});

// --- Fill Select 2 of Module ---
var ComponentsDropdowns = function () {
    var handleSelect2 = function () {
        LoadCurrentEmployee();
    }
    return {
        init: function () {
            handleSelect2();
        }
    };
}();

$('#openmodal').on('click', function (e) {
    discon()
});

function LoadCurrentEmployee() {
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");
    $("#sel_employee_leave").text(currentEmployeeName)

    if (currentEmployeeID != -1 && currentEmployeeID != null) {
        $.ajax({
            url: GETAPIURL("/api/v1/PayrollLovService/GetEmployeesDetailLov"),
            type: "GET", // Change "Get" to "GET" for consistency
            contentType: "application/json",
            dataType: "json",
            data: { Search: currentEmployeeID }, // Pass data using the "data" option
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            },
            success: function (response) {
                if (response != null && response.data != null) {
                    var data = response.data;
                    $('#txt_department').text(data.departmentName);
                }
            },
            error: function (xhr, status, err) {
                $('#txt_department').text('');
                Swal.fire({
                    title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                    width: 800,
                    icon: 'error',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                });
            }
        });
    }
};
function LoadLeaveType() {
    // var $element = $('.leave-type').select2();
    var $element = $('.leave-type');
    FILLCOMBOWIHOUTSELECT2('/api/v1/LeaveManagementLovService/GetLeaveTypeLov', $element, "Leave Type")
}
function LoadLeavesQuota() {
    var empoyeeId = localStorage.getItem("Id");
    if (empoyeeId != "" && empoyeeId != null) {
        $.ajax({
            url: GETAPIURL("/api/v1/LeaveManagementLovService/GetEmployeeLeavesByIdLov"),
            type: "Get",
            contentType: "application/json",
            dataType: "json",
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                xhr.setRequestHeader('_Id', empoyeeId);
                xhr.setRequestHeader('_MenuId', menuId);
            },
            success: function (response) {
                if (response != null && response.data != null) {
                    var res = response.data
                    RemainingCircleBar(res.TotalRemainingLeaves);
                    UtilizedCircleBar(res.TotalAllowedLeaves - res.TotalRemainingLeaves);
                    RenderLeaveTypes(res.TypeWise)
                    $('#total_leaves').text(res.TotalAllowedLeaves)
                    $('#total_leaves_bar').text(res.TotalAllowedLeaves)
                    $('#req_remaining').text(res.TotalRemainingLeaves)
                }
            },
            error: function (xhr, status, err) {
                Swal.fire({
                    title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                    width: 800,
                    icon: 'error',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                })
            }
        })

    }
}

// DISCONNECTION FUNCTION
function discon() {
    Onload();
    CLEAR();

    LoadLeavesQuota();

    btn_update.hide();
    btn_save.show();


    leaveTypeContainer.empty();
    availableLeaves = 0;
    var currentDate = new Date();
    $("#txt_fromdate").val(moment(currentDate).format("yyyy-MM-DD"));
   // $("#txt_fromdate").attr('min', moment(currentDate).format("yyyy-MM-DD"));
    var fromDate = new Date(currentDate);
    $('#txt_todate').attr('min', formatDate(fromDate));
    $("#txt_todate").val(moment(currentDate).format("yyyy-MM-DD"));

    btn_addrecord.show();
    btn_searchrecord.hide();
    leave_date_wise_table.show();

    $("#chart_container").show();
    $('#leave_date_wise_table tbody').empty();
    $('#txt_request_status').text("--");
    RemainingCircleBar(0);
    UtilizedCircleBar(0);
    $('#total_leaves').text(0);
    date_div.show();
}

function formatDate(date) {
    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();
    day = day < 10 ? '0' + day : day;
    month = month < 10 ? '0' + month : month;
    return year + '-' + month + '-' + day;
}

// PATCHING DATA FUNCTION
function patchdata(response) {
    formActionSpinners.css("display", "none");
    modalActionSpinners.css("display", "none");
    date_div.hide();

    var tbl_leave_date_wise_table = $('#leave_date_wise_table tbody');
    
    if (response.leaveRequestBaseModel.status === "P") {
        $("#txt_request_status").text("PENDING");
    } else if (response.leaveRequestBaseModel.status === "A") {
        $("#txt_request_status").text("APPROVED");
    } else if (response.leaveRequestBaseModel.status == "D") {
        $("#txt_request_status").text("CANCELLED");
    } else {
        $("#txt_request_status").text("--");
    }

    var row = '<tr>';
    row += '<td> <i class="fa fa-trash deleteItem_Detail"></i></td>';
    row += '<td hidden>' + response.leaveRequestBaseModel.id + '</td>';
    row += '<td>' + moment(response.leaveRequestBaseModel.date).format("DD-MMM-YYYY") + '</td>';
    row += '<td><select class="form-control leave-type" disabled id="sel_leavetype"></select></td>';
    row += '<td><select class="form-control leave-day" disabled id="sel_leaveDay"><option value="Full">Full Day</option><option value="Half">Half Day</option></select></td>';
    row += '<td><input type="text" id="reason" disabled class="form-control reason"></td>';
    row += '<td><input type="text" id="remarks" disabled class="form-control remarks"></td>';
    row += '</tr>';

    tbl_leave_date_wise_table.append(row);

    LoadLeaveType();
    setTimeout(() => {
        var leaveTypeSelect = tbl_leave_date_wise_table.find('.leave-type');
        leaveTypeSelect.val(response.leaveRequestBaseModel.leaveTypeId).trigger('change');
        var leaveDaySelect = tbl_leave_date_wise_table.find('.leave-day');
        leaveDaySelect.val(response.leaveRequestBaseModel.leaveDay).trigger('change');
        var leaveDaySelect = tbl_leave_date_wise_table.find('.reason');
        leaveDaySelect.val(response.leaveRequestBaseModel.reason).trigger('change');
        var leaveDaySelect = tbl_leave_date_wise_table.find('.remarks');
        leaveDaySelect.val(response.leaveRequestBaseModel.remarks).trigger('change');
    }, 500);
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var txt_id = $('#txt_id');
    var txt_code = $('#txt_code');

    var currentEmployeeID = localStorage.getItem("Id");
    var tbl_leave_date_wise_table = $('#leave_date_wise_table tbody tr');
    if (tbl_leave_date_wise_table.length > 0) {
        tbl_leave_date_wise_table.each(function () {
            var row = $(this);
            var date = row.find('td:eq(2)').text();
            var leaveType = row.find('.leave-type').val();
            var leaveDay = row.find('.leave-day').val();
            var reason = row.find('.reason').val();
            var remarks = row.find('.remarks').val();
            if (leaveType == -1) {
                ck = 1;
                _Error = "Select Leave Type on the date of " + moment(date).format("DD-MMM-YYYY")
                return false
            } else if (leaveDay == "") {
                ck = 1;
                _Error = "Select leave day on the date of " + moment(date).format("DD-MMM-YYYY")
                return false
            } else if (reason == "") {
                ck = 1;
                _Error = "Select reason on the date of " + moment(date).format("DD-MMM-YYYY")
                return false
            }
        });
    }
    if (tbl_leave_date_wise_table.length == 0) {
        ck = 1;
        _Error = 'Please select dates for leave request';
    }
    if (currentEmployeeID == -1) {
        ck = 1;
        _Error = 'Please refresh browser to load employee details!';
        sel_employee.focus();
    }

    if (txt_id.val() == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id.val()
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }
    else if (!Boolean(ck)) {
        var payload = [];
        tbl_leave_date_wise_table.each(function () {
            var row = $(this);
            var Id = row.find('td:eq(1)').text();
            var date = row.find('td:eq(2)').text();
            var leaveType = row.find('.leave-type').val();
            var leaveDay = row.find('.leave-day').val();
            var reason = row.find('.reason').val();
            var remarks = row.find('.remarks').val();

            var record = {
                id: Id === "null" ? null : Id,
                date: moment(date).format("YYYY-MM-DD"),
                leaveTypeId: leaveType,
                leaveDay: leaveDay,
                reason: reason,
                remarks: remarks,
                status: "P",
                type: "U",
            };
            payload.push(record);
        });
        _cre = JSON.stringify({
            employeeId: currentEmployeeID,
            leaveRequests: payload,
            menuId: menuId

        });
    }
    return { ckval: ck, creteria: _cre };
}

// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    var currentEmployeeID = localStorage.getItem("Id");

    $.ajax({
        url: GETAPIURL(end_point + "/GetLeaveByEmployee"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_MenuId', menuId);
            xhr.setRequestHeader('_Id', currentEmployeeID);
        },
        success: function (response) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                
                if (response.data != null) {
                    $("#total_approved").text(response.data.filter(x => x.status === "A").length)
                    $("#total_pending").text(response.data.filter(x => x.status === "P").length)
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { data: 'date', "render": function (data, type, full, meta) { return moment(data).format("YYYY-MM-DD") } },
                            { data: 'leaveType' },
                            { data: 'leaveDay' },
                            {
                                data: 'reason', "render": function (data, type, full, meta) {
                                    if (data && data.length > 25) { // Adjust 25 to your desired max length
                                        return data.substr(0, 25) + "...";
                                    } else {
                                        return data;
                                    }
                                }
                            },
                            {
                                data: 'remarks', "render": function (data, type, full, meta) {
                                    if (data && data.length > 25) { // Adjust 25 to your desired max length
                                        return data.substr(0, 25) + "...";
                                    } else {
                                        return data;
                                    }
                                }
                            },
                            {
                                data: 'status', "render": function (data, type, full, meta) {
                                    if (data === "A") {
                                        return "<p style='color: green;font-weight: bold;'> Approved <span><i class='align-middle mr-2 fas fa-fw fa-check-square'></i></span> </p>";
                                    } else if (data === "P") {
                                        return "<p style='color: #2c445c;font-weight: bold;' > Pending <span><i class='align-middle mr-2 fas fa-fw fa-spinner'></i></span> </p>";
                                    } else if (data === "D") {
                                        return "<p style='color: red;font-weight: bold;'> CANCELLED <span> <i class='align-middle mr-2 fas fa-fw fa-exclamation-triangle'></i> </span> </p>";
                                    }
                                }
                            },
                            {
                                data: 'status', "render": function (data, type, full, meta) {
                                    if (data === "P") {
                                        return "<a href='#' class='btn-edit fas fa-eye' data-toggle='tooltip' style='color:#2c445c' title='View'></a> <a href='#' class='btn-decline fas fa-times' data-toggle='tooltip' style='color:#2c445c' title='Decline'> </a> "
                                    } else if(data === "A") {
                                        return "<a href='#' class='btn-edit fas fa-eye' data-toggle='tooltip' style='color:#2c445c' title='View'> </a> ";
                                    } else {
                                        return "<span>-</span>"
                                    }
                                    
                                }
                            }, 
                        ],
                        "order": [[0, "desc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                }
            }


        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}





// GRAPHS | CHARTS
function UtilizedCircleBar(_progressEndValue) {
    let circularProgress = document.querySelector(".utilized-circular-progress"),
        progressValue = circularProgress.querySelector(".progress-value");
    let progressStartValue = 0,
        progressEndValue = _progressEndValue,
        speed = 5;



    let progress = setInterval(() => {
        if (_progressEndValue != 0) {
            progressStartValue += 0.5;
        }
        progressValue.textContent = `${progressStartValue}`
        circularProgress.style.background = `conic-gradient(red ${(progressStartValue / 0.30) * 3.6}deg, #ededed 0deg)`
        if (progressStartValue == progressEndValue) {
            clearInterval(progress);
        }
    }, speed);
}
function RemainingCircleBar(_progressEndValue) {
    let circularProgress = document.querySelector(".remaining-circular-progress"),
        progressValue = circularProgress.querySelector(".progress-value");
    let progressStartValue = 0, progressEndValue = _progressEndValue, speed = 5;

    availableLeaves = progressEndValue;

    if (isApprovalModal) {
        $('#txt_fromdate').removeAttr('min');
        $('#txt_fromdate').removeAttr('max');
        $('#txt_todate').removeAttr('max');
        $('#txt_todate').removeAttr('min');
    } else {
        var totalDayToAdd = 0;
        var selectStartDate = $('#txt_fromdate').val();
        totalDayToAdd = Math.ceil(availableLeaves);
        var tillDateLimit = moment(selectStartDate).add(totalDayToAdd - 1, "days");
        $('#txt_todate').attr('max', moment(tillDateLimit).format("yyyy-MM-DD"));
    }

    let progress = setInterval(() => {
        if (_progressEndValue != 0) {
            progressStartValue += 0.5;
        }
        progressValue.textContent = `${progressStartValue}`
        circularProgress.style.background = `conic-gradient(#3e4676 ${(progressStartValue / 0.30) * 3.6}deg, #ededed 0deg)`
        if (progressStartValue == progressEndValue) {
            clearInterval(progress);
        }
    }, speed);
}
function RenderLeaveTypes(_categories) {
    leaveTypeContainer.empty();
    if (typeof _categories !== 'object' || _categories === null) {
        console.error("_categories is not an object");
        return;
    }

    for (let key in _categories) {
        if (_categories.hasOwnProperty(key)) {
            const item = _categories[key];
            var typeItem = `<div class="col-sm-2 col-md-2 col-lg-2 col-xl-2 col-xxl-2 text-center pt-1">
                                    <h6>${key}</h6>
                                    <div class="col-sm-2 col-md-4 col-lg-10 col-xl-12 col-xxl-12 pt-2  ">
                                        <center><div class="utilized-circular-progress">
                                            <div class="progress-value" style="font-size: 18px">${item}</div>
                                        </div></center>
                                    </div>
                                </div>
                                <hr/>
                                `;
            leaveTypeContainer.append(typeItem);
        }
    }
}



// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddLeaveRequest", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = localStorage.getItem("UserName");
    var _fName = _name.split(" ")[0];

    $("#chart_container").hide();

    btn_save.hide()
    $('#leave_date_wise_table tbody').empty();
    await GETBYID(end_point + "/GetLeaveRequestById", _id, menuId, _fName, function (response) {
        patchdata(response)
    }, $(this));

});


// DATE PICKERS
$('#txt_fromdate').change(function (e) {
    var date = $('#txt_fromdate').val();
    $("#txt_todate").val(moment(date).format("yyyy-MM-DD"));
    var fromDate = new Date(date);
    $('#txt_todate').attr('min', formatDate(fromDate));

    if (isApprovalModal) {
        $('#txt_fromdate').removeAttr('min');
        $('#txt_fromdate').removeAttr('max');
        $('#txt_todate').removeAttr('max');
        $('#txt_todate').removeAttr('min');
    } else {
        var totalDayToAdd = 0;
        if (availableLeaves > 0) {
            totalDayToAdd = Math.ceil(availableLeaves);
            var tillDateLimit = moment(fromDate).add(totalDayToAdd - 1, "days");
            $('#txt_todate').attr('max', moment(tillDateLimit).format("yyyy-MM-DD"));
        }
    }
})

$('#btn_addrecord').on('click', function () {
    var startDate = $('#txt_fromdate').val();
    var endDate = $('#txt_todate').val();

    var currentDate = new Date(startDate);
    while (currentDate <= new Date(endDate)) {
        var formattedDate = moment(currentDate).format("DD-MMM-YYYY");
        var dateExists = false;
        if (tbl_leave_date_wise_table.length > 0) {
            tbl_leave_date_wise_table.find('tr').each(function () {
                var existingDate = $(this).find('td:eq(2)').text();
                if (existingDate === formattedDate) {
                    dateExists = true;
                    return false;
                }
            });
        }
        if (!dateExists) {
            var row = '<tr>' +
                '<td> <i class="fa fa-trash deleteItem_Detail"></i></td>' +
                '<td hidden>' + null + '</td>' +
                '<td>' + formattedDate + '</td>' +
                '<td><select class="form-control leave-type" id="sel_leavetype"></select></td>' +
                '<td><select class="form-control leave-day" id="sel_leaveDay"><option value="Full">Full Day</option><option value="Half">Half Day</option></select></td>' +
                '<td><input type="text" id="reason" class="form-control reason"></td>' +
                '<td><p id="remarks" class="remarks"></p>' +
                '</tr>';

            tbl_leave_date_wise_table.append(row);
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    LoadLeaveType();
});

$('form').on('click', '.delete-button', function () {
    $(this).closest('tr').remove();
});



$(document).on('click', '.deleteItem_Detail', function (e) {
    Swal.fire({
        title: "Are you sure, want to delete?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: 'success',
        cancelButtonColor: 'secondary',
        confirmButtonText: 'Delete',
    }).then((result) => {
        if (result.value) {
            e.preventDefault();
            $(this).parents('tr').css("background-color", "#ff6347").fadeOut(800, function () {
                $(this).remove();
                $(this).closest('tr');
            });
        }
    })
});

$(document).on('click', '.all_deleteItem_Detail', function (e) {
    var tableRows = $('tbody tr');
    if (tableRows.length === 0) {
        Swal.fire({
            title: "No Record Found",
            icon: 'warning',
        })
        return;
    }
    Swal.fire({
        title: "Are you sure, want to delete?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: 'success',
        cancelButtonColor: 'secondary',
        confirmButtonText: 'Delete',
    }).then((result) => {
        if (result.value) {
            e.preventDefault();
            tableRows.css("background-color", "#ff6347").fadeOut(800, function () {
                $(this).remove();
            });

        }
    })
});




// DECLINE BUTTON EVENT 
$('table').on('click', '.btn-decline', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['employeeName'];
    var type = data['type'];
    Swal.fire({
        title: 'Information',
        text: 'Are you sure you want to Decline this Request?',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: GETAPIURL("/api/v1/LeaveManagementLovService/DeclineLeaveRequest"),
                    type: "POST",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("_Id", _id);
                        xhr.setRequestHeader("_MenuId", menuId);
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                    },
                    success: function (response) {
                        if (response.statusCode == '200') {
                            Swal.fire({
                                title: response.message,
                                icon: 'success',
                            })
                            Onload()
                        }
                        else {
                            Swal.fire({
                                title: response.message,
                                icon: 'warning',
                            })
                        }
                    },
                    error: function (xhr, status, err) {
                        Swal.fire({
                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                })
            }
        })
});

// APPROVED BUTTON EVENT 
$('#btn_searchrecord').on('click', function () {
    var currentEmployeeID = localStorage.getItem("Id");
    var txt_fromdate = $('#txt_fromdate');
    var txt_todate = $('#txt_todate');

    if (currentEmployeeID == null || currentEmployeeID == "") {
        Swal.fire({
            title: 'Please refresh your current session to load employement details!',
            icon: 'error'
        })

        return
    }

    var employeeId = currentEmployeeID;
    var dateFrom = moment(txt_fromdate.val()).format("YYYY-MM-DD");
    var dateTo = moment(txt_todate.val()).format("YYYY-MM-DD");
    $.ajax({
        url: GETAPIURL("/api/v1/LeaveManagementLovService/GetMultiLeaveRequest"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("employeeId", employeeId);
            xhr.setRequestHeader("DateFrom", dateFrom);
            xhr.setRequestHeader("DateTo", dateTo);
            xhr.setRequestHeader("_MenuId", menuId);
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
        success: function (response) {
            if (response.statusCode == '200') {
                var row = ""
                for (let index = 0; index < response.data.length; index++) {
                    var tbl_leave_date_wise_table = $('#multi_leave_date_wise_table tbody');
                    row += '<tr>';
                    row += '<td> <i class="fa fa-trash deleteItem_Detail"></i></td>';
                    row += '<td hidden>' + response.data[index].id + '</td>';
                    row += '<td>' + moment(response.data[index].date).format("DD-MMM-YYYY") + '</td>';
                    row += '<td><select class="form-control leave-type" id="sel_leavetype' + index + '"></select></td>';
                    row += '<td><select class="form-control leave-day" id="sel_leaveDay' + index + '" ><option value="Full">Full Day</option><option value="Half">Half Day</option></select></td>';
                    row += '<td><input type="text" id="reason' + index + '" class="form-control reason" ></td>';
                    row += '<td><input type="text" id="remarks' + index + '" class="form-control remarks" ></td>';
                    if (response.data[index].status == "A") {
                        row += "<td><p style='color: green;font-weight: bold;font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;'> Approved <span><i class='align-middle mr-2 fas fa-fw fa-check-square'></i></span> </p></td>";
                    } else if (response.data[index].status == "P") {
                        row += "<td><p style='color: #2c445c;font-weight: bold;font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;' > Pending <span><i class='align-middle mr-2 fas fa-fw fa-spinner'></i></span> </p></td>";
                    } else if (response.data[index].status == "D") {
                        row += "<td><p style='color: red;font-weight: bold;font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;'> Decline <span> <i class='align-middle mr-2 fas fa-fw fa-exclamation-triangle'></i> </span> </p></td>";
                    }
                    row += '<td><input type="checkbox" id="ck_checkstatus' + index + '" class="form-control ck_checkstatus" ></td>';
                    row += '</tr>';
                }
                tbl_leave_date_wise_table.append(row);
                LoadLeaveType();
                setTimeout(() => {
                    for (let index = 0; index < response.data.length; index++) {
                        var leaveTypeSelect = tbl_leave_date_wise_table.find('#sel_leavetype' + index);
                        leaveTypeSelect.val(response.data[index].leaveTypeId).trigger('change');
                        var leaveDaySelect = tbl_leave_date_wise_table.find('#sel_leaveDay' + index);
                        leaveDaySelect.val(response.data[index].leaveDay).trigger('change');
                        var leaveDaySelect = tbl_leave_date_wise_table.find('#reason' + index);
                        leaveDaySelect.val(response.data[index].reason).trigger('change');
                        var leaveDaySelect = tbl_leave_date_wise_table.find('#remarks' + index);
                        leaveDaySelect.val(response.data[index].remarks).trigger('change');

                        var ck_status = tbl_leave_date_wise_table.find('#ck_checkstatus' + index);
                        var status = response.data[index].status === "A" ? true : false
                        ck_status.prop('checked', status);

                    }
                }, 500);
            }
            else {
                Swal.fire({
                    title: response.message,
                    icon: 'warning',
                })
            }
        },
        error: function (xhr, status, err) {
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                icon: 'error',
                showConfirmButton: true,
            })
        }
    })
});
