﻿import { GETAPIURL, GETBYID, POST, PUT, DELETE, CLEAR, FILLCOMBO, FILLCOMBOBYID, FILLCOMBOWIHOUTSELECT2 } from "../../Service/ApiService.js";
import { Roles } from "../../Service/Security.js";
const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");

// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')
var date_div = $('#date_div')

var formActionSpinners = $(".btn-spinner");
var modalActionSpinners = $(".modal-spinner");
var loaderIcon = document.getElementById("loader_icon_table");

var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {
    end_point = '/api/v1/EmployeeLoan';
    ComponentsDropdowns.init();
    discon()
});



var ComponentsDropdowns = function () {
    var handleSelect2 = function () {
        LoadCurrentEmployee();

    }
    return {
        init: function () {
            handleSelect2();
        }
    };
}();


const clearModal = () => {
    var code = $("#txt_code").val()
    $('input[type="text"]').removeAttr('disabled').val('');
    $('input[type="number"]').removeAttr('disabled').val('');
    $('input[type="date"]').removeAttr('disabled').val('');
    $('select').val("-1").removeAttr('disabled').trigger("change");
    $('.error-icon').css('display', 'none');
    $("#txt_code").val(code)

    //$("#txt_name").text("");
    //$("#txt_department").text("");
    //$("#txt_designation").text("");
    //$("#txt_salary").text("");
    //$("#sel_request_status").text("");

    $("#totalLoanInputs").empty();
    $("#totalLoanValue").removeAttr('disabled').text("");
    $("#remainingLoanValue").removeAttr('disabled').text("");
    $("#unadjustedLoanValue").removeAttr('disabled').text("");
    $("#generate_installments").removeAttr("hidden");
    $('#txt_startmonth').removeAttr('disabled');
    $('#txt_endmonth').removeAttr('disabled');
}

function LoadCurrentEmployee() {
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");
    $("#txt_name").text(currentEmployeeName)

    if (currentEmployeeID != -1 && currentEmployeeID != null) {
        $.ajax({
            url: GETAPIURL("/api/v1/PayrollLovService/GetEmployeesDetailLov"),
            type: "GET", // Change "Get" to "GET" for consistency
            contentType: "application/json",
            dataType: "json",
            data: { Search: currentEmployeeID }, // Pass data using the "data" option
            beforeSend: function (xhr) {
                xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            },
            success: function (response) {
                if (response != null && response.data != null) {
                    var data = response.data;
                    $('#txt_department').text(data.departmentName);
                    $('#txt_salary').text(data.salary);
                    $('#txt_designation').text(data.designationName);
                }
            },
            error: function (xhr, status, err) {
                $('#txt_department').text('');
                $('#txt_designation').text("");
                $('#txt_salary').text('');
                Swal.fire({
                    title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                    width: 800,
                    icon: 'error',
                    showConfirmButton: true,
                    showClass: {
                        popup: 'animated fadeInDown faster'
                    },
                    hideClass: {
                        popup: 'animated fadeOutUp faster'
                    }
                });
            }
        });
    }
}



$('div').on('click', '#openmodal', function (e) {
    clearModal();
    CLEAR();
    var today = new Date();
    var month = (today.getMonth() + 1).toString().padStart(2, '0');
    var year = today.getFullYear();
    var defaultValue = `${year}-${month}`;
    $("#sel_request_status").text("--");

    $('#txt_startmonth').val(defaultValue);
    $('#txt_endmonth').val(defaultValue);
    $('#txt_startmonth').attr('min', defaultValue);
    $('#txt_endmonth').attr('min', defaultValue);
    btn_update.hide();
    btn_save.hide();
});


$("#generate_installments").on("click", () => {
    var txt_loan = $('#txt_loan');
    var txt_startmonth = $('#txt_startmonth');
    var txt_endmonth = $('#txt_endmonth');
    var txt_salary = $('#txt_salary').text();
    var container = $("#totalLoanInputs");
    container.empty();
    $("#totalLoanValue").text("0");
    $("#remainingLoanValue").text("0");
    $("#unadjustedLoanvalue").text("0");

    if (txt_startmonth.val() > txt_endmonth.val()) {
        Swal.fire({
            title: 'Please select a valid monthly duration!',
            icon: 'error'
        })
        return;
    }

    if (txt_endmonth.val() == '') {
        Swal.fire({
            title: 'Please enter installment ending month',
            icon: 'error'
        })
        txt_endmonth.focus();
        return;
    }
    if (txt_startmonth.val() == '') {
        Swal.fire({
            title: 'Please enter installment start month.',
            icon: 'error'
        })
        txt_startmonth.focus();
        return;
    }
    if (txt_loan.val() == '' || txt_loan.val() <= 0) {
        Swal.fire({
            title: 'Please enter the loan amount',
            icon: 'error'
        })
        txt_loan.focus();
        return;
    }
    var startMonth = moment(txt_startmonth.val());
    var endMonth = moment(txt_endmonth.val());
    var monthRangeCount = endMonth.diff(startMonth, "months")
    monthRangeCount++;

    if (monthRangeCount > 60) {
        Swal.fire({
            title: "Repayment range cannot exceed 5 years duration.",
            icon: 'error'
        })
        return;
    }

    var permonthAmount = parseFloat(txt_loan.val()) / monthRangeCount;
    if (permonthAmount > parseFloat(txt_salary)) {
        Swal.fire({
            title: 'Please monthly installment amount exceeds monthly salary!',
            icon: 'error'
        })
        return;
    }
    var totalLoanValue = txt_loan.val();
    var remainingLoanvalue = txt_loan.val()
    var unadjustedLoanValue = txt_loan.val()

    $("#totalLoanValue").text(totalLoanValue);
    $("#remainingLoanValue").text(remainingLoanvalue);
    $("#unadjustedLoanvalue").text(unadjustedLoanValue);

    container.empty();
    var monthNames = [];
    for (var i = 0; i < monthRangeCount; i++) {
        var month = startMonth.clone().add(i, 'months');
        var monthName = month.format('MMMM YYYY');
        var dateStamp = moment(month).format('YYYY-MM-DD');
        monthNames.push(monthName);

        var item = `<div class="my-1 row justify-content-start align-items-center col-lg-4 installmentContainer">
                        <p hidden class="form-label col-lg-6 text-center font-weight-bold" style="font-size:18px;display: hidden">${dateStamp}</p>
                        <label class="form-label col-lg-6 text-center font-weight-bold" style="font-size:18px">${monthName}</label>
                        <div class="col-lg-6">
                            <input type="number" class="form-control did-floating-input loanValueInputs"  min="0" onkeypress="if(this.value.length==10) return false;" value="${permonthAmount.toFixed(1)}" />
                        </div>
                    </div>`;
        unadjustedLoanValue -= permonthAmount;
        container.append(item);
    }
    $("#unadjustedLoanValue").text(unadjustedLoanValue.toFixed(1));
    btn_save.show();
})

$(document).on("change", ".loanValueInputs", function () {
    var totalChangeLoan = 0;
    var totalLoan = $("#totalLoanValue").text();
    $(".loanValueInputs").each(function () {
        totalChangeLoan += parseFloat($(this).val());
    });

    var unadjusted = totalLoan - totalChangeLoan
    $("#unadjustedLoanValue").text(unadjusted.toFixed(1));
});

btn_save.on("click", function () {
    var totalChangeLoan = 0;
    var totalLoan = $("#totalLoanValue").text();
    $(".loanValueInputs").each(function () {
        totalChangeLoan += parseFloat($(this).val());
    });

    var remaining = totalLoan - totalChangeLoan
    if (Math.floor(remaining) > 0) {
        Swal.fire({
            title: "Repayment figures is not balanced to total loan requested!",
            icon: "error"
        })
    } else if (Math.ceil(remaining) < 0) {
        Swal.fire({
            title: "Repayment figures is greater to total loan requested!",
            icon: "error"
        })
    } else if (remaining < 1) {
        var ck = ckvalidation();
        var ckval = ck.ckval;
        if (ckval == 1) { return; }
        var _cre = ck.creteria;
        POST(end_point + "/AddLoan", _cre, function () {
            discon();
        }, formActionSpinners);
    } else {
        Swal.fire({
            title: "Repayment calculation is invalid!",
            icon: "error"
        })
    }
});

//DISCONNECTION FUNCTION
function discon() {
    Onload();
    CLEAR();
    clearModal();
    btn_update.hide();
    btn_save.hide()

    var currentDate = new Date();

    var today = new Date();
    var month = (today.getMonth() + 1).toString().padStart(2, '0');
    var year = today.getFullYear();
    var defaultValue = `${year}-${month}`;

    $('#txt_startmonth').val(defaultValue);
    $('#txt_endmonth').val(defaultValue);

    $('#sel_employeecode').val(-1).trigger('change');
}


// PATCHING DATA FUNCTION
function patchdata(response) {
    $('#txt_id').val(response.id);
    //$('#sel_employeecode').val(response.personalInformationId).trigger("change").attr("disabled", true);

    $('#txt_department').text(response.departmentName)
    $('#txt_designation').text(response.designationName)
    $('#txt_salary').text(response.salary)
    $('#sel_request_status').text(response.status)

    $('#txt_loan').val(response.totalLoanAmount).attr("disabled", true);
    $('#txt_startmonth').val(response.startMonth.slice(0, 7)).attr("disabled", true);
    $('#txt_endmonth').val(response.endMonth.slice(0, 7)).attr("disabled", true);
    $("#generate_installments").attr("hidden", true)
    $("#totalLoanValue").text(response.totalLoanAmount).attr("disabled", true);
    $("#remainingLoanValue").text(response.remainingLoanAmount).attr("disabled", true);

    var Installments = response.installments;
    var container = $("#totalLoanInputs");
    container.empty();


    $.each(Installments, (index, item) => {
        var cont = `<div class="my-1 row justify-content-start align-items-center col-lg-4 installmentContainer">
                        <p hidden class="form-label col-lg-6 text-center font-weight-bold" style="font-size:18px;display: hidden">${item.dateStamp}</p>
                        <label class="form-label col-lg-6 text-center font-weight-bold" style="font-size:18px">${item.month}</label>
                        <div class="col-lg-6">
                            <input style="background: ${item.status == "PAID" ? '#b1edcf' : true}" disabled type="number" class="form-control did-floating-input loanValueInputs"  min="0" onkeypress="if(this.value.length==10) return false;"
                            value="${item.amount}" />
                        </div>
                    </div>`;
        container.append(cont);
    })
    btn_save.hide();
    btn_update.hide();


    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '', id = '';
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");

    var txt_id = $('#txt_id').val();
    var txt_department = $('#txt_department').text();
    var txt_designation = $('#txt_designation').text();
    var txt_salary = $('#txt_salary').text();

    var txt_loan = $('#txt_loan').val();
    var txt_startmonth = $('#txt_startmonth').val();
    var txt_endmonth = $('#txt_endmonth').val();
    var totalAmount = $("#totalLoanValue").text();
    var remainingLoanValue = $("#remainingLoanValue").text();
    var txt_status = $('#sel_request_status').val();

    if (txt_loan == '') {
        ck = 1;
        _Error = 'Please enter the loan amount';
        txt_loan.focus();
    }

    if (currentEmployeeID == '' || currentEmployeeID == -1) {
        ck = 1;
        _Error = 'Please refresh to load your employement details!';
    }

    if (txt_startmonth == '') {
        ck = 1;
        _Error = 'Please enter installment start month.';
        txt_startmonth.focus();
    }

    if (txt_endmonth == '') {
        ck = 1;
        _Error = 'Please enter installment ending month';
        txt_endmonth.focus();
    }

    if (txt_id == '') {
        id = '00000000-0000-0000-0000-000000000000'
    }
    else {
        id = txt_id
    }

    var installmentsPayload = [];
    const divContainers = document.querySelectorAll('.installmentContainer');
    divContainers.forEach(container => {
        var installment = {
            dateStamp: container.querySelector("p").textContent.trim(),
            month: container.querySelector('label').textContent.trim(),
            amount: container.querySelector('input').value
        }
        installmentsPayload.push(installment);
    });
    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }
    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "departmentName": txt_department,
            "designationName": txt_designation,
            "personalInformationId": currentEmployeeID,
            "salary": txt_salary,
            "loanAmount": txt_loan,
            "startMonth": moment(txt_startmonth).format("YYYY-MM-DD"),
            "endMonth": moment(txt_endmonth).format("YYYY-MM-DD"),
            "totalLoanAmount": totalAmount,
            "remainingLoanAmount": remainingLoanValue,
            "installments": installmentsPayload,
            "status": "PENDING",
            "type": "U",
            "menuId": menuId
        });
    }
    return { ckval: ck, creteria: _cre };
}

// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    var currentEmployeeName = localStorage.getItem("UserName");
    var currentEmployeeID = localStorage.getItem("Id");
    $("#sel_employee_advance").text(currentEmployeeName)
    $.ajax({
        url: GETAPIURL(end_point + "/GetLoanByEmployee"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_MenuId', menuId);
            xhr.setRequestHeader('_Id', currentEmployeeID);
        },
        success: function (response) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            var action_button = ' ';
            if (response != null) {
                if (!response.permissions.insert_Permission) {
                    btn_add.hide()
                }
                if (response.data != null) {
                    $('#data_table').DataTable().clear().destroy();
                    var datatablesButtons = $("#data_table").DataTable({
                        data: response.data,
                        destroy: true,
                        retrieve: true,
                        processing: true,
                        lengthChange: !1,
                        buttons: ["pdf", "copy", "print", "csv"],
                        columns: [
                            { "render": function (data, type, full, meta) { return tbl_row_cnt++; } },
                            { data: 'date', "render": function (data, type, full, meta) { return moment(data).format("YYYY-MM-DD") } },
                            { data: 'employeeCode' },
                            { data: 'employeeName' },
                            { data: 'startMonth', "render": function (data, type, full, meta) { return moment(data).format("MMM-YYYY") } },
                            { data: 'endMonth', "render": function (data, type, full, meta) { return moment(data).format("MMM-YYYY") } },
                            { data: 'salary' },
                            { data: 'totalLoanAmount' },
                            { data: 'remainingLoanAmount' },
                            { data: 'status' },
                            {
                                data: null,
                                "render": function (data, type, full, meta) {
                                    var action_button = "";
                                    if (full.permissionView) {
                                        action_button += "<a href='#' class='btn-edit fas fa-eye' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
                                    }
                                    if (full.status === "PENDING") {
                                        action_button += "<a href='#' class='btn-delete fas fa-times' data-toggle='tooltip' style='color:#2c445c' title='Cancel'></a> ";
                                    }
                                    return action_button;
                                }
                            },
                        ],
                        "order": [[0, "asc"]],
                        //"pageLength": 10,
                    });
                    datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")
                    $("#txt_code").val(response.data[0].lastCode)
                } else {
                    $('#data_table').DataTable().clear().destroy();
                    $("#data_table").DataTable();
                    $("#txt_code").val(1)
                }
            }


        },
        error: function (xhr, status, err) {
            if (loaderIcon) {
                loaderIcon.style.display = "none";
            }
            Swal.fire({
                title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                width: 800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}


// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    console.log(_cre)
    PUT(end_point + "/UpdateLoan", _cre, function () {
        discon();
    }, formActionSpinners);
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['employeeName'];
    var type = data['type'];

    btn_update.hide();
    btn_save.hide()
    $('#leave_date_wise_table tbody').empty();
    await GETBYID(end_point + "/GetLoanById", _id, menuId, _name, function (response) {
        patchdata(response)
    }, $(this))
});

// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['employeeName'];
    var type = data['type'];

    var _cre = JSON.stringify({
        id: _Id,
        PersonalInformationId: menuId,
        menuId: menuId,
        type: 'U',
        status: 'CANCELLED',
    });

    Swal.fire({
        title: 'Information',
        text: 'Are you sure you want to cancel this request?',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: GETAPIURL(end_point + "/UpdateLoan"),
                    type: "PUT",
                    contentType: "application/json",
                    dataType: "json",
                    data: _cre,
                    beforeSend: function (xhr) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "inline-block");
                        }
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                    },
                    success: function (response) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        if (response.statusCode == 200) {
                            $('#data_Model').modal('hide');
                            Onload();
                            Swal.fire({
                                title: response.message,
                                icon: 'success',
                                showConfirmButton: true,
                            })
                        }
                        else {
                            Swal.fire({
                                title: response.message,
                                icon: 'warning',
                                showConfirmButton: true,
                            })
                        }
                    },
                    error: function (xhr, status, err) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        Swal.fire({
                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                            width: 800,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                })
            }
        })

    return true;
});
