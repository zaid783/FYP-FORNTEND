﻿
const apiBaseUrl = "http://localhost:7085";
let isFetchingDispenser = false;
let isFetchingAVI = false;
let dispenserData = [];
let aviData = [];

document.addEventListener("DOMContentLoaded", () => {
    fetchAndRenderDispenserData();
    fetchAndRenderAVIData(true); // First time load with dropdown + date

    setInterval(() => {
        console.log("♻️ Auto-refreshing Dispenser data...");
        fetchAndRenderDispenserData();
        console.log("♻️ Auto-refreshing AVI data...");
        fetchAndRenderAVIData(false); // Only update cards and table
    }, 30000);
});


// Fetch Dispenser Data
async function fetchAndRenderDispenserData() {
    if (isFetchingDispenser) return;
    isFetchingDispenser = true;

    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/dispenser-monitoring`);
        if (!response.ok) throw new Error("❌ Failed to fetch Dispenser data");

        const data = await response.json();
        console.log("✅ Dispenser data:", data);

        dispenserData = data.data_table || [];

        renderDispenserTable(dispenserData); // Render both cards and table from same data

        // Call after dispenser data is updated
        if (!isFetchingAVI) await sendDataToBackend();

    } catch (err) {
        console.error("🚨 Error loading dispenser data:", err.message);
    } finally {
        isFetchingDispenser = false;
    }
}

// Render Dispenser Table + Cards
function renderDispenserTable(dispensers) {
    const container = document.getElementById("vehicleCardsContainer");

    dispensers.forEach(disp => {
        const pumpId = disp.pump.replace(/\s+/g, "_"); // safe ID for element, e.g. Pump-1 -> Pump-1

        let card = document.getElementById(pumpId);
        const iconColor = disp.fuel_type === "Petrol" ? "text-primary" : "text-warning";
        const statusClass = disp.status === "online" ? "border-success" : "border-danger";

        // If card for this pump does NOT exist, create it once
        if (!card) {
            card = document.createElement("div");
            card.id = pumpId;
            card.className = "col-sm-6 col-xl-3";

            card.innerHTML = `
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4 mb-2 shadow-lg border-start ${statusClass} border-3" style="gap: 10px;">
                    <i class="fa fa-gas-pump fa-3x ${iconColor}"></i>
                    <div class="ms-1">
                        <p class="mb-2 card-title">${disp.pump} (<span class="status-text">${disp.status}</span>)</p>
                        <p class="mb-0 fuel-type">Fuel Type: ${disp.fuel_type}</p>
                        <h6 class="mb-0 fuel-volume">Fuel: ${disp.volume_liters.toFixed(2)} L</h6>
                        <h6 class="mb-0 price-omr">Price: ${disp.price_omr.toFixed(2)} OMR</h6>
                        <h6 class="mb-0 total-amount">Total: ${disp.total_amount_omr.toFixed(2)} OMR</h6>
                    </div>
                </div>
            `;
            container.appendChild(card);
        } else {
            
            const cardDiv = card.firstElementChild;
            cardDiv.className = `bg-light rounded d-flex align-items-center justify-content-between p-4 mb-2 shadow-lg border-start ${statusClass} border-3`;

            const icon = cardDiv.querySelector("i.fa-gas-pump");
            icon.className = `fa fa-gas-pump fa-3x ${iconColor}`;

            // Update text content inside card
            cardDiv.querySelector(".status-text").textContent = disp.status;
            cardDiv.querySelector(".fuel-volume").textContent = `Fuel: ${disp.volume_liters.toFixed(2)} L`;
            cardDiv.querySelector(".price-omr").textContent = `Price: ${disp.price_omr.toFixed(2)} OMR`;
            cardDiv.querySelector(".total-amount").textContent = `Total: ${disp.total_amount_omr.toFixed(2)} OMR`;
        }
    });
}


// Fetch AVI Data
async function fetchAndRenderAVIData(isInitialLoad = false) {
    if (isFetchingAVI) return;
    isFetchingAVI = true;


    try {
        const response = await fetch(`${apiBaseUrl}/api/sensordata/avi_vehicle`);
        if (!response.ok) throw new Error("❌ Failed to fetch AVI data");

        const data = await response.json();
        console.log("✅ AVI Data:", data);

        aviData = normalizeKeys(data.data_table || []);

        renderAVITable(aviData);
        
        // Call after avi data is updated
        if (!isFetchingDispenser) await sendDataToBackend();

    } catch (err) {
        console.error("🚨 Error loading AVI data:", err.message);
    } finally {
        isFetchingAVI = false;
    }
}


// ✅ Normalize keys (e.g., Total_Amount_OMR → total_amount_omr)
function normalizeKeys(dataArray) {
    return dataArray.map(item => ({
        sNo: item.S_No,
        vrn: item.VRN,
        tag: item.RFID_Tag_No,
        dispenser: item.Dispenser_Id,
        nozzle: item.Nozzle_Id,
        price: item.Price_OMR,
        volume: item.Volume_Liters,
        amount: item.Total_Amount_OMR,
        fuelType: item.Fuel_Type,
        timestamp: item.Timestamp
    }));
}


function renderAVITable(data) {
    if ($.fn.dataTable.isDataTable('#vehiclesTable')) {
        const table = $('#vehiclesTable').DataTable();
        table.clear();
        table.rows.add(data).draw();
    } else {
        $('#vehiclesTable').DataTable({
            data: data,
            columns: [
                { data: 'sNo', title: 'S.No' },
                { data: 'vrn', title: 'VRN' },
                { data: 'tag', title: 'Tag' },
                { data: 'dispenser', title: 'Dispenser' },
                { data: 'nozzle', title: 'Nozzle' },
                { data: 'price', title: 'Price (OMR)' },
                { data: 'volume', title: 'Volume (L)' },
                { data: 'amount', title: 'Amount (OMR)' },
                { data: 'fuelType', title: 'Fuel Type' },
                { data: 'timestamp', title: 'Timestamp' }
            ],
            dom: 'Bfltip',
            lengthMenu: [[5, 10, 20, -1], [5, 10, 20, "All"]],
            pageLength: 10,
            buttons: [
                { extend: 'copy', text: 'Copy' },
                { extend: 'csv', text: 'CSV' },
                { extend: 'excel', text: 'Excel' },
                { extend: 'pdf', text: 'PDF' },
                { extend: 'print', text: 'Print' }
            ],
            initComplete: function () {
                $(".dt-buttons").after($(".dataTables_length"));
            }
        });
    }
}


async function sendDataToBackend() {
    // Simple approach: For each dispenser, find matching AVI entries by dispenser ID
    for (const disp of dispenserData) {
        // Find all matching AVI records for this dispenser
        const matchingAVIs = aviData.filter(avi => avi.dispenser === disp.pump);

        // If no matching AVI, you might want to send dispenser data alone or skip
        if (matchingAVIs.length === 0) {
            await postSingleRecord(disp, null);
        } else {
            for (const avi of matchingAVIs) {
                await postSingleRecord(disp, avi);
            }
        }
    }
}
async function postSingleRecord(disp, avi) {
    const payload = {
        Pump: disp.pump,
        FuelType: disp.fuel_type,
        Status: disp.status,
        VolumeLiters: disp.volume_liters,
        PriceOmr: disp.price_omr,
        TotalAmountOmr: disp.total_amount_omr,

        Vrn: avi ? avi.vrn : null,
        RfidTag: avi ? avi.tag : null,
        DispenserId: avi ? avi.dispenser : null,
        NozzleId: avi ? avi.nozzle : null,
        AviPrice: avi && typeof avi.price === 'number' ? avi.price : 0,  // safe default
        AviVolume: avi && typeof avi.volume === 'number' ? avi.volume : 0,
        AviTotalAmount: avi && typeof avi.amount === 'number' ? avi.amount : 0,
        AviFuelType: avi ? avi.fuelType : null
    };

    try {
        const response = await fetch(`${apiBaseUrl}/api/EagleEye/eagleeye/log`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ dto: payload }) // ✅ wrap in dto
        });

        if (!response.ok) {
            const errText = await response.text();
            console.error("Failed to send log:", errText);
        } else {
            console.log(`Logged data for pump ${disp.pump}, vrn ${avi ? avi.vrn : "N/A"}`);
        }
    } catch (err) {
        console.error("Error sending log:", err);
    }
}

