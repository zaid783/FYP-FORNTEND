
var end_point;
$(document).ready(function () {
    setTimeout("location.href = 'Auth/SignIn';",100);
});


