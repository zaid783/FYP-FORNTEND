import  {GETAPIURL,GETBYID,POST,PUT,DELETE,CLEAR,FILLCOMBO}  from "../Service/ApiService.js";
import { Roles } from "../Service/Security.js";

// INITIALIZING VARIBALES
var end_point;
var btn_save = $('#btn_sav')
var btn_update = $('#btn_upd')
var btn_add = $('#openmodal')
var fromShortName = "BRN"

// Form Request Name get from URL param
var url = new URLSearchParams(window.location.search);
var menuId = '';
if (url.has('M')) {
    menuId = window.atob(url.get('M'));
}

// jQuery CONSTRUCTOR
$(document).ready(function () {  
    end_point = '/api/v1/Tenant';
    ComponentsDropdowns.init();
    discon();
  });

// DISCONNECTION FUNCTION
function discon(){
    Onload(); CLEAR(); 
    btn_update.hide();
    btn_save.show()

}

// --- Fill Select 2 of Module ---
var ComponentsDropdowns = function () {
    var handleSelect2 = function () {
        LoadTenant();  
    }
    return {
        init: function () {
            handleSelect2();
        }
    };
}();

// LOAD Tenant LOV
function LoadTenant() {
    var $element = $('#sel_comp').select2(); 
    FILLCOMBO('/api/v1/ConfigurationLovService/GetCompanyLov',$element)
}

// PATCHING DATA FUNCTION
function patchdata(response){
    $('#txt_id').val(response.id);
    $('#txt_code').val(response.code);
    $('#txt_name').val(response.name);
    $('#txt_sname').val(response.shortName);
    $('#sel_comp').val(response.companyId).trigger('change');
    $('#txt_address').val(response.address);
    $('#txt_phone').val(response.phone);
    $('#txt_mobile').val(response.mobile);
    $('#txt_email').val(response.email);
    if (!response.active) {
        $("#ck_act").prop("checked", false);
    } else { $("#ck_act").prop("checked", true); }
    $('#data_Model').modal();
}

// VALIDATION FUNCTION
function ckvalidation() {
    var ck = 0, _Error = '', _cre = '' ,id='';
    var txt_id = $('#txt_id');  
    var txt_code = $('#txt_code');   
    var txt_name = $('#txt_name');   
    var txt_sname = $('#txt_sname');   
    var sel_comp = $('#sel_comp');   
    var txt_phone = $('#txt_phone');   
    var txt_mobile = $('#txt_mobile');   
    var txt_email = $('#txt_email');   
    var txt_address = $('#txt_address');   
    var ck_act = $('#ck_act'); 
    
    if (txt_name.val() == '') {
        ck = 1;
        _Error = 'Tenant Name is required';
        txt_name.focus();
    }

    if (txt_sname.val() == '') {
        ck = 1;
        _Error = 'Short Name is required';
        txt_sname.focus();
    }
    
    if (txt_id.val() == '') {
        id= '00000000-0000-0000-0000-000000000000'
    }
    else{
        id = txt_id.val()
    }

    if (Boolean(ck)) {
        Swal.fire({
            title: _Error,
            icon: 'error'
        })
    }

    else if (!Boolean(ck)) {
        _cre = JSON.stringify({
            "id": id,
            "code": txt_code.val(),
            "name": txt_name.val(),
            "shortName": txt_sname.val(),
            "companyId": sel_comp.val(),
            "phone": txt_phone.val(),
            "mobile": txt_mobile.val(),
            "email": txt_email.val(),
            "address": txt_address.val(),
            "type": "U",
            "active": ck_act[0].checked,
        });
    }
    return { ckval: ck, creteria: _cre };
}


// ONLOAD FUNCTION
function Onload() {
    var tbl_row_cnt = 1;
    $.ajax({
        url: GETAPIURL(end_point + "/GetTenant"),
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function(xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader('_menuId', menuId);
        },
        success: function (response) {
            var action_button = ' ';
            if (!response.data[0].permissionAdd) {
                btn_add.hide()
            }
            if (response.data[0].permissionUpdate) {
                action_button += "<a href='#' class='btn-edit fas fa-edit' data-toggle='tooltip' style='color:#2c445c' title='Update'></a> ";
            }
            if (response.data[0].permissionDelete) {
                action_button += " <a href='#' class='btn-delete fas  fa-trash' data-toggle='tooltip' style='color:#2c445c' title='Delete()'></a> ";
            }
            if (response != null) {
                $('#data_table').DataTable().clear().destroy();
                var datatablesButtons = $("#data_table").DataTable({
                    data: response.data,
                    destroy: true,
                    retrieve: true,
                    processing: true,
                    lengthChange:!1,
                    buttons: ["pdf","copy", "print","csv"],
                    columns: [
                        { "render": function (data, type, full, meta) { return tbl_row_cnt++; }},
                        { data: 'code' },
                        { data: 'name' },
                        { data: 'shortName' },
                        { data: 'active','render': function (data, type, full, meta) {if (data) {return '✔'; }else { return '✘'; }  }},
                        { data: null,"defaultContent": action_button},
                    ],
                    "order": [[0, "asc"]],
                    //"pageLength": 10,
                });
                datatablesButtons.buttons().container().appendTo("#data_table_wrapper .col-md-6:eq(0)")

                if (response.data != null) {
                    $("#txt_code").val(response.data[0].lastCode)
                }
            }
        },
        error: function (xhr, status, err) {
            Swal.fire({
                title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                width:800,
                icon: 'error',
                showConfirmButton: true,
                showClass: {
                    popup: 'animated fadeInDown faster'
                },
                hideClass: {
                    popup: 'animated fadeOutUp faster'
                }
            })
        }
    })
    return true;
}

// OPEN MODAL BUTTON EVENT
$('div').on('click', '#openmodal', function (e) {
    var code = $("#txt_code").val()
    CLEAR();btn_update.hide();btn_save.show()
    $("#txt_code").val(code)
});

// ADD BUTTON EVENT
$('form').on('click', '#btn_sav', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    POST(end_point + "/AddTenant",_cre,function () {
        discon();
    });
});

// UPDATE BUTTON EVENT
$('form').on('click', '#btn_upd', function (e) {
    var ck = ckvalidation();
    var ckval = ck.ckval;
    if (ckval == 1) { return; }
    var _cre = ck.creteria;
    PUT(end_point + "/UpdateTenant",_cre,function () {
        discon();
    });
});

// EDIT BUTTON EVENT 
$('table').on('click', '.btn-edit', async function (e) { //Edit Start
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    btn_update.show();btn_save.hide()
    await GETBYID(end_point + "/GetTenantById", _id,_name, function (response) {
        patchdata(response)
    })
   
});

// DELETE BUTTON EVENT 
$('table').on('click', '.btn-delete', function (e) {
    e.preventDefault();
    var currentRow = $(this).closest("tr");
    var data = $('#data_table').DataTable().row(currentRow).data();
    var _Id = data['id'];
    var _name = data['name'];
    var type = data['type'];
    if (type == "S") {
        Swal.fire({
            title: "This is System Generated Record",
            icon: 'warning',
        })
        return
    }
    DELETE(end_point + "/DeleteTenant",_Id,_name,function () {
        Onload();
    })
});

