const primary1 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary1-color");
const primary2 = getComputedStyle(document.documentElement).getPropertyValue("--main-primary2-color");
const sec1 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary1-color");
const sec2 = getComputedStyle(document.documentElement).getPropertyValue("--main-secondary2-color");

export const GETAPIURL = (end_point)=>{
    return apiUrl + end_point
}

export const GETMIDDLEWAREAPIURL = (end_point) => {
    return apiMiddlewareUrl + end_point
}

export const GETBYID = (end_point, _id, _menuId, _name, patchdata, modalActionSpinners) => {
    Swal.fire({
        title: 'Information',
        text: 'Are you sure you want edit ' + _name + '?',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Confirm',
    })
        .then((result) => {
            if (result.value) {
            $.ajax({
                url: apiUrl + end_point,
                type: "Get",
                contentType: "application/json",
                dataType: "json",
                beforeSend: function (xhr) {
                    if (modalActionSpinners) {
                        modalActionSpinners.removeClass('fas fa-edit').addClass('fa fa-spinner fa-spin');
                    }
                    xhr.setRequestHeader("_MenuId", _menuId);
                    xhr.setRequestHeader("_Id", _id);
                    xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                },
                success: function (response) {
                    if (modalActionSpinners) {
                        modalActionSpinners.removeClass('fa fa-spinner fa-spin').addClass('fas fa-edit');
                    }
                    if (response.statusCode == '200') {
                        patchdata(response.data)
                    }
                    else {
                        Swal.fire({
                            title: response.message ,
                            icon: 'warning',
                            showConfirmButton: true,
                        })
                    }
                },
                error: function (xhr, status, err) {
                    if (modalActionSpinners) {
                        modalActionSpinners.removeClass('fa fa-spinner fa-spin').addClass('fas fa-edit');
                    }
                    Swal.fire({
                        title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                        icon: 'error',
                        showConfirmButton: true,
                    })
                }
            })
        }
    })
}

//export const GETBYIDFY = (end_point, _id, _menuId, _dateFrom, patchdata, modalActionSpinners) => {
//    Swal.fire({
//        title: 'Information',
//        text: 'Are you sure you want edit ' + _dateFrom + '?',
//        showCancelButton: true,
//        confirmButtonColor: sec1,
//        cancelButtonColor: primary2,
//        confirmButtonText: 'Confirm',
//    })
//        .then((result) => {
//            if (result.value) {
//                $.ajax({
//                    url: apiUrl + end_point,
//                    type: "Get",
//                    contentType: "application/json",
//                    dataType: "json",
//                    beforeSend: function (xhr) {
//                        if (modalActionSpinners) {
//                            modalActionSpinners.removeClass('fas fa-edit').addClass('fa fa-spinner fa-spin');
//                        }
//                        xhr.setRequestHeader("_MenuId", _menuId);
//                        xhr.setRequestHeader("_Id", _id);
//                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
//                    },
//                    success: function (response) {
//                        if (modalActionSpinners) {
//                            modalActionSpinners.removeClass('fa fa-spinner fa-spin').addClass('fas fa-edit');
//                        }
//                        if (response.statusCode == '200') {
//                            patchdata(response.data)
//                        }
//                        else {
//                            Swal.fire({
//                                title: response.message,
//                                icon: 'warning',
//                                showConfirmButton: true,
//                            })
//                        }
//                    },
//                    error: function (xhr, status, err) {
//                        if (modalActionSpinners) {
//                            modalActionSpinners.removeClass('fa fa-spinner fa-spin').addClass('fas fa-edit');
//                        }
//                        Swal.fire({
//                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
//                            icon: 'error',
//                            showConfirmButton: true,
//                        })
//                    }
//                })
//            }
//        })
//}

export const POST = (end_point, _cre, Onload, formActionSpinners) => {
   Swal.fire({
        title: "Information",
        text: "Are you sure you want to save this record?",
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Save',
    }).then((result) => {
        if (result.value) {
            $.ajax({
                url: apiUrl + end_point,
                type: "Post",
                contentType: "application/json",
                dataType: "json",
                data:  _cre,
                beforeSend: function (xhr) {
                    if(formActionSpinners) {
                        formActionSpinners.css("display", "inline-block");
                    }
                    xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                },
                success: function (response) {
                    //console.log(response)
                    if (formActionSpinners) {
                        formActionSpinners.css("display", "none");
                    }
                    if (response.statusCode == 200) {                       
                        $('#data_Model').modal('hide');
                        Onload();
                        Swal.fire({
                            title: response.message,
                            icon: 'success',
                            showConfirmButton: true,
                        })
                    }
                    else {
                        Swal.fire({
                            text: response.message,
                            icon: 'warning',
                            showConfirmButton: true,
                        })
                    }
                },
                error: function (xhr, status, err) {
                    if (formActionSpinners) {
                        formActionSpinners.css("display", "none");
                    }

                    if (xhr.status.toString() == "400") {
                        Swal.fire({
                            title: "Error",
                            text: "Please fill all the required fields!",
                            width: 500,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    } else {
                        Swal.fire({
                            title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                            width: 800,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                }
            })
        }
    })
    
   return true
}

export const PUT = (end_point, _cre, Onload, formActionSpinners) => {
    Swal.fire({
        title: 'Information',
        text: 'Are you sure you want to update this record?',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Update',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: apiUrl + end_point,
                    type: "Put",
                    contentType: "application/json",
                    dataType: "json",
                    data: _cre,
                    beforeSend: function (xhr) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "inline-block");
                        }
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                    },
                    success: function (response) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        if (response.statusCode == "200") {
                            $('#data_Model').modal('hide');
                            Onload();
                            Swal.fire({
                                title: response.message,
                                icon: 'success',
                                showConfirmButton: true,
                            })
                        }
                        else {
                            Swal.fire({
                                title: response.message,
                                icon: 'warning',
                                showConfirmButton: true,
                            })
                        }
                    },
                    error: function (xhr, status, err) {
                        if (formActionSpinners) {
                            formActionSpinners.css("display", "none");
                        }
                        Swal.fire({
                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                            width: 800,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                })
            }
        })
        
    return true;
}


export const DELETE = (end_point, _Id, _name, Onload, formActionSpinners) => {
    Swal.fire({
        title: 'Confirmation',
        text: 'Are you sure you want to delete ' + _name + '?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Delete',
    })
      .then((result) => {
        if (result.value) {
            $.ajax({
                url: apiUrl + end_point,
                type: "Delete",
                contentType: "application/json",
                dataType: "json",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("Id", _Id);
                    xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                    xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                },
                success: function (response) {
                    if (formActionSpinners) {
                        formActionSpinners.css("display", "none");
                    }
                    if (response.statusCode == 200) {
                        Swal.fire({
                            title: response.message,
                            icon: 'success',
                            showConfirmButton: true,
                        })
                        Onload();
                    }
                    else {
                        //var _title = response.statusCode == 405 ? "Error # <a href='" + apiUrl_View + "/Configuration/Report/ErrorLog?I=" + response.message + "' target='_blank'>"+ " " + response.message + "</a>" : response.message;
                        Swal.fire({
                            title: response.message,
                            icon: 'warning',
                            showConfirmButton: true,
                        })
                    }
                },
                error: function (xhr, status, err) {
                    if (formActionSpinners) {
                        formActionSpinners.css("display", "none");
                    }
                    Swal.fire({
                        title: xhr.status.toString() + ' #'+ status + '\n' + xhr.responseText,
                        icon: 'error',
                        showConfirmButton: true,
                    })
                }
            })
        }
    })
}

export const UNASSIGN = (end_point, _Id, _name, LoadEmployeesTable) => {
    Swal.fire({
        title: 'Confirmation',
        text: 'Are you sure you want to unassign ' + _name + '?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: sec1,
        cancelButtonColor: primary2,
        confirmButtonText: 'Delete',
    })
        .then((result) => {
            if (result.value) {
                $.ajax({
                    url: apiUrl + end_point,
                    type: "Delete",
                    contentType: "application/json",
                    dataType: "json",
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader("Id", _Id);
                        xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                        xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
                    },
                    success: function (response) {
                        if (response.statusCode == 200) {
                            Swal.fire({
                                title: response.message,
                                icon: 'success',
                                showConfirmButton: true,
                            })
                            LoadEmployeesTable();
                        }
                        else {
                            Swal.fire({
                                title: response.message,
                                icon: 'warning',
                                showConfirmButton: true,
                            })
                        }
                    },
                    error: function (xhr, status, err) {
                        Swal.fire({
                            title: xhr.status.toString() + ' #' + status + '\n' + xhr.responseText,
                            icon: 'error',
                            showConfirmButton: true,
                        })
                    }
                })
            }
        })
}


export const CLEAR = ()=>{
    document.getElementById('create_form').reset();
}

export const FILLCOMBO = (end_point, $element, placeholder) => {
    var $request = $.ajax({
        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView') 
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
     });

    $request.then(function (responce) {

        //console.log("Employee Department", responce.data);
        if (responce != null) {
            $element.empty();
            if (responce.statusCode === "200") { 
                $element.select2({
                    placeholder: "Select "+ placeholder,
                    multiple: false,
                    data: [{ id: -1, text: "Select " + placeholder + "" }, ...responce.data?.map((itm) => ({ text: itm.name, id: itm.id}))]
                });
                


            }else{
                $element.select2({
                    placeholder: "Select "+ placeholder,
                    data: [{ id: -1, text: "Select " + placeholder + ""}]
                });
            }
        }
    });
}

export const FILLCOMBOMULTIPARAM = (end_point, $element, placeholder) => {
    var $request = $.ajax({
        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView') 
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
    });

    $request.then(function (responce) {
        
        //console.log("Employee Department", responce.data);
        if (responce != null) {
            $element.empty();
            if (responce.statusCode === "200") {
                $element.select2({
                    placeholder: "Select " + placeholder,
                    multiple: false,
                    data: [{ id: -1, text: "Select " + placeholder + "", qty: '' }, ...responce.data?.map((itm) => ({ text: itm.name, id: itm.id, qty: itm.extensionType }))]
                });
            } else {
                $element.select2({
                    placeholder: "Select " + placeholder,
                    data: [{ id: -1, text: "Select " + placeholder + "", qty: '' }]
                });
            }
        }
    });
}


export const FILLCOMBOBYID = (Id,end_point,$element,placeholder)=>{
    var $request = $.ajax({
        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView') 
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader("_Id", Id);
        },
     });
    $request.then(function (responce) {
        if (responce!=null) {
            $element.empty();
            if (responce.statusCode === "200") {
            
                $element.select2({
                    placeholder: "Select "+ placeholder,
                    multiple: false,
                    data:[{ id: -1, text: "Select " + placeholder + "" }, ... responce.data?.map((itm) => ({ text: itm.name, id: itm.id }))]
                });
            }else{
                $element.select2({
                    placeholder: "Select "+ placeholder,
                    data:[{ id: -1, text: "Select " + placeholder + "" }]
                });
            }
        }
    });
}

export const FILLCOMBOBYIDROSTER = (Id, end_point, $element, placeholder) => {
    var $request = $.ajax({
        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView') 
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader("_Id", Id);
        },
    });
    $request.then(function (responce) {
        if (responce != null) {
            $element.empty();
            if (responce.statusCode === "200") {

                $element.select2({
                    placeholder: "Select " + placeholder,
                    multiple: false,
                    data: [{ id: -1, text: "Select " + placeholder + "" }, ...responce.data?.map((itm) => ({ text: itm.value, id: itm.id }))]
                });
            } else {
                $element.select2({
                    placeholder: "Select " + placeholder,
                    data: [{ id: -1, text: "Select " + placeholder + "" }]
                });
            }
        }
    });
}

export const FILLCOMBOWIHOUTSELECT2 = (end_point, $element, placeholder) => {
    var $request = $.ajax({
        url: apiUrl + end_point,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
    });

    $request.then(function (response) {
        if (response != null) {
            $element.empty();
            if (response.statusCode === "200") {
                $element.append($('<option>', {
                    value: -1,
                    text: "Select " + placeholder
                }));
                if (response.data != null) {
                    response.data?.forEach(function (item) {
                        $element.append($('<option>', {
                            value: item.id,
                            text: item.name
                        }));
                    });
                }
            } else {
                console.error("Error: ", response.message);
            }
        }
    });
};

export const FILLCOMBOFILTER = (end_point,$element,Id)=>{
    
    var $request = $.ajax({
        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView') 
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
            xhr.setRequestHeader("Search", Id.toString());
        },
     });

     $element.CLEAR
    $request.then(function (responce) {
        for (var d = 0; d < responce.data.length; d++) {
        var item = responce.data[d];
        var option = new Option(item.name, item.id, false, false);
        $element.append(option);
        }
    });
}

//export const FILLCOMBOMULTISELECT = (end_point, $element, placeholder) => {
//    var $request = $.ajax({
//        url: apiUrl + end_point, //GETAPIURL('/ListOfViewService/GetMenuCategoryListOfView')
//        beforeSend: function (xhr) {
//            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
//        },
//    });

//    $request.then(function (responce) {
//        //console.log("Employee Department", responce.data);
//        if (responce != null) {
//            $element.empty();
//            if (responce.statusCode === "200") {
//                $element.select2({
//                    placeholder: "Select " + placeholder,
//                    multiple: true,
//                    data: [{ id: -1, text: "Select " + placeholder + "" }, ...responce.data?.map((itm) => ({ text: itm.name, id: itm.id }))]
//                });
//            } else {
//                $element.select2({
//                    placeholder: "Select " + placeholder,
//                    data: [{ id: -1, text: "Select " + placeholder + "" }]
//                });

//            }
//        }
//    });
//}

export const FILLCOMBOMULTISELECT = (end_point, $element, placeholder) => {
    var $request = $.ajax({
        url: apiUrl + end_point,
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
    });

    $request.then(function (response) {
        if (response && response.statusCode === "200") {
            $element.empty();
            const employeeData = response.data?.map((itm) => ({ id: itm.id, text: itm.name })) || [];

            $element.select2({
                placeholder: "Select " + placeholder,
                allowClear: true,
                closeOnSelect: true,
                multiple: true,
                data: [{ id: -1, text: "Select " + placeholder }, ...employeeData],
                templateSelection: function (selected) {
                    return selected.text;
                }
            });
            let selectedItems = [];
            $element.on('select2:select', function (e) {
                const selectedId = e.params.data.id;
                if (selectedId !== -1) {
                    selectedItems.push(selectedId);
                    const uniqueSelections = [...new Set(selectedItems)];
                    $element.val(uniqueSelections).trigger('change');
                }
            });
            $element.on('select2:unselect', function (e) {
                const unselectedId = e.params.data.id;
                selectedItems = selectedItems.filter(id => id !== unselectedId);
            });

        } else {
            $element.select2({
                placeholder: "Select " + placeholder,
                data: [{ id: -1, text: "Select " + placeholder }]
            });
        }
    });
}

