
class ControlType {
    static radio = 'radio'
    static text = 'text';
    static image = 'image';
    static hidden = 'hidden';
    static number = 'number';
    static checkbox = 'checkbox';
    static select = 'select';
    static button = 'button';
    static submit = 'submit';
    static reset = 'reset';
    static password = 'password';
}