
// Form Request Name get from URL param
var url = new URLSearchParams(window.location.search);
var Id = '';
if (url.has('M')) {
    Id = window.atob(url.get('M'));
}
var app_token = ""

async function autoLoginToGetToken() {
    try {
        const res = await fetch('http://localhost:7085/api/external/login', { method: 'POST' });
        if (!res.ok) throw new Error(await res.text());
        const data = await res.json();
        if (data.user_api_hash) {
            localStorage.setItem('apiToken', data.user_api_hash);
            return data.user_api_hash;
        }
        throw new Error("Missing token in response");
    } catch (err) {
        console.error("❌ Auto-login failed:", err);
        return null;
    }
}

async function AddNotifications() {
    const notificationItems = document.getElementById('NotificationItems');
    const notificationCountElement = document.getElementById('notificationCount');
    let notificationCount = 0;
    let noNotificationsMessage = null;

    notificationItems.innerHTML = ''; // Clear existing notifications

    // Token lein, agar na ho to auto-login se lein
    let token = localStorage.getItem('apiToken');
    if (!token) {
        token = await autoLoginToGetToken();
        if (!token) {
            const errorMessage = document.createElement('a');
            errorMessage.className = 'dropdown-item text-danger';
            errorMessage.href = '#';
            errorMessage.textContent = 'Failed to authenticate';
            notificationItems.appendChild(errorMessage);
            notificationCountElement.textContent = '0';
            return;
        }
    }

    // Alerts fetch karo aur show karo
    try {
        const response = await fetch(`http://localhost:7085/api/external/getalerts?user_api_hash=${encodeURIComponent(token)}`);
        if (!response.ok) throw new Error('Network response was not ok');

        const alerts = await response.json();

        if (alerts.length === 0) {
            noNotificationsMessage = document.createElement('a');
            noNotificationsMessage.className = 'dropdown-item';
            noNotificationsMessage.href = '#';
            noNotificationsMessage.textContent = 'No notifications received';
            notificationItems.appendChild(noNotificationsMessage);
            notificationCountElement.textContent = '0';
        } else {
            alerts.forEach(alert => {
                notificationCount++;

                const item = document.createElement('a');
                item.className = 'dropdown-item';
                item.style.display = 'flex';
                item.style.alignItems = 'flex-start';

                const icon = document.createElement('i');
                icon.className = 'fas fa-exclamation-circle';
                icon.style.fontSize = '1.5rem';
                icon.style.marginRight = '10px';
                icon.style.color = alert.active ? 'red' : 'gray';

                const contentDiv = document.createElement('div');
                contentDiv.style.display = 'flex';
                contentDiv.style.flexDirection = 'column';

                const nameDiv = document.createElement('div');
                nameDiv.style.fontWeight = 'bold';
                nameDiv.textContent = alert.name;

                const dateDiv = document.createElement('div');
                dateDiv.style.color = '#6c757d';
                dateDiv.style.fontSize = 'small';
                dateDiv.textContent = `Created: ${alert.createdAt}`;

                const activeDiv = document.createElement('div');
                activeDiv.textContent = `Active: ${alert.active ? 'Yes' : 'No'}`;

                // New fields:
                const alertIdDiv = document.createElement('div');
                alertIdDiv.style.fontSize = 'small';
                alertIdDiv.style.color = '#007bff';
                alertIdDiv.textContent = `Alert ID: ${alert.alertId}`;

                const devicesDiv = document.createElement('div');
                devicesDiv.style.fontSize = 'small';
                devicesDiv.style.color = '#6c757d';
                devicesDiv.textContent = `Devices: ${alert.devices.join(', ')}`;

                contentDiv.appendChild(nameDiv);
                contentDiv.appendChild(alertIdDiv);
                contentDiv.appendChild(devicesDiv);
                contentDiv.appendChild(activeDiv);
                contentDiv.appendChild(dateDiv);

                item.appendChild(icon);
                item.appendChild(contentDiv);

                notificationItems.appendChild(item);

                const divider = document.createElement('div');
                divider.className = 'dropdown-divider';
                notificationItems.appendChild(divider);
            });

            notificationCountElement.textContent = notificationCount;
        }
    } catch (error) {
        console.error('Error fetching alerts:', error);
        const errorMessage = document.createElement('a');
        errorMessage.className = 'dropdown-item text-danger';
        errorMessage.href = '#';
        errorMessage.textContent = 'Failed to load notifications';
        notificationItems.appendChild(errorMessage);
        notificationCountElement.textContent = '0';
    }
    // HandleNotification jo aapne diya tha, exactly waise hi
    function handleNotification(message) {
        notificationCount++;
        notificationCountElement.textContent = notificationCount;

        if (noNotificationsMessage) {
            notificationItems.removeChild(noNotificationsMessage);
            noNotificationsMessage = null;
        }

        const messageParts = message.split(" ");
        const requestName = messageParts[0];
        const requestType = messageParts[2];
        const employeeName = messageParts.slice(4, messageParts.length - 4).join(" ");
        const dateTime = messageParts.slice(-3).join(" ");

        const item = document.createElement('a');
        item.className = 'dropdown-item';
        item.style.display = 'flex';
        item.style.alignItems = 'flex-start';

        const icon = document.createElement('i');
        icon.className = 'fas fa-user-circle';
        icon.style.fontSize = '3rem';
        icon.style.marginRight = '15px';

        const contentDiv = document.createElement('div');
        contentDiv.style.display = 'flex';
        contentDiv.style.flexDirection = 'column';
        contentDiv.style.lineHeight = '1.5';

        const nameDiv = document.createElement('div');
        nameDiv.style.fontWeight = 'bold';
        nameDiv.textContent = employeeName;

        const requestNameDiv = document.createElement('div');
        requestNameDiv.style.fontWeight = 'bold';
        requestNameDiv.textContent = requestName;

        const requestTypeDiv = document.createElement('div');
        requestTypeDiv.textContent = requestType;

        const dateTimeDiv = document.createElement('div');
        dateTimeDiv.style.color = '#6c757d';
        dateTimeDiv.textContent = dateTime;

        contentDiv.appendChild(nameDiv);
        contentDiv.appendChild(requestNameDiv);
        contentDiv.appendChild(requestTypeDiv);
        contentDiv.appendChild(dateTimeDiv);

        item.appendChild(icon);
        item.appendChild(contentDiv);

        notificationItems.insertBefore(item, notificationItems.firstChild);

        const divider = document.createElement('div');
        divider.className = 'dropdown-divider';
        notificationItems.insertBefore(divider, notificationItems.firstChild.nextSibling);
    }
}

$(document).ready(function () {

    if (localStorage.getItem(api_signature) != null) {
        app_token = localStorage.getItem(api_signature)
    }

    Onload();
    AddNotifications();

    $('.dropdown-toggle').dropdown();
    
});


// ONLOAD FUNCTION
// FETCH MENU OPTIONS NAMES
function Onload() {


    $("#baseURL").text(baseURL)
    var tbl_row_cnt = 1;
    $.ajax({
        url: apiUrl + "/api/v1/ConfigurationLovService/GetMenuInitializer",
        type: "Get",
        contentType: "application/json",
        dataType: "json",
        beforeSend: function (xhr) {
            xhr.setRequestHeader('Authorization', 'Bearer ' + app_token);
        },
        success: function (response) {
            if (response.statusCode === "200") {
                CreateMenu(response.data)
            }
        },
        error: function (xhr, status, err) {
            console.log(xhr + status)
            Swal.fire({
                title: "Disconnected with Sever",
                width: 800,
                icon: 'error',
                showConfirmButton: true,
            })
        }
    })
    return true;
}

function CreateMenu(responce) {
    var modules = [];
    var modulesObj = {};
    console.log(responce);

    for (const obj in responce) {
        if (!modules.includes(responce[obj].moduleName)) {

            modules.push(responce[obj].moduleName)
            modulesObj[responce[obj].moduleName] = responce[obj]
        }
    }
    var menuSubCategory = ""
    var menu = `<li class="sidebar-item">
    ${Object.keys(modulesObj).map(module => {
        const menuSubCategories = responce.filter(obj => obj.moduleName === module);

        if (module === menuSubCategories[0]?.menuAlias) {
            return `
                <a href="${menuSubCategories[0].menuURL.replace(" ", "")}?M=${btoa(menuSubCategories[0].menuId)}" class="sidebar-link">
                    <i class="align-middle mr-2 ${modulesObj[module].moduleIcon}"></i> 
                    <span class="align-middle">${modulesObj[module].moduleName}</span>
                </a>`;
        } else {
            return `
                <a href="#${module.replace(" ", "")}" data-toggle="collapse" class="sidebar-link collapsed">
                    <i class="align-middle mr-2 ${modulesObj[module].moduleIcon}"></i> 
                    <span class="align-middle">${modulesObj[module].moduleName}</span>
                </a>
                <ul id="${module.replace(" ", "")}" class="sidebar-dropdown list-unstyled collapse" data-parent="#sidebar">
                    ${(() => {
                    return menuSubCategories.length !== 0 ? menuSubCategories.map(menuSubCategory => `
                            <li class="sidebar-item">
                                <a href="${menuSubCategory.menuURL.replace(" ", "")}?M=${btoa(menuSubCategory.menuId)}" class="sidebar-link">
                                    <i class="align-middle mr-2 ${menuSubCategory.moduleIcon}"></i>
                                    <span class="align-middle text-dark">${menuSubCategory.menuAlias}</span>
                                </a>
                            </li>`).join('') : '';
                })()}
                </ul>`;
        }
    }).join('')}
</li>`;


    var sidebar = document.getElementById("sideMenu")
    sidebar.innerHTML = ""
    sidebar.innerHTML = menu;

}