﻿
function AddNotifications() {
    const notificationItems = document.getElementById('NotificationItems');
    const notificationCountElement = document.getElementById('notificationCount');
    let notificationCount = 0;
    let noNotificationsMessage = null;

    // Initialize notification count and display stored notifications
    function initializeNotifications() {
        const storedNotifications = JSON.parse(localStorage.getItem('notifications')) || [];
        notificationCount = storedNotifications.length;
        notificationCountElement.textContent = notificationCount;

        if (notificationCount === 0) {
            showNoNotificationsMessage();
        } else {
            storedNotifications.forEach(message => addNotificationItem(message));
        }
    }

    // Function to handle the notification
    function handleNotification(message) {

        notificationCount++;
        notificationCountElement.textContent = notificationCount;

        // Add the notification to the UI
        addNotificationItem(message);
        const storedNotifications = JSON.parse(localStorage.getItem('notifications')) || [];
        storedNotifications.push(message);
        localStorage.setItem('notifications', JSON.stringify(storedNotifications));
        console.log("Notification stored in LocalStorage")
    }

    function addNotificationItem(message) {
        // Remove "No notifications" message if it exists
        if (noNotificationsMessage) {
            notificationItems.removeChild(noNotificationsMessage);
            noNotificationsMessage = null;
        }

        const item = document.createElement('a');
        item.className = 'dropdown-item';

        if (message.startsWith("Advance Salary")) {
            item.href = "/AdvanceSalary/AdvanceSalary?M=" + Id + "";
        } else {
            item.href = '#';
        }

        const icon = document.createElement('i');
        icon.className = 'align-middle mr-1 fas fa-envelope';

        item.appendChild(icon);
        item.appendChild(document.createTextNode(message));
        notificationItems.appendChild(item);

        // Create a divider
        const divider = document.createElement('div');
        divider.className = 'dropdown-divider';
        notificationItems.appendChild(divider);
    }


    // Function to display "No notifications" message
    function showNoNotificationsMessage() {
        if (!noNotificationsMessage) {
            noNotificationsMessage = document.createElement('a');
            noNotificationsMessage.className = 'dropdown-item';
            noNotificationsMessage.href = '#';
            noNotificationsMessage.textContent = 'No notifications received';
            notificationItems.appendChild(noNotificationsMessage);
        }
    }

    // Create and configure the SignalR connection
    const connection = new signalR.HubConnectionBuilder()
        .withUrl("http://localhost:7085/notifications", {
            skipNegotiation: true,
            transport: signalR.HttpTransportType.WebSockets
        })
        .withAutomaticReconnect()
        .build();

    // Function to start the connection
    async function startConnection() {
        try {
            await connection.start();
            console.log("SignalR Connected.");
        } catch (err) {
            console.error("SignalR Connection Error: ", err);
            setTimeout(startConnection, 5000);
        }
    }

    // Start the connection
    startConnection();
    connection.on("ReceiveNotification", handleNotification);
    connection.onclose(async () => {
        console.log("SignalR Connection Closed unexpectedly.");
        await startConnection();
    });

    initializeNotifications();
}
